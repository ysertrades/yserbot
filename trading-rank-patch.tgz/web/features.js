'use strict';

/**
 * web/features.js
 *
 * The rest of the bot's adjustable surface: the lottery
 * channel, card drops, levelling, verification, scheduled posts, auto-replies
 * and direct coin adjustments.
 *
 * Same shape as web/settings.js and for the same reason — these are a dozen
 * small settings that differ only in where they live and what counts as a
 * valid value, so they're described as data. A per-setting function each would
 * be a dozen chances for the validation to drift apart.
 *
 * The list-shaped things (schedules, auto-replies, level roles) can't be
 * expressed that way, so they get real handlers underneath.
 */

const { readJson, writeJson } = require('../utils/jsonStorage');
const { getBalance, addCoins, setBalance } = require('../utils/economyManager');
const { BADGE_DEFS } = require('../utils/badges');
const {
  generateScheduleId, parseScheduleTime,
  nextWeekdayTimestamp, nextDayOfWeekTimestamp, onDateTimestamp,
  formatDate, dayOfWeek, DAY_NAMES,
} = require('../utils/scheduler');
const { todaysSlotUTC, REWARD: LOTTERY_REWARD, drawStatus } = require('../utils/lotteryRunner');
const { normaliseMention } = require('../utils/mentionTarget');
const { parseDuration, formatDuration } = require('../utils/duration');
const levelingEngine = require('../utils/levelingEngine');

// Exactly what utils/scheduler.js implements — anything not listed here is
// treated as daily by computeNextRun, so a value the runner does not know
// would silently fire every day instead of on the cadence that was picked.
const FREQUENCIES = [
  { value: 'once',     label: 'Once' },
  { value: 'everyday', label: 'Every day' },
  { value: 'weekdays', label: 'Weekdays (Mon–Fri)' },
  { value: 'weekly',   label: 'Every week (pick a day)' },
];
const FREQUENCY_VALUES = FREQUENCIES.map(f => f.value);

// The weekday a weekly schedule lands on is not a stored field — it lives in
// the run time, and the 7-day step keeps it there. The panel still needs the
// names to offer the picker, and the current day back to show what is set.
const DAY_OPTIONS = DAY_NAMES.map((label, value) => ({ value, label }));

/**
 * The chosen day for a weekly schedule, or null when none was picked.
 *
 * The empty string is checked for explicitly: a select left on its blank
 * option posts '', and Number('') is 0 — which would read as "Sunday" and
 * quietly move a schedule nobody asked to move.
 */
function weeklyDay(body, fallback = null) {
  const raw = body.dayOfWeek;
  if (raw === undefined || raw === null || raw === '') return fallback;
  const n = Number(raw);
  return Number.isInteger(n) && n >= 0 && n <= 6 ? n : fallback;
}

/**
 * The date picked for a schedule, or null when none was.
 *
 * Same trap as weeklyDay: a date input that has been cleared posts '', and an
 * empty string has to mean "leave the day alone" rather than being handed to a
 * parser that would reject it and fail an edit nobody meant to make.
 */
function scheduleDate(body) {
  const raw = body.date;
  if (raw === undefined || raw === null) return null;
  const str = String(raw).trim();
  return str === '' ? null : str;
}

// file → the settings inside it, so one table covers several stores.
const GROUPS = {
  cards: {
    file: 'cards_config.json',
    label: 'Card drops',
    fields: [
      { key: 'channelId', label: 'Drop channel', type: 'channel' },
      { key: 'chance', label: 'Drop chance (%)', type: 'int', min: 1, max: 100, fallback: 5 },
      { key: 'interval', label: 'Messages between drops', type: 'int', min: 1, max: 1000, fallback: 25 },
    ],
  },
};

// These live under config.json[guildId], like web/settings.js.
const CONFIG_GROUPS = {
  lottery: {
    label: 'Lottery',
    fields: [
      // Without one there is no draw at all — the runner has always skipped a
      // guild that has not set this, so it is the difference between the
      // lottery existing and not.
      { key: 'channelId', path: ['lotterySettings', 'channelId'], label: 'Results channel', type: 'channel' },
      // Stops the draw *and* the ticket sales. It used to stop only the draw,
      // which meant a paused lottery went on taking coins for entries that
      // would never be drawn. The pool itself is untouched either way, so
      // entries already bought are still there when it is switched back on.
      { key: 'paused', path: ['lotterySettings', 'paused'], label: 'Pause the daily draw', type: 'bool' },
    ],
  },
  verify: {
    label: 'Verification',
    fields: [
      // ['verifySettings', 'role'] — NOT 'roleId'. commands/utility/verify.js
      // reads settings.role, so the panel writing roleId meant picking a role
      // here did nothing at all: the panel showed it set, and /verify still
      // told members no role had been configured.
      { key: 'role', path: ['verifySettings', 'role'], label: 'Role given on verify', type: 'role' },
      { key: 'channelId', path: ['verifySettings', 'channelId'], label: 'Where the panel goes', type: 'channel' },
      { key: 'title', path: ['verifySettings', 'title'], label: 'Panel heading', type: 'text', max: 200 },
      { key: 'intro', path: ['verifySettings', 'intro'], label: 'Opening line', type: 'text', max: 1500 },
      { key: 'rulesText', path: ['verifySettings', 'rulesText'], label: 'Rules text', type: 'text', max: 3000 },
      // The button's label, emoji and colour are on the Appearance screen,
      // beside a preview of the button itself. It was here as well, and the
      // one here always won — so editing the button where you can see it did
      // nothing. A value already saved here still applies until the button is
      // edited on Appearance, so nobody's panel changes wording on its own.
      // The memory challenge itself. Four of eight is the shipped difficulty;
      // the range is what the grid can actually be built from — Discord allows
      // five buttons a row and the answer view uses four rows at most.
      { key: 'sequenceLength', path: ['verifySettings', 'sequenceLength'], label: 'Emoji to memorise', type: 'int', min: 2, max: 6, fallback: 4 },
      { key: 'welcome', path: ['verifySettings', 'welcome'], label: 'Message after verifying', type: 'text', max: 1000 },
    ],
  },
};

const LEVEL_FIELDS = [
  { key: 'xpMin', label: 'XP per message (min)', type: 'int', min: 1, max: 500, fallback: 10 },
  { key: 'xpMax', label: 'XP per message (max)', type: 'int', min: 1, max: 500, fallback: 20 },
  { key: 'baseXp', label: 'XP for level 1', type: 'int', min: 10, max: 100000, fallback: 150 },
  { key: 'multiplier', label: 'Growth per level (×)', type: 'float', min: 1.01, max: 5, fallback: 1.5 },
  // The two anti-farming levers. Both were fixed in source until now — the
  // cooldown at twenty seconds, the length check at nothing at all.
  { key: 'cooldownMs', label: 'Wait between earning messages', type: 'duration', min: 0, max: 6 * 60 * 60 * 1000, fallback: 20000,
    hint: 'How long before a member can earn again. 0 pays on every message.' },
  { key: 'minLength', label: 'Shortest message that earns', type: 'int', min: 0, max: 500, fallback: 0,
    hint: 'A shorter message earns nothing and does not start the cooldown, so a quick "yes" costs a member nothing. 0 turns it off.' },
];

const dig = (o, p) => p.reduce((x, k) => (x == null ? x : x[k]), o);
function put(o, p, v) {
  let cur = o;
  for (const k of p.slice(0, -1)) { if (typeof cur[k] !== 'object' || cur[k] === null) cur[k] = {}; cur = cur[k]; }
  cur[p[p.length - 1]] = v;
}

/* ─── reading ────────────────────────────────────────────────────────────── */

function read(guildId, guild) {
  const out = { groups: {}, schedules: [], autoreplies: [], levels: null, members: [] };

  for (const [name, group] of Object.entries(GROUPS)) {
    const store = readJson(group.file, {})[guildId] || {};
    out.groups[name] = {
      label: group.label,
      fields: group.fields.map(f => ({ ...f })),
      values: Object.fromEntries(group.fields.map(f => [f.key, store[f.key] ?? f.fallback ?? null])),
    };
  }

  const conf = readJson('config.json', {})[guildId] || {};
  for (const [name, group] of Object.entries(CONFIG_GROUPS)) {
    out.groups[name] = {
      label: group.label,
      fields: group.fields.map(f => ({ ...f })),
      values: Object.fromEntries(group.fields.map(f => [f.key, dig(conf, f.path) ?? f.fallback ?? null])),
    };
  }

  // Scheduled posts, with the template and channel resolved so the panel can
  // show what they actually refer to rather than a pair of ids.
  const scheduled = readJson('schedules.json', {})[guildId] || {};
  out.schedules = Object.values(scheduled).map(s => ({
    id: s.id,
    embedName: s.embedName,
    channelId: s.channelId,
    channelName: guild.channels.cache.get(s.channelId)?.name || null,
    frequency: s.frequency,
    // Derived, not stored — see DAY_OPTIONS above. Null for every cadence
    // except weekly, where it is what the day picker shows as current.
    dayOfWeek: s.frequency === 'weekly' && s.time ? dayOfWeek(s.time, s.offsetMinutes ?? 0) : null,
    // Derived the same way, and for the same reason: the date a schedule next
    // runs on lives inside its run time. The picker needs it to open on the
    // day that is actually set rather than on an empty box.
    date: s.time ? formatDate(s.time, s.offsetMinutes ?? 0) : null,
    mention: s.mention ?? null,
    time: s.time ?? null,
    offsetMinutes: s.offsetMinutes ?? 0,
    lastRun: s.lastRun ?? null,
  })).sort((a, b) => (a.embedName || '').localeCompare(b.embedName || ''));

  const replies = readJson('autoreplies.json', {})[guildId] || {};
  out.autoreplies = Object.entries(replies).map(([key, r]) => ({
    key, trigger: r.trigger, embedName: r.embedName,
    exact: !!r.exact, cooldown: r.cooldown ?? 0, enabled: r.enabled !== false,
  })).sort((a, b) => a.trigger.localeCompare(b.trigger));

  const lv = readJson('levels.json', {})[guildId] || {};
  const s = lv.settings || {};
  const xp = Array.isArray(s.xpPerMessage) ? s.xpPerMessage : [10, 20];
  out.levels = {
    fields: LEVEL_FIELDS,
    values: {
      xpMin: xp[0], xpMax: xp[1], baseXp: s.baseXp ?? 150, multiplier: s.multiplier ?? 1.5,
      // Shown as the string it would be typed back in as, the way the economy
      // screen does its cooldowns.
      cooldownMs: formatDuration(s.cooldownMs ?? 20000) || '0',
      minLength: s.minLength ?? 0,
    },
    roles: Object.entries(lv.roles || {}).map(([level, roleId]) => ({
      level: Number(level), roleId, roleName: guild.roles.cache.get(roleId)?.name || null,
    })).sort((a, b) => a.level - b.level),
    badges: Object.entries(lv.badges || {}).map(([level, badgeId]) => ({
      level: Number(level), badgeId, badgeLabel: BADGE_DEFS[badgeId]?.label || badgeId,
    })).sort((a, b) => a.level - b.level),
    badgeCatalog: Object.entries(BADGE_DEFS).map(([id, b]) => ({ id, label: b.label, emoji: b.emoji })),
    tracked: Object.keys(lv.users || {}).length,
  
    trading: levelingEngine.panelSnapshot(guildId, guild),
};

  // Members the panel can act on. Capped, because a large server would make
  // the overview payload enormous — and a picker nobody can scroll is no
  // better than a box you type an id into.
  out.members = guild.members?.cache
    ? [...guild.members.cache.values()]
        .filter(m => !m.user?.bot)
        .map(m => {
          const name = m.displayName || m.user?.globalName || m.user?.username || m.id;
          const isOwner = m.id === guild.ownerId;
          let isAdmin = false;
          try {
            isAdmin = !!(m.permissions?.has?.('Administrator') || m.permissions?.has?.('ManageGuild'));
          } catch {}
          const roles = [...(m.roles?.cache?.values?.() || [])]
            .filter(r => r.id !== guild.id && !r.managed)
            .sort((a, b) => (b.position || 0) - (a.position || 0))
            .map(r => ({
              id: r.id, name: r.name,
              color: r.hexColor && r.hexColor !== '#000000' ? r.hexColor : null,
            }));
          let avatar = null;
          try {
            avatar = m.displayAvatarURL?.({ size: 64, extension: 'png', forceStatic: true })
              || m.user?.displayAvatarURL?.({ size: 64 }) || null;
          } catch {}
          return {
            id: m.id, name, username: m.user?.username || '', displayName: name,
            avatar, roles, isOwner, isAdmin: isAdmin || isOwner,
            joinedAt: m.joinedTimestamp || null,
            accountCreatedAt: m.user?.createdTimestamp || null,
          };
        })
        .sort((a, b) => {
          if (a.isOwner !== b.isOwner) return a.isOwner ? -1 : 1;
          if (a.isAdmin !== b.isAdmin) return a.isAdmin ? -1 : 1;
          return a.name.localeCompare(b.name);
        })
        .slice(0, 500)
    : [];

  // Admins for Drop Desk host picker — Manage Guild or Administrator, non-bots.
  out.admins = guild.members?.cache
    ? [...guild.members.cache.values()]
        .filter(m => {
          if (m.user?.bot) return false;
          try {
            return m.permissions?.has?.('Administrator')
              || m.permissions?.has?.('ManageGuild');
          } catch { return false; }
        })
        .map(m => ({
          id: m.id,
          name: m.displayName || m.user?.username || m.id,
        }))
        .sort((a, b) => a.name.localeCompare(b.name))
    : [];

  // Today's lottery pool, resolved to names. The draw itself is run by
  // utils/lotteryRunner on its own schedule; this is the window onto it.
  const lot = readJson('lottery.json', {})[guildId] || { pool: {}, lastDrawAt: 0, history: [] };
  const pool = Object.entries(lot.pool || {}).sort((a, b) => b[1] - a[1]);
  const lotteryStatus = drawStatus(guildId);
  out.lottery = {
    reward: LOTTERY_REWARD,
    // Whether a draw can actually happen. The panel used to show a countdown
    // whatever the state, which is the screen promising a draw that a paused
    // or unconfigured lottery was never going to run.
    open: lotteryStatus.open,
    closedReason: lotteryStatus.reason,
    totalTickets: pool.reduce((n, [, c]) => n + c, 0),
    participants: pool.length,
    nextDrawAt: todaysSlotUTC(Date.now() + 86400000),
    lastDrawAt: lot.lastDrawAt || null,
    top: pool.slice(0, 10).map(([userId, tickets]) => ({
      userId, tickets,
      name: guild.members?.cache?.get(userId)?.displayName || null,
    })),
    history: (lot.history || []).slice(-5).reverse(),
  };

  out.frequencies = FREQUENCIES;
  out.scheduleDays = DAY_OPTIONS;
  return out;
}

/* ─── validation ─────────────────────────────────────────────────────────── */

function coerce(field, incoming, guild) {
  switch (field.type) {
    case 'channel': {
      if (!incoming) return { value: null };
      const ch = guild.channels.cache.get(incoming);
      if (!ch?.isTextBased?.()) return { error: 'bad_channel' };
      return { value: incoming };
    }
    case 'role': {
      if (!incoming) return { value: null };
      if (!guild.roles.cache.has(incoming)) return { error: 'bad_role' };
      return { value: incoming };
    }
    case 'int': {
      const n = Number(incoming);
      if (!Number.isInteger(n) || n < field.min || n > field.max) return { error: 'bad_number' };
      return { value: n };
    }
    case 'float': {
      const n = Number(incoming);
      if (!Number.isFinite(n) || n < field.min || n > field.max) return { error: 'bad_number' };
      return { value: Math.round(n * 100) / 100 };
    }
    case 'duration': {
      // The same 20s/10m/2h the slash commands take, so a value typed here and
      // a value typed into /levelsettings mean the same thing. Zero is a real
      // answer for a cooldown — "every message earns" — and parseDuration
      // refuses it on purpose, so it is handled before the parse.
      const raw = String(incoming ?? '').trim();
      if (/^0[smhd]?$/i.test(raw) || raw === '') {
        return field.min === 0 ? { value: 0 } : { error: 'bad_duration' };
      }
      const ms = parseDuration(raw);
      if (ms === null || ms < field.min || ms > field.max) return { error: 'bad_duration' };
      return { value: ms };
    }
    case 'text':
      return { value: typeof incoming === 'string' ? incoming.slice(0, field.max || 2000) : '' };
    case 'bool':
      // Strictly a boolean: a checkbox that arrived as the string "false"
      // would otherwise be stored as true, which for a pause switch means the
      // opposite of what was asked for.
      if (typeof incoming !== 'boolean') return { error: 'bad_bool' };
      return { value: incoming };
    default:
      return { error: 'bad_field' };
  }
}

/* ─── writing ────────────────────────────────────────────────────────────── */

function saveGroup(guildId, name, body, guild) {
  // hasOwn rather than a truthiness check — GROUPS['__proto__'] is
  // Object.prototype, which is truthy and has no fields, so it sailed past the
  // guard and threw on the way to the store.
  const group = Object.hasOwn(GROUPS, name) ? GROUPS[name] : null;
  const confGroup = Object.hasOwn(CONFIG_GROUPS, name) ? CONFIG_GROUPS[name] : null;
  if (!group && !confGroup) return { error: 'unknown_group' };

  const fields = (group || confGroup).fields;
  const changed = [];

  if (group) {
    const all = readJson(group.file, {});
    if (!all[guildId]) all[guildId] = {};
    for (const f of fields) {
      if (!(f.key in body)) continue;
      const r = coerce(f, body[f.key], guild);
      if (r.error) return { error: r.error, field: f.key };
      if (all[guildId][f.key] === r.value) continue;
      all[guildId][f.key] = r.value;
      changed.push(f.label);
    }
    if (!changed.length) return { unchanged: true };
    writeJson(group.file, all);
    return { ok: true, changed, label: group.label };
  }

  const conf = readJson('config.json', {});
  if (!conf[guildId]) conf[guildId] = {};
  for (const f of fields) {
    if (!(f.key in body)) continue;
    const r = coerce(f, body[f.key], guild);
    if (r.error) return { error: r.error, field: f.key };
    if (dig(conf[guildId], f.path) === r.value) continue;
    put(conf[guildId], f.path, r.value);
    changed.push(f.label);
  }
  if (!changed.length) return { unchanged: true };
  writeJson('config.json', conf);
  return { ok: true, changed, label: confGroup.label };
}

function saveLevels(guildId, body) {
  const all = readJson('levels.json', {});
  if (!all[guildId]) all[guildId] = { users: {}, roles: {}, settings: {} };
  const s = all[guildId].settings || {};
  const values = {};

  for (const f of LEVEL_FIELDS) {
    if (!(f.key in body)) continue;
    const r = coerce(f, body[f.key], null);
    if (r.error) return { error: r.error, field: f.key };
    values[f.key] = r.value;
  }
  if (!Object.keys(values).length) return { unchanged: true };

  const xp = Array.isArray(s.xpPerMessage) ? [...s.xpPerMessage] : [10, 20];
  if ('xpMin' in values) xp[0] = values.xpMin;
  if ('xpMax' in values) xp[1] = values.xpMax;
  if (xp[0] > xp[1]) return { error: 'min_above_max' };

  all[guildId].settings = {
    ...s,
    xpPerMessage: xp,
    baseXp: values.baseXp ?? s.baseXp ?? 150,
    multiplier: values.multiplier ?? s.multiplier ?? 1.5,
    cooldownMs: values.cooldownMs ?? s.cooldownMs ?? 20000,
    minLength: values.minLength ?? s.minLength ?? 0,
  };
  writeJson('levels.json', all);
  return { ok: true, changed: ['Levelling'] };
}

function saveLevelRole(guildId, body, guild) {
  const level = Number(body.level);
  if (!Number.isInteger(level) || level < 1 || level > 999) return { error: 'bad_number' };

  const all = readJson('levels.json', {});
  if (!all[guildId]) all[guildId] = { users: {}, roles: {}, settings: {} };
  if (!all[guildId].roles) all[guildId].roles = {};

  if (body.remove) {
    if (!(level in all[guildId].roles)) return { error: 'unknown_level_role' };
    delete all[guildId].roles[level];
    writeJson('levels.json', all);
    return { ok: true, removed: level };
  }

  if (!guild.roles.cache.has(body.roleId)) return { error: 'bad_role' };
  all[guildId].roles[level] = body.roleId;
  writeJson('levels.json', all);
  return { ok: true, level, roleId: body.roleId };
}

/**
 * A badge awarded automatically the moment a member reaches a level — the
 * replacement for buying one in the shop, so badges keep working exactly
 * the same whether or not this server's economy is switched on. Same shape
 * as level-reward roles (level -> id), on purpose: one is a role, one is a
 * badge, and an admin who already understands one understands the other.
 */
function saveLevelBadge(guildId, body) {
  const level = Number(body.level);
  if (!Number.isInteger(level) || level < 1 || level > 999) return { error: 'bad_number' };

  const all = readJson('levels.json', {});
  if (!all[guildId]) all[guildId] = { users: {}, roles: {}, settings: {} };
  if (!all[guildId].badges) all[guildId].badges = {};

  if (body.remove) {
    if (!(level in all[guildId].badges)) return { error: 'unknown_level_badge' };
    delete all[guildId].badges[level];
    writeJson('levels.json', all);
    return { ok: true, removed: level };
  }

  if (!BADGE_DEFS[body.badgeId]) return { error: 'bad_badge' };
  all[guildId].badges[level] = body.badgeId;
  writeJson('levels.json', all);
  return { ok: true, level, badgeId: body.badgeId };
}

/**
 * Wipes every member's level/XP/message-count for this guild — level reward
 * roles and level badges stay configured, since those are settings, not
 * progress. There's no undo, so the panel confirms before calling this.
 */
function resetAllLevels(guildId) {
  const all = readJson('levels.json', {});
  const count = Object.keys(all[guildId]?.users || {}).length;
  if (!count) return { ok: true, reset: 0 };
  all[guildId].users = {};
  writeJson('levels.json', all);
  return { ok: true, reset: count };
}

/**
 * Turns a typed time, a picked date and the browser's UTC offset into an
 * absolute run time.
 *
 * This is why scheduling can live on the web at all: the page knows the
 * viewer's offset, so "09:30" means the same instant it would have meant if
 * you had typed it into /schedule.
 *
 * Returns the reason rather than a bare null, because there are now three ways
 * this can fail and they need three different things done about them — a
 * malformed time, a day that does not exist, and a moment that has already
 * gone by all used to arrive as the same "check the time" message.
 *
 * @returns {{time: number}|{error: string}}
 */
function resolveTime(input, offsetMinutes, frequency, day = null, date = null) {
  const offset = Number(offsetMinutes);
  if (!Number.isFinite(offset) || offset < -720 || offset > 840) return { error: 'bad_time' };
  let t = parseScheduleTime(String(input || '').trim(), offset);
  if (!t) return { error: 'bad_time' };

  // The date is the most specific thing said about when to post, so it is
  // applied first and the cadence nudges work from there.
  if (date) {
    const onDate = onDateTimestamp(t, date, offset);
    if (onDate === null) return { error: 'bad_date' };
    // A time of day already gone by rolls to tomorrow on its own; pinning it
    // to today puts it in the past, and the runner fires anything in the past
    // on its very next tick.
    if (onDate <= Date.now()) return { error: 'past_date' };
    t = onDate;
  }

  if (frequency === 'weekdays') t = nextWeekdayTimestamp(t, offset);
  // Weekly keeps whatever weekday its run time lands on, so the picked day is
  // applied to that time rather than stored beside it. A date already names a
  // weekday, so it wins — applying both would move the run off the very date
  // that was picked.
  if (frequency === 'weekly' && day !== null && !date) t = nextDayOfWeekTimestamp(t, day, offset);
  return { time: t };
}

/** Creates a scheduled post. */
function createSchedule(guildId, body, guild) {
  const templates = readJson('embeds.json', {})[guildId] || {};
  const embedName = String(body.embedName || '').trim();
  if (!templates[embedName]) return { error: 'unknown_template' };

  const channel = guild.channels.cache.get(String(body.channelId || ''));
  if (!channel?.isTextBased?.()) return { error: 'bad_channel' };

  const frequency = FREQUENCY_VALUES.includes(body.frequency) ? body.frequency : null;
  if (!frequency) return { error: 'bad_frequency' };

  const when = resolveTime(body.time, body.offsetMinutes, frequency, weeklyDay(body), scheduleDate(body));
  if (when.error) return { error: when.error };
  const time = when.time;

  const mention = normaliseMention(body.mention, guild);
  if (mention === undefined) return { error: 'bad_mention' };

  const all = readJson('schedules.json', {});
  if (!all[guildId]) all[guildId] = {};
  const id = generateScheduleId(Object.keys(all[guildId]));

  all[guildId][id] = {
    id, embedName, channelId: channel.id, time, frequency, mention,
    offsetMinutes: Number(body.offsetMinutes) || 0,
    createdBy: body.createdBy || null, createdAt: Date.now(), lastRun: null,
  };
  writeJson('schedules.json', all);
  return { ok: true, id, embedName, channelName: channel.name, time };
}

function saveSchedule(guildId, body, guild) {
  const id = String(body.id || '').trim();
  const all = readJson('schedules.json', {});
  const entry = all[guildId]?.[id];
  if (!entry) return { error: 'unknown_schedule' };

  if (body.remove) {
    delete all[guildId][id];
    writeJson('schedules.json', all);
    return { ok: true, removed: id };
  }

  const changed = [];
  if (body.channelId && body.channelId !== entry.channelId) {
    if (!guild.channels.cache.get(body.channelId)?.isTextBased?.()) return { error: 'bad_channel' };
    entry.channelId = body.channelId;
    changed.push('channel');
  }
  if (body.embedName && body.embedName !== entry.embedName) {
    const templates = readJson('embeds.json', {})[guildId] || {};
    if (!templates[body.embedName]) return { error: 'unknown_template' };
    entry.embedName = body.embedName;
    changed.push('message');
  }
  if (body.frequency && body.frequency !== entry.frequency) {
    if (!FREQUENCY_VALUES.includes(body.frequency)) return { error: 'bad_frequency' };
    entry.frequency = body.frequency;
    changed.push('frequency');
  }
  if ('mention' in body) {
    const m = normaliseMention(body.mention, guild);
    if (m === undefined) return { error: 'bad_mention' };
    if (m !== entry.mention) { entry.mention = m; changed.push('mention'); }
  }
  if (body.time) {
    const when = resolveTime(body.time, body.offsetMinutes, entry.frequency, weeklyDay(body), scheduleDate(body));
    if (when.error) return { error: when.error };
    entry.time = when.time;
    entry.offsetMinutes = Number(body.offsetMinutes) || 0;
    changed.push('time');
  } else {
    // No new time typed, but the day it runs on may still have moved — or the
    // schedule may have only just become weekly. Both branches shift the run
    // time already stored rather than making somebody retype a time they were
    // happy with; the time of day survives either way.
    const offset = entry.offsetMinutes || 0;
    const date = scheduleDate(body);
    const day = weeklyDay(body);

    if (date && entry.time) {
      const moved = onDateTimestamp(entry.time, date, offset);
      if (moved === null) return { error: 'bad_date' };
      if (moved !== entry.time) {
        if (moved <= Date.now()) return { error: 'past_date' };
        entry.time = moved;
        changed.push('date');
      }
    } else if (entry.frequency === 'weekly' && day !== null && entry.time && dayOfWeek(entry.time, offset) !== day) {
      entry.time = nextDayOfWeekTimestamp(entry.time, day, offset);
      changed.push('day');
    }
  }
  if (!changed.length) return { unchanged: true };
  all[guildId][id] = entry;
  writeJson('schedules.json', all);
  return { ok: true, id, changed };
}

function saveAutoreply(guildId, body) {
  const all = readJson('autoreplies.json', {});
  if (!all[guildId]) all[guildId] = {};
  const key = String(body.key || '').trim().toLowerCase();
  if (!key || key.length > 60) return { error: 'bad_trigger' };

  if (body.remove) {
    if (!all[guildId][key]) return { error: 'unknown_autoreply' };
    delete all[guildId][key];
    writeJson('autoreplies.json', all);
    return { ok: true, removed: key };
  }

  const templates = readJson('embeds.json', {})[guildId] || {};
  const embedName = String(body.embedName || '').trim();
  if (!templates[embedName]) return { error: 'unknown_template' };

  const cooldown = Number(body.cooldown);
  if (!Number.isInteger(cooldown) || cooldown < 0 || cooldown > 86400) return { error: 'bad_number' };

  const existing = all[guildId][key];
  all[guildId][key] = {
    trigger: String(body.trigger || key).trim().slice(0, 100),
    embedName, exact: !!body.exact, cooldown,
    enabled: body.enabled !== false,
  };
  writeJson('autoreplies.json', all);
  return { ok: true, key, isNew: !existing };
}

/**
 * Direct coin adjustment.
 *
 * The most dangerous thing the panel can do, so it is the most constrained:
 * a bounded amount, a member who is actually in the guild, and an explicit
 * mode rather than a signed number that could be fat-fingered into a wipe.
 */
function adjustCoins(guildId, body, guild) {
  const amount = Number(body.amount);
  if (!Number.isInteger(amount) || amount < 0 || amount > 100_000_000) return { error: 'bad_amount' };

  const mode = ['give', 'take', 'set'].includes(body.mode) ? body.mode : null;
  if (!mode) return { error: 'bad_mode' };

  if (body.everyone) {
    if (mode === 'set') return { error: 'no_bulk_set' };
    const members = [...(guild.members?.cache?.values() || [])].filter(m => !m.user?.bot);
    if (!members.length) return { error: 'no_members' };
    for (const m of members) addCoins(m.id, mode === 'give' ? amount : -amount);
    return { ok: true, mode, amount, count: members.length };
  }

  const userId = String(body.userId || '');
  const member = guild.members?.cache?.get(userId);
  if (!member || member.user?.bot) return { error: 'bad_member' };

  const before = getBalance(userId);
  if (mode === 'set') setBalance(userId, amount);
  else addCoins(userId, mode === 'give' ? amount : -amount);

  return { ok: true, mode, amount, userId, name: member.displayName, before, after: getBalance(userId) };
}

/**
 * Clears today's lottery pool.
 *
 * Deliberately not a "draw now" button: the runner owns drawing, and a second
 * path into it would race the scheduled one and could pay a winner twice.
 * Clearing is the safe intervention — it voids a round without touching money.
 */
function clearLottery(guildId) {
  const all = readJson('lottery.json', {});
  const state = all[guildId];
  const count = Object.keys(state?.pool || {}).length;
  if (!count) return { unchanged: true };
  state.pool = {};
  writeJson('lottery.json', all);
  return { ok: true, cleared: count };
}

module.exports = {
  read, saveGroup, saveLevels, saveLevelRole, saveLevelBadge, resetAllLevels,
  createSchedule, saveSchedule, saveAutoreply, adjustCoins, clearLottery,
  GROUPS, CONFIG_GROUPS, LEVEL_FIELDS, FREQUENCIES, FREQUENCY_VALUES,
};

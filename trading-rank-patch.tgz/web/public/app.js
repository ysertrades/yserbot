'use strict';

/* Control panel front-end. No framework, no build step.
   Every value shown here comes from Discord or from typed input, so nothing is
   ever assigned as HTML — el() builds nodes and sets textContent. */

const $ = sel => document.querySelector(sel);
const root = document.documentElement;

const LOGIN_ERRORS = {
  bad_state:    'That login link expired. Try again.',
  no_access:    'That account does not manage a server this bot is in.',
  login_failed: 'Discord rejected the login. Try again.',
};

const WRITE_ERRORS = {
  bad_channel:     'Pick a text channel that still exists.',
  bad_scope:       'Pick today, tomorrow or this week.',
  missing_permissions: 'I need Send Messages and Embed Links in that channel.',
  calendar_unavailable: 'The calendar source is not answering. Try again in a few minutes.',
  nothing_to_post: 'Nothing is scheduled for that range.',
  no_question:     'Give the poll a question.',
  question_too_long: 'That question is too long for a Discord embed.',
  need_two_options: 'A poll needs at least two options.',
  too_many_options: 'Five options is the most Discord fits on one row.',
  option_too_long: 'One of the options is too long.',
  unknown_poll:    'That poll is no longer listed.',
  need_response_embed:    'Pick the message this button should show privately.',
  unknown_response_embed: 'That message no longer exists — pick another.',
  bad_mention:     'Pick a role that still exists, or @everyone / @here.',
  bad_time:        'Give a time as HH:MM, or a gap from now like 2h.',
  bad_date:        'That is not a real date — pick one from the calendar.',
  past_date:       'That day and time have already gone by. Pick a later one.',
  bad_frequency:   'Pick how often it should post.',
  unknown_schedule: 'That scheduled post is no longer listed.',
  not_a_member:    'That account is not a member of that server.',
  unknown_grant:   'That access grant is no longer listed.',
  unknown_guild:   'The bot is not in that server.',
  bad_user:        'That is not a Discord account id.',
  no_sources:      'Keep at least one news source.',
  bad_price:       'Price must be a whole number.',
  bad_choice:      'Pick a valid option from the list.',
  bad_number:      'That number is outside the range this setting allows.',
  bad_weight:      'A rarity weight has to be between 0 and 1000.',
  bad_rarity:      'Could not read the rarity table.',
  bad_cards:       'Could not read the card list.',
  no_weight:       'Give at least one rarity a weight above zero, or nothing could drop.',
  no_cards:        'Leave at least one card switched on.',
  bad_color:       'Colour needs to be a 6-digit hex code.',
  bad_csrf:        'Your session expired. Reload the page.',
  forbidden:       'You cannot change that server.',
  bad_username:    'Bot name must be 2–32 characters.',
  bad_bio:         'Bio must be 190 characters or less.',
  bad_avatar:      'Upload a PNG, JPG, WebP or GIF image.',
  bad_nickname:    'Nickname must be 32 characters or less.',
  username_rate_limited: 'Discord is rate-limiting username changes. Try again later.',
  missing_permission: 'The bot needs permission to change its nickname here.',
  discord_rejected: 'Discord rejected that change.',
  nothing_to_change: 'Nothing to save.',
  bad_status:      'Pick a valid status mode.',
  bad_activity:    'Status text must be 128 characters or less.',
  body_too_large:  'That upload is too large. Try a smaller image.',
  unknown_giveaway: 'That giveaway is no longer listed.',
  channel_gone:    'The channel that giveaway was posted in is gone.',
  message_deleted: 'The giveaway message was deleted, so there is nothing to end.',
  end_failed:      'Could not end that giveaway.',
  reroll_failed:   'Could not reroll that giveaway.',
  launch_failed:   'Could not start that giveaway.',
  all_jobs_closed: 'Leave at least one job hiring.',
  min_above_max:   'The lowest value is above the highest.',
  bad_duration:    'Use a duration like 30s, 10m, 6h or 2d.',
  empty_window:    'Boost hour needs a start and an end that differ.',
  bad_image:       'The image must be a link starting with https, or one of the generated banners.',
  bad_thumbnail:   'The thumbnail must be a link starting with https — generated banners are too wide to use as one.',
  bad_footerIcon:  'The footer icon must be a link starting with https.',
  bad_authorIcon:  'The author icon must be a link starting with https.',
  bad_titleUrl:    'The title link must start with https.',
  bad_authorUrl:   'The author link must start with https.',
  unknown_template: 'That template no longer exists.',
  unknown_activity: 'That is not something the economy knows about.',
  unknown_group:   'That settings group no longer exists.',
};

// Inside someone else's iframe the session cookie may never be sent — Safari
// drops third-party cookies entirely. The popup login hands the same signed
// token back through postMessage, and it rides in a header from then on.
const embedded = window.self !== window.top;

// Kept so you are not signing in every time the panel opens.
//
// Inside a third-party iframe this is not reliable on its own: Safari's
// Prevent Cross-Site Tracking — on by default — can block localStorage in an
// embedded frame outright, and setItem simply throws. That is why the login
// never stuck inside Whop, and why storageWorks is tracked rather than the
// failure being swallowed: if the store is unavailable the panel falls back to
// asking for storage access instead of silently making you sign in again.
const STORE_KEY = 'yserflow.session';
let storageWorks = true;

const remember = t => {
  try {
    if (t) localStorage.setItem(STORE_KEY, t);
    else localStorage.removeItem(STORE_KEY);
    storageWorks = true;
  } catch {
    storageWorks = false;
  }
};

const recall = () => {
  try { return localStorage.getItem(STORE_KEY); }
  catch { storageWorks = false; return null; }
};


/**
 * Asks the browser to let this frame use its own first-party storage.
 *
 * This is the Storage Access API, which exists for exactly this situation: an
 * embedded frame that legitimately owns a session on its own domain. Granting
 * it makes the SameSite=None cookie start being sent, so the session persists
 * across closing and reopening the host app without another Discord round
 * trip. It must be called from a real user gesture, which is why it hangs off
 * the sign-in button rather than running on load.
 */
async function requestStorage() {
  try {
    if (typeof document.hasStorageAccess !== 'function') return false;
    if (await document.hasStorageAccess()) return true;
    await document.requestStorageAccess();
    storageWorks = true;
    return true;
  } catch {
    return false;
  }
}

/**
 * The last resort, on browsers old enough to drop a partitioned cookie and
 * strict enough to block localStorage in a frame.
 *
 * It is a button rather than something automatic because requestStorageAccess
 * only resolves from a real user gesture — and because a permission prompt
 * nobody asked for is worse than one attached to something they tapped. It
 * shows up only once the panel is open and both quiet mechanisms have already
 * failed, so most people never see it.
 */
function offerStorageAccess() {
  if (!embedded || storageWorks) return;
  if (document.querySelector('.storage-nudge')) return;

  const note = el('div', 'panel storage-nudge');
  note.append(el('p', 'muted', 'Your browser is blocking this panel from remembering you here, so you will have to sign in again next time.'));
  const btn = el('button', 'btn', 'Keep me signed in');
  btn.addEventListener('click', async () => {
    btn.textContent = 'Asking…';
    const ok = await requestStorage();
    if (ok) { remember(state.token); }
    if (storageWorks) note.remove();
    else btn.textContent = 'Not allowed — try again';
  });
  note.append(btn);
  $('#server').before(note);
}

// A token riding in the URL, from a Whop embed link. This is Whop's own
// settings reloading the same URL every time the app opens, not anything the
// browser remembered — so it takes priority over whatever storage did or
// didn't manage to hold onto.
const urlToken = new URLSearchParams(location.search).get('t');
if (urlToken) {
  const clean = new URL(location.href);
  clean.searchParams.delete('t');
  history.replaceState(null, '', clean.pathname + clean.search + clean.hash);
}

const state = {
  csrf: null, token: urlToken || recall(), guildId: null, guilds: [], overview: null,
  me: null,                             // who is signed in, for {user} previews
  templates: [], tpl: null, copy: {},   // Studio
  tplName: null, draft: null,           // Composer
  styleKey: null,                       // Appearance — the message being edited
  socialDraft: null,                    // Social — the account being added
  socialTests: {},                       // Social — the result of each account's Test
  liveOn: false,                        // whether the push stream is connected
  socialOpen: new Set(),                // Social — which account cards are open
  openFolds: new Set(),                 // which fold-away sections are open
  gawBump: null,                        // redraw the giveaway preview on demand
};


/* ── dom helpers ───────────────────────────────────────────────────────── */

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function row(label, value, { dim = false } = {}) {
  const r = el('div', 'row');
  r.append(el('span', 'k', label));
  r.append(value instanceof Node ? value : el('span', `v${dim ? ' dim' : ''}`, value));
  return r;
}

const pill = (on, onText = 'On', offText = 'Off') =>
  el('span', `pill ${on ? 'on' : 'off'}`, on ? onText : offText);

function chips(items) {
  const wrap = el('div', 'chips');
  if (!items.length) { wrap.append(el('span', null, 'none')); return wrap; }
  for (const it of items) {
    const isObj = typeof it === 'object';
    const span = el('span', isObj && it.known === false ? 'unknown' : null, isObj ? it.label : it);
    if (isObj && it.known === false) span.title = 'This source is no longer available';
    wrap.append(span);
  }
  return wrap;
}

const num = n => Number(n || 0).toLocaleString();

function duration(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
  return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m`;
}

let toastTimer;
function toast(message, kind = '') {
  const t = $('#toast');
  t.textContent = message;
  t.className = `toast ${kind}`;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 3200);
}

/* ── network ───────────────────────────────────────────────────────────── */

const authHeaders = () => (state.token ? { authorization: `Bearer ${state.token}` } : {});

async function get(path) {
  const res = await fetch(path, { credentials: 'same-origin', headers: authHeaders() });
  if (!res.ok) {
    const err = new Error(`${path} → ${res.status}`);
    err.status = res.status;
    err.body = await res.json().catch(() => ({}));
    throw err;
  }
  return res.json();
}

/**
 * @param {object} opts
 *   quiet — no "Saved" toast. For the operations that read rather than write:
 *           testing a feed and checking the bridge both go through this
 *           endpoint, and telling somebody their change was saved when they
 *           pressed Test is simply untrue.
 */

async function sendDropPrize(shortId, text) {
  const body = { shortId, text: String(text || '').trim() };
  if (!body.text) { toast('Enter the prize message or code first.', 'bad'); return; }
  const res = await post('giveawaysendprize', body);
  if (res?.ok) toast(`Prize DM sent (${res.sent}/${res.total}).`, 'good');
}

async function post(op, body, { quiet = false } = {}) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), 12000) : null;
  let res;
  try {
    res = await fetch(`/api/guild/${state.guildId}/${op}`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'content-type': 'application/json', 'x-csrf-token': state.csrf, ...authHeaders() },
      body: JSON.stringify(body),
      signal: ctrl?.signal,
    });
  } catch (e) {
    if (timer) clearTimeout(timer);
    toast(e?.name === 'AbortError' ? 'Save timed out — try again.' : 'Network error — try again.', 'bad');
    return null;
  }
  if (timer) clearTimeout(timer);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    // Always surface the real reason. A bare "did not save" hides forbidden,
    // rate limits, Discord rejections, and missing ops after a partial deploy.
    const known = WRITE_ERRORS[data.error];
    const code = data.error ? String(data.error) : `http_${res.status}`;
    const why = typeof data.detail === 'string' && data.detail.trim() ? data.detail.trim() : null;
    toast([known || `That change did not save (${code}).`, why].filter(Boolean).join(' — '), 'bad');
    console.warn('[Panel write failed]', op, res.status, data);
    return null;
  }
  if (data.unchanged) { if (!quiet) toast('Nothing to change.'); return data; }
  if (!quiet) {
    const SUCCESS = {
      giveawaystart:        'Giveaway launched — members can enter now.',
      giveawayend:          'Giveaway ended — drawing winners.',
      giveawayreroll:       'New winner drawn.',
      giveawaydelete:       'Giveaway removed.',
      giveawaysendprize:    'Prize message sent.',
      giveawayclearhistory: 'Giveaway history cleared.',
      featuretoggles:       'Features updated for this server.',
      settings:             'Server settings saved.',
      econpost:             'Calendar post sent to the channel.',
      econcal:              'Calendar settings saved.',
      warnsettings:         'Warning settings saved.',
      economyglobal:        'Economy dials updated.',
    };
    let msg = SUCCESS[op];
    if (!msg && op.startsWith('bot-profile')) msg = 'Profile saved.';
    if (!msg && data.changed && Array.isArray(data.changed) && data.changed.length)
      msg = `Saved: ${data.changed.join(', ')}.`;
    if (!msg) msg = 'Saved.';
    toast(msg, 'good');
  }
  if (data.featureToggles && state.overview) {
    state.overview.featureToggles = data.featureToggles;
    try { syncFeatureNav(); } catch {}
  }
  if (data.overview) {
    state.overview = data.overview;
    renderOverview();
  } else if (/^giveaway/.test(op)) {
    /* Fallback live update when the write op did not return a full overview */
    try {
      const fresh = await get(`/api/guild/${state.guildId}`);
      if (fresh?.guild?.id === state.guildId) {
        state.overview = fresh;
        renderGiveaways();
        // Never rebuild the launch form from a live tick — preserves typed fields

      }
    } catch (e) { console.warn('[panel] giveaway refresh', e); }
  } else if (state.overview?.botProfile) {
    // Lightweight profile responses without a full overview rebuild.
    if (data.global) state.overview.botProfile.global = { ...state.overview.botProfile.global, ...data.global };
    if (data.guild)  state.overview.botProfile.guild  = { ...state.overview.botProfile.guild,  ...data.guild };
    if (data.presence) state.overview.botProfile.presence = data.presence;
    if (data.global || data.guild || data.presence) renderBotProfile();
  }
  return data;
}

/* ── the sheet ─────────────────────────────────────────────────────────────
   A single overlay shared by the giveaway detail and the embed preview.

   Focus is moved into it and restored on close, and Escape / the scrim / the
   close button all dismiss it — a modal that traps you is worse than no modal.
   `onClose` is how a caller cleans up after itself (revoking an object URL,
   say) no matter which of those three routes was taken. */

let sheetReturnFocus = null;
let sheetOnClose = null;

function closeSheet() {
  const wrap = $('#sheet');
  if (wrap.hidden) return;
  wrap.hidden = true;
  $('#sheet-body').replaceChildren();
  $('#sheet-actions').replaceChildren();
  const after = sheetOnClose;
  sheetOnClose = null;
  try { sheetReturnFocus?.focus?.(); } catch { /* the element may be gone */ }
  sheetReturnFocus = null;
  after?.();
}

/**
 * @param {string} title
 * @param {Node[]} body    rows to show
 * @param {Node[]} actions buttons for the footer
 * @param {Function} [onClose]
 */
function openSheet(title, body, actions = [], onClose = null) {
  const wrap = $('#sheet');
  sheetReturnFocus = document.activeElement;
  sheetOnClose = onClose;
  $('#sheet-title').textContent = title;
  $('#sheet-body').replaceChildren(...body);
  $('#sheet-actions').replaceChildren(...actions);
  wrap.hidden = false;
  // The close button is the one control guaranteed to exist, so it is the
  // safe place to land focus.
  $('#sheet-close').focus();
}

function initSheet() {
  $('#sheet-close').addEventListener('click', closeSheet);
  $('#sheet-scrim').addEventListener('click', closeSheet);
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && !$('#sheet').hidden) closeSheet();
  });
}

/**
 * Asks before doing something, without window.confirm.
 *
 * confirm() is unusable here. Inside Whop's app the panel runs in a native
 * WKWebView, and a WKWebView only shows a JavaScript dialog if the host app
 * implements the delegate for it — Whop's does not, so confirm() returns false
 * the instant it is called. Every `if (!confirm(...)) return;` in this file was
 * therefore a button that did nothing at all inside the embed, with no error
 * and nothing in the console to explain it.
 *
 * This is the same sheet everything else uses, so it works wherever the panel
 * renders at all.
 *
 * @returns {Promise<boolean>}
 */
function isEditingPanel() {
  const a = document.activeElement;
  if (!a || a === document.body || a === document.documentElement) return false;
  const tag = (a.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
  if (a.isContentEditable) return true;
  // focused inside a form / sheet field
  if (a.closest && (a.closest('form') || a.closest('.field') || a.closest('#sheet'))) return true;
  return false;
}

function askConfirm({ title, message, confirmLabel = 'Confirm', danger = false }) {
  // Nested overlay — never replaces the current sheet (e.g. Participants).
  return new Promise(resolve => {
    let answered = false;
    const finish = (value) => {
      if (answered) return;
      answered = true;
      try { overlay.remove(); } catch {}
      document.removeEventListener('keydown', onKey);
      resolve(value);
    };

    const overlay = el('div', 'confirm-overlay');
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');

    const card = el('div', 'confirm-card');
    card.append(el('h3', 'confirm-title', title || 'Confirm'));
    if (message) card.append(el('p', 'confirm-msg muted', message));

    const actions = el('div', 'confirm-actions');
    const cancel = el('button', 'btn', 'Cancel');
    cancel.type = 'button';
    cancel.addEventListener('click', () => finish(false));
    const go = el('button', `btn ${danger ? 'danger' : 'primary'}`, confirmLabel);
    go.type = 'button';
    go.addEventListener('click', () => finish(true));
    actions.append(cancel, go);
    card.append(actions);
    overlay.append(card);

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) finish(false);
    });
    const onKey = (e) => {
      if (e.key === 'Escape') finish(false);
    };
    document.addEventListener('keydown', onKey);

    document.body.append(overlay);
    go.focus();
  });
}

/** A labelled row for sheet bodies, matching the panel's own row styling. */
function sheetRow(label, value) {
  const r = el('div', 'row');
  r.append(el('span', 'k', label));
  r.append(value instanceof Node ? value : el('span', 'v', String(value)));
  return r;
}


/* ── screens ───────────────────────────────────────────────────────────── */

function showLogin() {
  if (embedded) wireEmbeddedLogin();

  const code = new URLSearchParams(location.search).get('error');
  if (code) {
    const p = $('#login-error');
    p.textContent = LOGIN_ERRORS[code] || 'Login failed.';
    p.classList.remove('soft');
    p.hidden = false;
  } else if (embedded) {
    // Set expectations before the tab switch, rather than leaving you looking
    // at a page that appears to have done nothing.
    const p = $('#login-error');
    p.textContent = 'This opens Discord in a new tab. Come back here once it says you are signed in.';
    p.classList.add('soft');
    p.hidden = false;
  }
  root.dataset.state = 'login';
}

/**
 * The sign-in button inside a host page.
 *
 * It has to stay a plain link. Opening the login from JavaScript works only
 * while the click's user activation is still live, and every `await` in front
 * of it spends that activation — the browser then blocks the new tab without
 * saying anything, so the panel sat on "Waiting for Discord…" while nothing
 * had actually opened. Building the href up front lets the browser perform the
 * navigation itself, which no amount of asynchronous work beforehand can
 * cancel. The handler is left with one job: start collecting the result.
 *
 * The handoff id has to be minted here for the same reason — it is part of the
 * URL the browser is about to follow.
 */
function wireEmbeddedLogin() {
  const link = document.querySelector('.view[data-view="login"] a.btn.primary[href="/auth/login"]');
  if (!link || link.dataset.wired) return;
  link.dataset.wired = '1';

  const id = (crypto.randomUUID?.() || String(Math.random()).slice(2) + Date.now()).replace(/-/g, '');
  link.href = `/auth/login?popup=1&h=${id}`;
  link.target = '_blank';
  // Deliberately no rel="noopener": where the opener does survive, the login
  // page posts the session straight back and the poll never has to run.

  link.addEventListener('click', () => pollHandoff(id));
}

/**
 * Collecting the session the login tab leaves behind.
 *
 * On iOS the login opens a whole new Safari tab with no opener relationship,
 * so postMessage has nobody to reach. The page therefore hands a random id to
 * the login and polls for the finished session against that id. postMessage
 * still works when there is an opener; this is the path that works when there
 * isn't.
 */
let handoffTimer = null;

function pollHandoff(id) {
  const started = Date.now();
  clearInterval(handoffTimer);
  const status = $('#login-error');
  status.hidden = false;
  status.classList.add('soft');
  status.textContent = 'Waiting for Discord… you can come back to this tab once it says you are signed in.';

  handoffTimer = setInterval(async () => {
    if (Date.now() - started > 120000) {
      clearInterval(handoffTimer);
      status.textContent = 'That took too long. Tap sign in to try again.';
      return;
    }
    try {
      const res = await fetch(`/auth/handoff?h=${id}`, { credentials: 'same-origin' });
      if (res.status !== 200) return;
      const { token } = await res.json();
      if (!token) return;
      clearInterval(handoffTimer);
      status.hidden = true;
      state.token = token;
      remember(token);
      // The first /api/me carrying this token is what plants the partitioned
      // cookie, which is what makes the session outlive the app being closed.
      main().catch(() => {});
    } catch { /* keep polling */ }
  }, 1500);
}

function showSetup(missing) {
  $('#setup-missing').replaceChildren(...missing.map(k => el('li', null, k)));
  root.dataset.state = 'setup';
}

function discordAvatarUrl(user) {
  if (user?.avatar) {
    return `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=64`;
  }
  let idx = 0;
  try { idx = Number(BigInt(user.id) >> 22n) % 6; }
  catch { idx = Number(String(user?.id || '0').slice(-1)) % 6; }
  return `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
}

function renderIdentity(user) {
  const wrap = $('#bar-right');
  wrap.replaceChildren();
  if (user) {
    const img = el('img');
    img.src = discordAvatarUrl(user);
    img.alt = '';
    img.referrerPolicy = 'no-referrer';
    img.onerror = () => { img.style.display = 'none'; };
    wrap.append(img);
  }
  wrap.append(el('span', 'who', user?.name || 'You'));
  const out = el('a', 'btn small', 'Sign out');
  // Still an anchor, so a browser with no JavaScript can sign out of a cookie
  // session by following it. With JavaScript the click is taken over below,
  // because a plain navigation sends only the cookie — and the session that
  // most needs ending is often the one living purely in a bearer token.
  out.href = '/auth/logout';
  out.addEventListener('click', async (e) => {
    e.preventDefault();
    out.textContent = 'Signing out…';
    try {
      // Carries the token, so the server knows whose sessions to revoke even
      // when no cookie was ever set. Revocation is what makes this stick: the
      // stored token is dead server-side before the page reloads, so a copy
      // that survived in storage — or in a host app's saved URL — cannot sign
      // anyone back in.
      await fetch('/auth/logout', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { ...authHeaders(), 'x-csrf-token': state.csrf || '' },
      });
    } catch { /* the local clear and the reload below still happen */ }
    state.token = null;
    remember(null);
    // replace(), not assign(): Back must not return to a panel rendered from
    // the state this page still has in memory.
    location.replace('/');
  });
  wrap.append(out);
}

function renderGuildPicker() {
  // Keep pill icons in sync with the live overview crest when available.
  if (state.overview?.guild?.id && state.overview.guild.icon) {
    const live = state.guilds.find(x => x.id === state.overview.guild.id);
    if (live) live.icon = state.overview.guild.icon;
  }
  $('#guilds').replaceChildren(...state.guilds.map(g => {
    const b = el('button');
    b.type = 'button';
    if (g.icon) {
      const i = el('img');
      i.src = g.icon;
      i.alt = '';
      i.referrerPolicy = 'no-referrer';
      i.loading = 'lazy';
      i.onerror = () => { i.remove(); };
      b.append(i);
    } else {
      const ph = el('span', 'guild-ico-fallback');
      ph.textContent = (g.name || '?').slice(0, 1).toUpperCase();
      b.append(ph);
    }
    b.append(el('span', null, g.name));
    if (g.id === state.guildId) b.setAttribute('aria-current', 'true');
    b.addEventListener('click', () => selectGuild(g.id));
    return b;
  }));
}

/* ── overview ──────────────────────────────────────────────────────────── */

function tile(value, label, kind = '') {
  const t = el('div', `tile ${kind}`);
  t.append(el('div', 'n', value), el('div', 'l', label));
  return t;
}

/**
 * The tiles, updated in place.
 *
 * They used to be rebuilt with replaceChildren on every repaint, and the
 * stylesheet plays a staggered entrance on `.tiles > *`. So every repaint put
 * all six back to opacity 0 and cascaded them in again over about 380ms —
 * measurably: 140ms of a completely blank row, then one tile at a time. Once
 * is an entrance. On every overview the live stream pushes it is a flicker,
 * and on a busy server, where updates arrive closer together than the cascade
 * takes to finish, the later tiles never reach full opacity at all. That is
 * the row that looks empty until you open the panel again.
 *
 * So the elements are built once and kept. After that only the number and the
 * state class change, which means the entrance plays exactly when something
 * entered, and an update is just the digits moving.
 */
function paintTiles(specs) {
  const host = $('#tiles');
  const live = [...host.children].filter(c => !c.classList.contains('ph'));
  // Switching servers is new content, not an update to what is on screen, so
  // it earns the entrance the same way the first load does.
  const arrived = host.dataset.guild !== state.guildId || live.length !== specs.length;
  host.dataset.guild = state.guildId || '';

  if (arrived) {
    host.replaceChildren(...specs.map(s => tile(s.value, s.label, s.kind)));
    return;
  }

  specs.forEach((s, i) => {
    const t = live[i];
    const n = t.firstElementChild;
    const next = String(s.value);
    if (n.textContent !== next) {
      n.textContent = next;
      // Only on a real change, so a repaint that altered nothing stays
      // perfectly still. Restarting the class is what lets it run twice.
      n.classList.remove('ticked');
      void n.offsetWidth;
      n.classList.add('ticked');
    }
    const cls = `tile ${s.kind}`.trim();
    if (t.className !== cls) t.className = cls;
  });
}

/**
 * The read-only half of the overview screen: identity, tiles, the two cards.
 *
 * Split out because the live stream repaints these on every change and must
 * not go near a form while it is being filled in.
 */

function memberRankLabel(m) {
  if (m.isOwner) return 'Owner';
  if (m.isAdmin) return 'Admin';
  return null;
}

function rolePill(r, { removable = false, onRemove = null } = {}) {
  const chip = el('span', 'role-pill');
  const color = r.color || null;
  if (color) {
    chip.style.setProperty('--role-c', color);
    chip.classList.add('has-color');
  }
  const dot = el('span', 'role-pill-dot');
  if (color) dot.style.background = color;
  chip.append(dot, document.createTextNode(r.name || 'role'));
  if (removable && onRemove) {
    const rm = el('button', 'role-pill-x', '\u00d7');
    rm.type = 'button';
    rm.title = 'Remove role';
    rm.addEventListener('click', (e) => {
      e.stopPropagation();
      onRemove();
    });
    chip.append(rm);
  }
  return chip;
}

function memberSearchScore(m, q) {
  if (!q) return 1;
  const name = String(m.displayName || m.name || '').toLowerCase();
  const user = String(m.username || '').toLowerCase();
  const id = String(m.id || '');
  const roles = ((m.roles || []).map(r => String(r.name || '').toLowerCase())).join(' ');
  const tokens = q.split(/\s+/).filter(Boolean);
  if (!tokens.length) return 1;

  let score = 0;
  for (const tok of tokens) {
    if (name.startsWith(tok)) score += 40;
    else if (name.includes(tok)) score += 20;
    else if (user.startsWith(tok)) score += 35;
    else if (user.includes(tok)) score += 18;
    else if (id.includes(tok)) score += 10;
    else if (roles.includes(tok)) score += 8;
    else return 0;
  }
  return score;
}

function renderMembersRoster(filter = null) {
  const host = document.getElementById('members-roster');
  const countEl = document.getElementById('members-count');
  const search = document.getElementById('members-search');
  if (!host) return;

  const members = state.overview?.features?.members || [];
  const q = (filter != null ? String(filter) : (search?.value || '')).trim().toLowerCase();
  let shown;
  if (!q) {
    shown = members.slice();
  } else {
    shown = members
      .map(m => ({ m, s: memberSearchScore(m, q) }))
      .filter(x => x.s > 0)
      .sort((a, b) => b.s - a.s)
      .map(x => x.m);
  }

  if (countEl) {
    countEl.textContent = q
      ? String(shown.length) + ' / ' + String(members.length)
      : String(members.length);
  }

  if (!members.length) {
    host.replaceChildren(el('div', 'muted members-empty', 'No members loaded yet \u2014 refresh in a moment.'));
    return;
  }
  if (!shown.length) {
    host.replaceChildren(el('div', 'muted members-empty', 'No members match that search.'));
    return;
  }

  const list = el('div', 'members-list');
  for (const m of shown) {
    const row = el('div', 'member-row' + (m.isOwner ? ' is-owner' : m.isAdmin ? ' is-admin' : ''));
    const av = el('div', 'member-av');
    if (m.avatar) {
      const img = el('img');
      img.src = m.avatar;
      img.alt = '';
      av.append(img);
    } else {
      av.append(el('span', null, (m.name || '?').slice(0, 1).toUpperCase()));
    }
    row.append(av);

    const info = el('div', 'member-info');
    const nameLine = el('div', 'member-name');
    nameLine.append(document.createTextNode(m.displayName || m.name || m.id));
    const rank = memberRankLabel(m);
    if (rank) nameLine.append(el('span', 'member-rank', rank));
    info.append(nameLine);
    if (m.username) info.append(el('div', 'member-user', '@' + m.username));

    const roleRow = el('div', 'member-roles');
    const roles = (m.roles || []).slice(0, 5);
    for (const r of roles) roleRow.append(rolePill(r));
    if ((m.roles || []).length > 5) {
      roleRow.append(el('span', 'role-pill more', '+' + String((m.roles.length) - 5)));
    }
    if (roles.length) info.append(roleRow);
    row.append(info);

    const check = el('button', 'btn small member-check', 'Check');
    check.type = 'button';
    check.addEventListener('click', (e) => {
      e.stopPropagation();
      openMemberPad(m);
    });
    row.append(check);
    list.append(row);
  }
  host.replaceChildren(list);
}

function bindMembersSearch() {
  const search = document.getElementById('members-search');
  if (!search) return;
  if (search.dataset.bound) return;
  search.dataset.bound = '1';
  let timer = null;
  const run = () => {
    clearTimeout(timer);
    timer = setTimeout(() => renderMembersRoster(search.value), 40);
  };
  search.addEventListener('input', run);
  search.addEventListener('search', run);
  search.addEventListener('keyup', run);
}

function formatAccountAge(ts) {
  if (ts == null || ts === '') return null;
  const ms = Date.now() - Number(ts);
  if (!Number.isFinite(ms) || ms < 0) return null;
  const days = Math.floor(ms / 86400000);
  if (days < 1) {
    const hours = Math.floor(ms / 3600000);
    return hours <= 1 ? 'just now' : (hours + 'h old');
  }
  if (days < 30) return days + 'd old';
  if (days < 365) {
    const mo = Math.floor(days / 30);
    return mo === 1 ? '1 month old' : (mo + ' months old');
  }
  const y = Math.floor(days / 365);
  const rem = Math.floor((days % 365) / 30);
  if (rem <= 0) return y === 1 ? '1 year old' : (y + ' years old');
  return y + 'y ' + rem + 'mo old';
}

function formatCalendarDate(ts, opts) {
  const d = new Date(Number(ts));
  if (isNaN(d.getTime())) return null;
  try {
    return d.toLocaleDateString(undefined, opts);
  } catch {
    return d.toISOString().slice(0, 10);
  }
}

function formatJoinedLine(ts) {
  if (ts == null || ts === '') return null;
  const abs = formatCalendarDate(ts, { day: 'numeric', month: 'short', year: 'numeric' });
  if (!abs) return null;
  let rel = null;
  try {
    if (typeof relativeTime === 'function') {
      const r = relativeTime(ts);
      if (typeof r === 'string' && r.trim() && r !== '[]') rel = r.trim();
    }
  } catch (_) {}
  return rel ? (abs + ' · ' + rel) : abs;
}

function openMemberPad(m) {
  const roles = roleList();
  const memberRoles = new Set((m.roles || []).map(r => r.id));

  const head = el('div', 'member-pad-hero');
  const av = el('div', 'member-pad-av');
  if (m.avatar) {
    const img = el('img');
    img.src = m.avatar.replace('size=64', 'size=128');
    img.alt = '';
    av.append(img);
  } else {
    av.append(el('span', null, (m.name || '?').slice(0, 1).toUpperCase()));
  }
  head.append(av);

  const meta = el('div', 'member-pad-meta');
meta.append(el('div', 'member-pad-name', m.displayName || m.name || m.id));
  if (m.username) meta.append(el('div', 'member-pad-user', '@' + m.username));
  const rank = memberRankLabel(m);
  if (rank) meta.append(el('span', 'member-rank', rank));

  const timeline = el('div', 'member-pad-timeline');
  const joinedLine = formatJoinedLine(m.joinedAt);
  const ageLine = formatAccountAge(m.accountCreatedAt);
  const joinCard = el('div', 'member-pad-time-card');
  joinCard.append(
    el('span', 'member-pad-time-k', 'Joined server'),
    el('span', 'member-pad-time-v', (typeof joinedLine === 'string' && joinedLine) || 'Unknown'),
  );
  const ageCard = el('div', 'member-pad-time-card');
  let ageDetail = (typeof ageLine === 'string' && ageLine) || 'Unknown';
  if (typeof ageLine === 'string' && ageLine && m.accountCreatedAt) {
    const since = formatCalendarDate(m.accountCreatedAt, { month: 'short', year: 'numeric' });
    if (since) ageDetail = ageLine + ' · since ' + since;
  }
  ageCard.append(
    el('span', 'member-pad-time-k', 'Account age'),
    el('span', 'member-pad-time-v', ageDetail),
  );
  timeline.append(joinCard, ageCard);
  meta.append(timeline);

  head.append(meta);

  const body = [head];

  const roleWrap = el('div', 'member-pad-roles');
  roleWrap.append(el('div', 'member-pad-label', 'Roles'));
  const chips = el('div', 'member-pad-chips');
  const current = (m.roles || []);
  if (!current.length) {
    chips.append(el('span', 'muted', 'No roles'));
  } else {
    for (const r of current) {
      chips.append(rolePill(r, {
        removable: true,
        onRemove: async () => {
          const out = await post('memberrole', { userId: m.id, roleId: r.id, op: 'remove' });
          if (out && out.ok) {
            m.roles = out.roles || (m.roles || []).filter(x => x.id !== r.id);
            openMemberPad(m);
            renderMembersRoster();
          }
        },
      }));
    }
  }
  roleWrap.append(chips);
  body.push(roleWrap);

  const assignable = roles.filter(r => !memberRoles.has(r.id));
  if (assignable.length) {
    const assign = el('div', 'member-pad-assign');
    assign.append(el('div', 'member-pad-label', 'Assign role'));
    const sel = el('select');
    sel.append(Object.assign(el('option'), { value: '', textContent: 'Pick a role\u2026' }));
    for (const r of assignable) {
      sel.append(Object.assign(el('option'), { value: r.id, textContent: r.name }));
    }
    const addBtn = el('button', 'btn small', 'Add');
    addBtn.type = 'button';
    addBtn.addEventListener('click', async () => {
      if (!sel.value) return;
      addBtn.disabled = true;
      const out = await post('memberrole', { userId: m.id, roleId: sel.value, op: 'add' });
      if (out && out.ok) {
        m.roles = out.roles || m.roles;
        openMemberPad(m);
        renderMembersRoster();
      } else {
        addBtn.disabled = false;
      }
    });
    const row = el('div', 'member-pad-assign-row');
    row.append(sel, addBtn);
    assign.append(row);
    body.push(assign);
  }

  const msgBox = el('div', 'member-pad-dm');
  msgBox.append(el('div', 'member-pad-label', 'Send a message'));
  const ta = el('textarea');
  ta.rows = 3;
  ta.placeholder = 'Write a private message the bot will DM them\u2026';
  ta.maxLength = 1800;
  const sendRow = el('div', 'member-pad-dm-row');
  const sendBtn = el('button', 'btn small primary', 'Send DM');
  sendBtn.type = 'button';
  sendBtn.addEventListener('click', async () => {
    const message = ta.value.trim();
    if (!message) return;
    sendBtn.disabled = true;
    const out = await post('memberdm', { userId: m.id, message: message });
    if (out && out.ok) ta.value = '';
    sendBtn.disabled = false;
  });
  sendRow.append(sendBtn);
  msgBox.append(ta, sendRow);
  body.push(msgBox);

  const acts = el('div', 'member-pad-actions');
  acts.append(el('div', 'member-pad-label', 'Moderation'));
  const grid = el('div', 'member-pad-grid');

  const runMod = async (action, extra) => {
    extra = extra || {};
    const reason = window.prompt('Reason for ' + action + ' (optional):', '') || '';
    const payload = Object.assign({ action: action, userId: m.id, reason: reason }, extra);
    const out = await post('modaction', payload);
    if (out && out.ok) {
      closeSheet();
      try {
        const data = await get('/api/guild/' + state.guildId);
        if (data) { state.overview = data; renderOverviewCards(); renderMembersRoster(); }
      } catch (err) {}
    } else if (out && out.error) {
      window.alert(out.detail || out.error);
    }
  };

  const mk = (label, cls, fn) => {
    const b = el('button', 'btn small ' + (cls || ''), label);
    b.type = 'button';
    b.addEventListener('click', fn);
    return b;
  };

  grid.append(
    mk('Warn', '', function() { return runMod('warn'); }),
    mk('Timeout 10m', '', function() { return runMod('timeout', { timeoutMinutes: 10 }); }),
    mk('Timeout 1h', '', function() { return runMod('timeout', { timeoutMinutes: 60 }); }),
    mk('Kick', 'danger', function() { return runMod('kick'); }),
    mk('Ban', 'danger', function() { return runMod('ban'); })
  );
  acts.append(grid);
  body.push(acts);

  openSheet(m.displayName || m.name || 'Member', body, [
    Object.assign(el('button', 'btn', 'Close'), { type: 'button', onclick: function() { closeSheet(); } }),
  ]);
}

function renderOverviewCards() {
  const d = state.overview;
  if (!d) return;

  $('#crest').replaceChildren(...(d.guild.icon
    ? [Object.assign(el('img'), { src: d.guild.icon, alt: '' })]
    : [el('span', null, d.guild.name.slice(0, 1).toUpperCase())]));
  $('#server-name').textContent = d.guild.name;
  $('#server-meta').textContent = `${num(d.guild.members)} members · ${num(d.guild.channels)} channels`;

  paintTiles([
    { value: d.econcal.enabled ? 'LIVE' : 'OFF', label: 'Calendar', kind: d.econcal.enabled ? 'live' : 'idle' },
    { value: num(d.counts.activeGiveaways), label: 'Giveaways', kind: d.counts.activeGiveaways ? 'live' : 'idle' },
    { value: num(d.counts.embedTemplates), label: 'Templates', kind: '' },
    { value: num(d.counts.moderationCases), label: 'Mod cases', kind: '' },
    { value: d.whop?.enabled ? 'ON' : 'OFF', label: 'Whop', kind: d.whop?.enabled ? 'live' : 'idle' },
    { value: num(d.guild?.members) || '—', label: 'Members', kind: '' },
  ]);

  $('#card-systems').replaceChildren(
    row('Calendar', pill(d.econcal.enabled, 'Running', 'Stopped')),
    row('Calendar channel', d.econcal.channel ? `#${d.econcal.channel}` : 'not set', { dim: !d.econcal.channel }),
    row('Whop tracker', pill(!!d.whop?.enabled, 'On', 'Off')),
    row('Mod log', d.modlog.channel ? `#${d.modlog.channel}` : 'not set', { dim: !d.modlog.channel }),
  );

  $('#card-counts').replaceChildren(
    row('Embed templates', num(d.counts.embedTemplates)),
    row('Moderation cases', num(d.counts.moderationCases)),
    row('Word filter', pill(d.automod.badWords)),
    row('Link filter', pill(d.automod.linkFilter)),
    row('Custom words', num(d.automod.customWords)),
  );

}

function renderOverview() {
  if (!state.overview) return;
  renderOverviewCards();
  bindMembersSearch();
  renderMembersRoster();
  try { syncFeatureNav(); } catch {}
  if (isEditing() || sheetIsOpen()) {
    liveMissed = true;
    return;
  }
  renderFeedForms();
  renderModerationForm();
  /* renderShop retired */
  renderComposer();
  /* Appearance editor is sticky — only rebuilt when opening the tab or
     changing which message is selected. Rebuilding it on every overview
     refresh is what made the Appearance tab flash. */
  if (root.dataset.section !== 'appearance') renderAppearance();
  else {
    const count = document.getElementById('appearance-count');
    const data = state.overview?.appearance;
    if (count && data) {
      count.textContent = data.changedCount ? `${data.changedCount} changed` : 'all default';
      count.classList.toggle('on', data.changedCount > 0);
    }
  }
  /* Social removed from panel */
  renderGiveaways();
  renderSettings();
  renderFeatureToggles();
  try { syncFeatureNav(); } catch {}
  try { syncFeatureNav(); } catch (e) { console.warn('[panel] syncFeatureNav', e); }
  renderBotProfile();
  renderPanelLog();
  renderLegalLinks();
  renderTickets();
  renderPolls();
  try { if (featureOn('casino')) renderCasino(); } catch (e) { console.warn('[panel] renderCasino', e); }
  renderLinkRequests();
  renderModeration();
  renderGroupForm('#form-lottery', 'lottery');
  renderCards();
  try { if (featureOn('economy')) renderEconomy(); } catch (e) { console.warn('[panel] renderEconomy', e); }
  /* Drop form first — must not sit behind economy renders that can throw */
  renderGiveawayForm();
  try { renderCoins(); } catch (e) { console.warn('[panel] renderCoins', e); }
  try { renderSchedules(); } catch (e) { console.warn('[panel] renderSchedules', e); }
  try { renderAutoreplies(); } catch (e) { console.warn('[panel] renderAutoreplies', e); }
  renderLevels();
  renderLevelRoles();
  renderLevelBadges();
  renderLevelsReset();
  /* rank via renderEngagement */
  
  
  
  
  try { renderLottery(); } catch (e) { console.warn('[panel] renderLottery', e); }
  startTicking();
}

function renderBoard(data) {
  const panel = $('#panel-leaderboard');
  // Economy off for the selected server: the card disappears entirely
  // rather than sitting there empty or explaining itself — an admin who
  // turned coins off doesn't need a panel telling them so a second time.
  if (panel) panel.style.display = data.economyOff ? 'none' : '';

  const list = $('#board');
  if (!data.entries.length) { list.replaceChildren(el('li', 'muted', 'No balances yet.')); return; }
  list.replaceChildren(...data.entries.map((e, i) => {
    const li = el('li');
    li.append(el('span', 'rank', `${i + 1}`));
    if (e.avatar) { const img = el('img'); img.src = e.avatar; img.alt = ''; li.append(img); }
    li.append(el('span', 'name', e.name), el('span', 'bal', num(e.balance)));
    return li;
  }));
}

function renderHealth(h) {
  const c = h.renderCache;
  $('#card-health').replaceChildren(
    row('Uptime', duration(h.uptimeMs)),
    row('Gateway ping', `${h.ping} ms`),
    row('Servers', num(h.guilds)),
    row('Memory', `${h.memoryMb} MB`),
    row('Cached renders', `${num(c.hits)} / ${num(c.hits + c.misses)}`),
    row('Blocking avoided', `${num(c.blockingMsAvoided)} ms`),
  );
}

/* ── forms ─────────────────────────────────────────────────────────────── */

function toggle(label, checked, onChange) {
  // Div, not <label> — only the switch control toggles, not the text.
  const row = el('div', 'toggle');
  row.append(el('span', 'toggle-text', label));
  const input = el('input');
  input.type = 'checkbox';
  input.checked = checked;
  input.addEventListener('change', () => onChange(input.checked));
  input.addEventListener('click', (e) => e.stopPropagation());
  row.append(input);
  return row;
}

function textField(label, value, onInput, { placeholder = '' } = {}) {
  const l = el('label', 'field');
  l.append(el('span', null, label));
  const input = el('input');
  input.type = 'text';
  input.value = value ?? '';
  input.placeholder = placeholder;
  input.addEventListener('input', () => onInput(input.value));
  l.append(input);
  return l;
}

/* ── durations ─────────────────────────────────────────────────────────────
   The same 10s/10m/10h/10d the slash commands take. Mirrored here rather than
   fetched so the field can validate as you type; utils/duration.js is the
   authority and rejects anything this lets through. */

const DURATION_UNIT_MS = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
const UNIT_NAME = { s: 'second', m: 'minute', h: 'hour', d: 'day' };

function parseDurationMs(str) {
  const m = String(str ?? '').trim().match(/^(\d+)([smhd])$/i);
  if (!m) return null;
  const ms = parseInt(m[1], 10) * DURATION_UNIT_MS[m[2].toLowerCase()];
  return ms > 0 ? ms : null;
}

function humanDuration(str) {
  const m = String(str ?? '').trim().match(/^(\d+)([smhd])$/i);
  if (!m) return str;
  const n = parseInt(m[1], 10);
  return `${n} ${UNIT_NAME[m[2].toLowerCase()]}${n === 1 ? '' : 's'}`;
}

/**
 * A duration input that says what it understood, so a typo is visible before
 * the giveaway is launched rather than after the server rejects it.
 */
function durationField(label, value, onInput, { hideChips = false } = {}) {
  const l = el('label', 'field');
  const head = el('div', 'field-head');
  const echo = el('span', 'count');
  head.append(el('span', null, label), echo);
  l.append(head);

  const input = el('input');
  input.type = 'text';
  input.value = value ?? '';
  input.placeholder = '30s · 10m · 6h · 2d';
  input.setAttribute('inputmode', 'text');
  input.autocapitalize = 'none';
  input.spellcheck = false;

  const sync = () => {
    const ok = parseDurationMs(input.value);
    echo.textContent = ok ? humanDuration(input.value) : 'use 10s / 10m / 10h / 10d';
    echo.className = `count${ok ? '' : ' bad'}`;
  };
  sync();
  input.addEventListener('input', () => {
    // Units are lower case; typing "10M" should still work.
    input.value = input.value.toLowerCase();
    sync();
    onInput(input.value);
  });

  l.append(input);
  // Giveaway form already has preset chips; hide these to avoid duplicates.
  if (!hideChips) {
    const chips = el('div', 'chipset');
    for (const preset of ['30s', '10m', '1h', '6h', '1d', '7d']) {
      const c = el('button', 'chip', preset);
      c.type = 'button';
      c.addEventListener('click', () => { input.value = preset; sync(); onInput(preset); });
      chips.append(c);
    }
    l.append(chips);
  }
  return l;
}

/* ── dates ─────────────────────────────────────────────────────────────── */

/** 'YYYY-MM-DD' as this browser's own calendar reads it. */
const localDate = d =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

/** Midnight today, the reference every "in N days" is counted from. */
const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };

/**
 * What a picked date says back — the weekday, and how far off it is.
 *
 * 2026-08-20 is the shape the scheduler wants and the one thing a person
 * cannot check by eye: nothing in it says Thursday, and nothing says next
 * week. This is the half the field adds.
 */
function dateEcho(value) {
  if (!value) return { text: 'no date set', bad: false };
  const [y, m, d] = String(value).split('-').map(Number);
  const picked = new Date(y, (m || 1) - 1, d || 1);
  if (isNaN(picked)) return { text: 'not a date', bad: true };

  const days = Math.round((picked - startOfToday()) / 86400000);
  const named = picked.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'short' });
  if (days < 0) return { text: `${named} — already passed`, bad: true };
  if (days === 0) return { text: `today · ${named}`, bad: false };
  if (days === 1) return { text: `tomorrow · ${named}`, bad: false };
  return { text: `${named} · in ${days} days`, bad: false };
}

/**
 * A date picker, with the days anyone actually reaches for beside it.
 *
 * <input type="date"> rather than a hand-built calendar because it is the
 * native one on every device this panel opens on — the wheel on a phone, the
 * drop-down calendar on a desktop — and it can only ever hand back a real
 * date in the exact shape the scheduler parses. `min` is today, so a date that
 * would fire the moment it was saved is not offered in the first place.
 *
 * The chips are there because today and tomorrow are most of what a one-off
 * post is ever set to, and finding today's cell in a calendar is slower than a
 * word saying so. Clear is one of them too: on an existing schedule, a blank
 * date has to stay reachable or the day could be changed but never left alone.
 */
function dateField(label, value, onInput, { note = '' } = {}) {
  const l = el('label', 'field');
  const head = el('div', 'field-head');
  const title = el('span', null, label);
  const echo = el('span', 'count');
  head.append(title, echo);
  l.append(head);

  const input = el('input');
  input.type = 'date';
  input.value = value || '';
  input.min = localDate(new Date());

  const caption = el('p', 'hint', note);
  caption.hidden = !note;

  const sync = () => {
    const { text, bad } = dateEcho(input.value);
    echo.textContent = text;
    echo.className = `count${bad ? ' bad' : ''}`;
    input.classList.toggle('bad', bad);
  };
  sync();
  const set = v => { input.value = v; sync(); onInput(v); };
  input.addEventListener('change', () => { sync(); onInput(input.value); });

  l.append(input);

  const chips = el('div', 'chipset');
  for (const [text, offsetDays] of [['Today', 0], ['Tomorrow', 1], ['Next week', 7]]) {
    const c = el('button', 'chip', text);
    c.type = 'button';
    c.addEventListener('click', () => {
      const d = startOfToday();
      d.setDate(d.getDate() + offsetDays);
      set(localDate(d));
    });
    chips.append(c);
  }
  const clear = el('button', 'chip', 'Clear');
  clear.type = 'button';
  clear.addEventListener('click', () => set(''));
  chips.append(clear);
  l.append(chips, caption);

  // The label and the caption both depend on the cadence, which is picked in a
  // different field, so the caller can move them without rebuilding the node.
  l.retitle = (text, hint) => {
    title.textContent = text;
    caption.textContent = hint || '';
    caption.hidden = !hint;
  };
  return l;
}

/**
 * @param {Function} onSave
 * @param {object}  [opts]
 *   label — for forms that do something rather than save something. A
 *   giveaway form is not saving settings, it is starting a giveaway, and
 *   "Save changes" said the wrong thing about what the button would do.
 */
function actions(onSave, { label = 'Save changes', busyLabel = null } = {}) {
  const wrap = el('div', 'actions');
  const save = el('button', 'btn primary small', label);
  save.type = 'button';
  save.addEventListener('click', async () => {
    if (save.dataset.busy === '1') return;
    save.dataset.busy = '1';
    save.disabled = true;
    save.setAttribute('aria-busy', 'true');
    save.className = 'btn primary small is-busy';
    if (busyLabel) save.textContent = busyLabel;
    try {
      await onSave();
    } finally {
      save.dataset.busy = '0';
      save.disabled = false;
      save.removeAttribute('aria-busy');
      save.className = 'btn primary small';
      save.textContent = label;
    }
  });
  wrap.append(save);
  return wrap;
}





function renderWhop() {
  const d = state.overview?.whop;
  const form = $("#form-whop");
  const list = $("#whop-courses");
  const pillEl = $("#whop-state");
  if (!form) return;
  if (!d) {
    form.replaceChildren(el("p", "muted", "Whop data not loaded yet."));
    return;
  }

  const log = Array.isArray(d.log) ? d.log : [];
  const catalog = Array.isArray(d.catalog) ? d.catalog : [];

  if (pillEl) {
    pillEl.textContent = d.enabled
      ? (log.length ? (log.length + " tracked") : "ON")
      : "OFF";
    pillEl.className = "pill " + (d.enabled && log.length ? "on" : "off");
  }

  const draft = {
    enabled: !!d.enabled,
    apiKey: "",
    unlockKey: false,
    companyId: d.companyId || "",
    pollMinutes: d.pollMinutes != null ? d.pollMinutes : 0.5,
    onlyVideos: d.onlyVideos !== false,
    buttonLabel: d.buttonLabel || "open course",
  };

  const children = [];
  children.push(toggle("Tracking on", draft.enabled, v => { draft.enabled = v; }));

  if (d.hasKey && !draft.unlockKey) {
    children.push(el("p", "hint", "API key locked · " + (d.keyMask || "••••")));
    const unlock = el("button", "btn small", "Change API key");
    unlock.type = "button";
    unlock.addEventListener("click", () => { draft.unlockKey = true; renderWhop(); });
    const row = el("div", "actions");
    row.append(unlock);
    children.push(row);
  } else {
    children.push(textField("Whop API key", draft.apiKey, v => { draft.apiKey = v; }, { placeholder: "Company / Account API key" }));
    children.push(el("p", "hint", "Saved once and locked."));
  }

  children.push(textField("Company ID", draft.companyId, v => { draft.companyId = v; }, { placeholder: "biz_…" }));
  children.push(el("p", "hint", "Required. Example: biz_61…"));
  children.push(textField("Check every (minutes)", String(draft.pollMinutes), v => { draft.pollMinutes = Number(v) || 0.5; }));
  children.push(el("p", "hint", "How often to look for new lessons. Use 0.5 for ~30s, 0.25 for ~15s (fastest)."));
  children.push(toggle("Only video lessons", draft.onlyVideos, v => { draft.onlyVideos = v; }));
  children.push(textField("Button label", draft.buttonLabel, v => { draft.buttonLabel = v; }, { placeholder: "Open course" }));
  children.push(el("p", "hint", "Each alert includes course name, course app, and banner art when available."));

  if (d.lastError) children.push(el("p", "hint bad", String(d.lastError)));
  else if (d.lastScanAt) children.push(el("p", "hint", "Last scan · " + new Date(d.lastScanAt).toLocaleString()));

  children.push(actions(async () => {
    const body = {
      enabled: draft.enabled,
      companyId: draft.companyId || null,
      pollMinutes: draft.pollMinutes,
      onlyVideos: draft.onlyVideos,
      buttonLabel: draft.buttonLabel,
    };
    if (draft.apiKey.trim()) body.apiKey = draft.apiKey.trim();
    await post("whop", body);
  }));

  form.replaceChildren(...children);

  if (!list) return;
  const blocks = [];

  /* ---- Tracking log — collapsed by default ---- */
  if (state.trackLogOpen == null) state.trackLogOpen = false;
  const trackHead = el("div", "track-log-head");
  trackHead.append(el("h3", null, "Tracking log"));
  const trackToggle = el("button", "btn small track-log-toggle", state.trackLogOpen ? "Hide" : "Show");
  trackToggle.type = "button";
  trackToggle.setAttribute("aria-expanded", state.trackLogOpen ? "true" : "false");
  trackToggle.addEventListener("click", () => {
    state.trackLogOpen = !state.trackLogOpen;
    if (typeof renderWhop === "function") renderWhop();
  });
  trackHead.append(trackToggle);
  blocks.push(trackHead);

  if (!log.length) {
    if (state.trackLogOpen) {
      blocks.push(el("p", "muted track-log-body is-open", "Empty. Add a course from the library below (course + channel)."));
    }
  } else if (!state.trackLogOpen) {
    blocks.push(el("p", "hint track-log-summary", `${log.length} course${log.length === 1 ? "" : "s"} tracked — press Show to manage channels and pings.`));
  } else {
    const pageSize = 3;
    const total = log.length;
    const pages = Math.max(1, Math.ceil(total / pageSize));
    let page = Math.max(0, state.trackLogPage || 0);
    if (page >= pages) page = pages - 1;
    state.trackLogPage = page;
    const slice = log.slice(page * pageSize, (page + 1) * pageSize);

    const desk = el("div", "track-desk");
    const grid = el("div", "track-grid");
    for (const e of slice) {
      const card = el("div", "track-card");
      const kind = e.type === 'app' ? 'Course app' : 'Course';
      card.append(
        el("p", "track-title", (e.type === 'app' ? '▦ ' : '') + (e.title || e.id)),
        el("p", "track-meta",
          kind
          + (e.experienceName && e.type !== 'app' ? (" · " + e.experienceName) : "")
          + (e.channel ? (" · #" + e.channel) : "")
          + " · " + (e.knownCount || 0) + " lessons"
          + (e.baselined ? " · live" : " · warming up")
        )
      );
      let ch = e.channelId || null;
      let role = e.mentionRoleId || null;
      card.append(pickOne("Channel", "channel", ch, v => { ch = v; }));
      card.append(pickOne("Ping role", "role", role, v => { role = v; }));
      const acts = el("div", "actions");
      const save = el("button", "btn small primary", "Save");
      save.type = "button";
      save.addEventListener("click", async () => {
        save.disabled = true;
        try {
          await post("whop", { op: "update", courseId: e.id, channelId: ch, mentionRoleId: role });
        } finally { save.disabled = false; }
      });
      const remove = el("button", "btn small", "Remove");
      remove.type = "button";
      remove.addEventListener("click", async () => {
        remove.disabled = true;
        try {
          await post("whop", { op: "remove", courseId: e.id });
          toast("Removed from log.", "good");
        } finally { remove.disabled = false; }
      });
      acts.append(save, remove);
      card.append(acts);
      grid.append(card);
    }
    desk.append(grid);
    if (pages > 1) {
      const pager = el("div", "drop-pager track-pager");
      const meta = el("div", "drop-pager-meta");
      meta.append(
        el("span", "drop-pager-label", "Tracking desk"),
        el("span", "drop-pager-count", `${page * pageSize + 1}–${Math.min((page + 1) * pageSize, total)} of ${total}`),
      );
      const dots = el("div", "drop-pager-dots");
      for (let i = 0; i < pages; i++) {
        const dot = el("button", "drop-pager-dot" + (i === page ? " on" : ""), String(i + 1));
        dot.type = "button";
        if (i === page) dot.setAttribute("aria-current", "page");
        dot.addEventListener("click", () => {
          state.trackLogPage = i;
          if (typeof renderWhop === "function") renderWhop();
        });
        dots.append(dot);
      }
      const nav = el("div", "drop-pager-nav");
      const prev = el("button", "btn small drop-pager-btn", "←");
      prev.type = "button";
      prev.disabled = page <= 0;
      prev.addEventListener("click", () => {
        if ((state.trackLogPage || 0) > 0) {
          state.trackLogPage -= 1;
          if (typeof renderWhop === "function") renderWhop();
        }
      });
      const next = el("button", "btn small drop-pager-btn", "→");
      next.type = "button";
      next.disabled = page >= pages - 1;
      next.addEventListener("click", () => {
        if ((state.trackLogPage || 0) < pages - 1) {
          state.trackLogPage += 1;
          if (typeof renderWhop === "function") renderWhop();
        }
      });
      nav.append(prev, next);
      pager.append(meta, dots, nav);
      desk.append(pager);
    }
    desk.classList.add("track-log-body", "is-open");
    blocks.push(desk);
  }

  /* ---- Single courses from scan (grouped by course app) ---- */
  blocks.push(el("h3", null, "Courses"));
  if (!catalog.length) {
    blocks.push(el("p", "muted", "No library yet. Save API key + Company ID, then press Scan courses."));
  } else {
    const available = catalog.filter(c => !c.inLog);
    blocks.push(el("p", "hint",
      catalog.length + " course(s) in library · "
      + available.length + " available to track · grouped by course app"));

    if (!available.length) {
      blocks.push(el("p", "muted", "Every scanned course is already tracked individually."));
    } else {
      // Group by course app. Missing experienceId still shows — attach to the
      // only app when there is one, otherwise a library group so Scan is never empty.
      const appList = Array.isArray(d.apps) ? d.apps : [];
      const onlyApp = appList.length === 1 ? appList[0] : null;
      const groups = new Map();
      for (const c of available) {
        let expId = c.experienceId || (onlyApp && onlyApp.id) || "_library";
        const fromApps = appList.find(a => a.id === expId);
        const label = c.experienceName
          || fromApps?.name
          || (onlyApp && onlyApp.name)
          || (d.companyTitle ? (d.companyTitle + " · courses") : "Courses");
        const key = String(expId);
        if (!groups.has(key)) groups.set(key, { label, items: [] });
        groups.get(key).items.push(c);
      }
      const ordered = [...groups.entries()].sort((a, b) => a[1].label.localeCompare(b[1].label));
      if (!ordered.length) {
        blocks.push(el("p", "muted", "Scan returned no courses. Check API key + Company ID, then Scan again."));
      }

      const groupsWrap = el("div", "whop-app-groups");
      for (const [, g] of ordered) {
        const head = el("div", "whop-app-group");
        head.append(el("div", "whop-app-group-title", g.label));
        head.append(el("p", "hint", g.items.length + " course" + (g.items.length === 1 ? "" : "s")));

        let pickId = null;
        let pickCh = null;
        let pickRole = null;
        const options = g.items.map(c => ({
          value: c.id,
          label: (c.title || c.id)
            + (c.lessonsCount != null ? (" · " + c.lessonsCount + " lessons") : ""),
        }));
        head.append(select("Course", "", options, v => { pickId = v || null; }, { blank: "Choose a course in this app…" }));
        head.append(pickOne("Channel", "channel", null, v => { pickCh = v; }));
        head.append(pickOne("Ping role (optional)", "role", null, v => { pickRole = v; }));

        const addRow = el("div", "actions");
        const addBtn = el("button", "btn primary small", "Track course");
        addBtn.type = "button";
        addBtn.addEventListener("click", async () => {
          if (!pickId) { toast("Choose a course.", "bad"); return; }
          if (!pickCh) { toast("Choose a channel.", "bad"); return; }
          addBtn.disabled = true;
          try {
            await post("whop", {
              op: "add",
              courseId: pickId,
              channelId: pickCh,
              mentionRoleId: pickRole,
            });
            toast("Course tracked.", "good");
          } finally { addBtn.disabled = false; }
        });
        addRow.append(addBtn);
        head.append(addRow);
        groupsWrap.append(head);
      }
      blocks.push(groupsWrap);
    }
  }

  list.replaceChildren(...blocks);

  const scanBtn = $("#whop-scan");
  if (scanBtn && !scanBtn.dataset.bound) {
    scanBtn.dataset.bound = "1";
    scanBtn.addEventListener("click", async () => {
      scanBtn.disabled = true;
      scanBtn.textContent = "Scanning…";
      try {
        const res = await post("whopscan", {});
        if (res && res.ok) {
          toast("Library updated · " + res.courses + " course(s).", "good");
        }
      } finally {
        scanBtn.disabled = false;
        scanBtn.textContent = "Scan courses";
      }
    });
  }
}


function renderFeedForms() {
  const d = state.overview;

  // News feed removed — Financial Juice live feed retired.

  const ec = {
    enabled: d.econcal.enabled,
    impactFilter: d.econcal.impact.slice(),
    currencyFilter: d.econcal.currencies.slice(),
    weeklyPost: { ...d.econcal.weekly },
  };
  const wp = ec.weeklyPost;

  // Everything /econcal can set, in the order the command's own panel walks
  // through it — where it goes, who gets pinged, what is included, and when
  // the week-ahead summary posts.
  const weeklyRows = [
    select('Day', String(wp.weekday), WEEKDAY_OPTIONS, v => { wp.weekday = Number(v); }),
    textField('Time (24h, HH:MM)', `${String(wp.hour).padStart(2, '0')}:${String(wp.minute).padStart(2, '0')}`, v => {
      const m = v.match(/^(\d{1,2}):(\d{2})$/);
      if (!m) return;
      wp.hour = Math.min(23, Number(m[1]));
      wp.minute = Math.min(59, Number(m[2]));
    }),
    select('Timezone', String(wp.offsetMinutes), UTC_OFFSET_OPTIONS, v => { wp.offsetMinutes = Number(v); }),
  ];
  const weeklyWrap = el('div', 'subfields');
  weeklyWrap.append(...weeklyRows);
  weeklyWrap.hidden = !wp.enabled;

  $('#form-econcal').replaceChildren(
    toggle('Calendar running', ec.enabled, v => { ec.enabled = v; }),
    pickOne('Channel', 'channel', d.econcal.channelId, v => { ec.channelId = v; }),
    pickOne('Ping this role on reminders', 'role', d.econcal.roleId, v => { ec.roleId = v; },
      { blank: 'No ping' }),
    pickValues('Impact levels', d.econcal.impactLevels || [], ec.impactFilter,
      v => { ec.impactFilter = v; }, { allNote: 'Nothing picked — every impact level is sent.' }),
    pickValues('Currencies', d.econcal.currencyCodes || [], ec.currencyFilter,
      v => { ec.currencyFilter = v; }, { allNote: 'Nothing picked — every currency is sent.' }),
    el('h2', null, 'Weekly summary'),
    toggle('Post the week ahead', wp.enabled, v => { wp.enabled = v; weeklyWrap.hidden = !v; }),
    weeklyWrap,
    actions(() => post('econcal', ec)),
  );

  renderReleaseDesk();
  renderWhop();
}

/* ── release desk ──────────────────────────────────────────────────────────
 *
 * The three scopes /econcal can post, with their contents on screen first.
 *
 * The agenda is fetched separately from the overview, on purpose: it is the
 * one read in the panel that can reach the network, and the overview must
 * never wait on the calendar mirror. So the card carries its own small
 * lifecycle — asking, loaded, or unavailable — and the rest of the tab is
 * finished long before it resolves.
 */

const SCOPE_LABEL = { today: 'Today', tomorrow: 'Tomorrow', week: 'This week' };
const SCOPE_SEND = { today: "today's releases", tomorrow: "tomorrow's releases", week: 'the week ahead' };
const IMPACT_RANK = { High: 'high', Medium: 'medium', Low: 'low', Holiday: 'holiday' };

const desk = { scope: 'today', agenda: null, loadedFor: null, error: null, loading: false };

function renderReleaseDesk() {
  const card = $('#release-desk');
  if (!card) return;

  // One fetch per server, not one per repaint — the live stream repaints this
  // tab whenever anything in the guild changes, and the calendar has not.
  if (desk.loadedFor !== state.guildId && !desk.loading) loadAgenda();

  paintDeskScopes();
  paintAgenda();
  paintDeskForm();
}

async function loadAgenda() {
  const forGuild = state.guildId;
  desk.loading = true;
  desk.error = null;
  desk.agenda = null;
  paintAgenda();
  try {
    const data = await get(`/api/guild/${forGuild}/calendar`);
    // A slow answer for a server you have since left is not an answer.
    if (forGuild !== state.guildId) return;
    desk.agenda = data;
  } catch (err) {
    if (forGuild !== state.guildId) return;
    desk.error = err.status === 503 ? 'unavailable' : 'failed';
  } finally {
    if (forGuild === state.guildId) {
      desk.loading = false;
      desk.loadedFor = forGuild;
      paintDeskScopes();
      paintAgenda();
      paintDeskForm();
    }
  }
}

function paintDeskScopes() {
  const host = $('#desk-scopes');
  host.replaceChildren(...Object.keys(SCOPE_LABEL).map(scope => {
    const b = el('button', 'scope-tab');
    b.type = 'button';
    b.setAttribute('role', 'tab');
    b.append(el('span', 'scope-name', SCOPE_LABEL[scope]));
    // The count is the number that would actually be posted — the filters are
    // applied before it is counted, so a small number here means a quiet day
    // or a strict filter, and the note under the list says which.
    const n = desk.agenda?.scopes?.[scope]?.count;
    b.append(el('span', 'scope-count', n === undefined ? '–' : num(n)));
    if (scope === desk.scope) b.setAttribute('aria-selected', 'true');
    b.addEventListener('click', () => {
      desk.scope = scope;
      paintDeskScopes();
      paintAgenda();
      paintDeskForm();
    });
    return b;
  }));

  const src = $('#desk-source');
  if (desk.loading) src.textContent = 'checking…';
  else if (desk.error) src.textContent = '';
  else if (desk.agenda) {
    const narrowed = [
      desk.agenda.impact.length ? desk.agenda.impact.join('/') : null,
      desk.agenda.currencies.length ? desk.agenda.currencies.join(' ') : null,
    ].filter(Boolean);
    src.textContent = narrowed.length ? `filtered · ${narrowed.join(' · ')}` : 'all releases';
  } else src.textContent = '';
}

/** The event time, in the timezone the weekly post is scheduled in. */
function deskTime(ts) {
  const shifted = new Date(ts + (desk.agenda?.offsetMinutes || 0) * 60000);
  const hh = String(shifted.getUTCHours()).padStart(2, '0');
  const mm = String(shifted.getUTCMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

const DESK_DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
function deskDay(ts) {
  return DESK_DAY[new Date(ts + (desk.agenda?.offsetMinutes || 0) * 60000).getUTCDay()];
}

function paintAgenda() {
  const host = $('#desk-agenda');

  if (desk.loading) {
    host.replaceChildren(...Array.from({ length: 3 }, () => {
      const s = el('div', 'skeleton');
      s.style.height = '2.4rem';
      return s;
    }));
    return;
  }
  if (desk.error) {
    host.replaceChildren(el('p', 'muted', desk.error === 'unavailable'
      ? 'The calendar source is not answering right now. Everything else on this tab still works — try again in a few minutes.'
      : 'Could not load the calendar.'));
    return;
  }

  const scope = desk.agenda?.scopes?.[desk.scope];
  if (!scope) { host.replaceChildren(); return; }
  if (scope.count === 0) {
    host.replaceChildren(el('p', 'muted', desk.scope === 'week'
      ? 'Nothing scheduled this week that matches your filters.'
      : `Nothing scheduled ${desk.scope} that matches your filters.`));
    return;
  }

  // The week runs across days, so it gets a weekday column. A single day does
  // not — repeating "Tue" down forty rows is noise.
  //
  // The cell is left out of the markup rather than hidden in CSS, and the
  // stylesheet has a matching template with no track for it. Hiding a grid
  // item does not collapse its column, it removes the item, and everything
  // after it slides one track left into the wrong width.
  const weekly = desk.scope === 'week';
  host.dataset.range = weekly ? 'week' : 'day';

  const rows = scope.events.map(e => {
    const r = el('div', 'agenda-row');
    r.append(el('span', `impact-dot ${IMPACT_RANK[e.impact] || 'low'}`));
    if (weekly) r.append(el('span', 'agenda-day', deskDay(e.timestamp)));
    r.append(el('span', 'agenda-time', deskTime(e.timestamp)));
    r.append(el('span', 'agenda-cur', e.currency || '—'));
    r.append(el('span', 'agenda-title', e.title));
    // Forecast against previous is the whole reason a release matters, so it
    // rides along where there is room rather than being a click away.
    const fig = [e.forecast && `f ${e.forecast}`, e.previous && `p ${e.previous}`].filter(Boolean).join('  ');
    r.append(el('span', 'agenda-fig', fig));
    r.title = `${e.impact} impact · ${e.currency} · ${e.title}`;
    return r;
  });

  if (scope.truncated) {
    rows.push(el('p', 'muted', `Showing the first ${scope.events.length} of ${num(scope.count)} — all of them are posted.`));
  }
  host.replaceChildren(...rows);
  // Only fade the bottom edge when there is something below it to fade to.
  host.classList.toggle('is-scrollable', host.scrollHeight > host.clientHeight + 1);
}

function paintDeskForm() {
  const form = $('#form-econpost');
  const scope = desk.agenda?.scopes?.[desk.scope];
  const sendable = !!scope && scope.count > 0;

  // Defaults to the configured calendar channel, because that is where this
  // usually goes — and stays changeable, because the week ahead often wants
  // an announcements channel the live reminders would be noise in.
  const draft = { scope: desk.scope, channelId: desk.postChannelId ?? desk.agenda?.channelId ?? null };

  const send = actions(async () => {
    // Show success toast like other panel actions
    await post('econpost', { scope: desk.scope, channelId: draft.channelId });
  }, { label: `Post ${SCOPE_SEND[desk.scope]}`, busyLabel: 'Posting…' });

  const button = send.querySelector('button');
  if (!sendable) {
    button.disabled = true;
    button.title = desk.loading ? 'Still loading the calendar' : 'Nothing to post for this range';
  }

  form.replaceChildren(
    pickOne('Post to', 'channel', draft.channelId, v => { draft.channelId = v; desk.postChannelId = v; }),
    send,
  );
}

const WEEKDAY_OPTIONS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
  .map((label, i) => ({ value: String(i), label }));

// -12:00 to +14:00 in whole hours, which covers every real UTC offset the
// scheduler accepts.
const UTC_OFFSET_OPTIONS = Array.from({ length: 27 }, (_, i) => {
  const hours = i - 12;
  return { value: String(hours * 60), label: `UTC${hours >= 0 ? '+' : ''}${hours}` };
});

function renderModerationForm() {
  const d = state.overview;
  const m = {
    badWords: d.automod.badWords,
    linkFilter: d.automod.linkFilter,
    mentionSpamProtection: d.automod.mentionSpam,
    modLog: { ...d.modlog },
  };
  delete m.modLog.channel;

  $('#form-moderation').replaceChildren(
    toggle('Word filter', m.badWords, v => { m.badWords = v; }),
    toggle('Link filter', m.linkFilter, v => { m.linkFilter = v; }),
    toggle('Mention spam protection', m.mentionSpamProtection, v => { m.mentionSpamProtection = v; }),
    el('h2', null, 'Log these events'),
    toggle('Member joins and leaves', m.modLog.members, v => { m.modLog.members = v; }),
    toggle('Message edits and deletes', m.modLog.messages, v => { m.modLog.messages = v; }),
    toggle('Role changes', m.modLog.roles, v => { m.modLog.roles = v; }),
    toggle('Purges', m.modLog.purges, v => { m.modLog.purges = v; }),
    row('Log channel', d.modlog.channel ? `#${d.modlog.channel}` : 'not set', { dim: !d.modlog.channel }),
    actions(() => post('moderation', m)),
  );
}

function renderShop() {
  const list = $('#shop-list');
  const items = state.overview.shop || [];
  if (!items.length) { list.replaceChildren(el('p', 'muted', 'No shop items yet.')); return; }

  list.replaceChildren(...items.map(item => {
    const draft = { id: item.id, name: item.name, description: item.description, price: item.price };
    const d = el('details', 'item');
    const s = el('summary');
    s.append(
      el('span', 'emoji', item.emoji || '📦'),
      el('span', 'nm', item.name),
      el('span', 'pr', num(item.price)),
    );
    const body = el('div', 'body');
    body.append(
      textField('Name', item.name, v => { draft.name = v; }),
      textField('Description', item.description, v => { draft.description = v; }),
      textField('Price', String(item.price), v => { draft.price = Number(v); }),
      actions(() => post('shop', draft)),
    );
    d.append(s, body);
    return d;
  }));
}

/* ── composer ──────────────────────────────────────────────────────────────
   Embeds and buttons in one editor. They are two files on disk and two
   commands in Discord, but a message is both, so it is edited as both. */

function select(label, value, options, onChange, { blank = null } = {}) {
  const l = el('label', 'field');
  l.append(el('span', null, label));
  const s = el('select');
  if (blank !== null) { const o = el('option', null, blank); o.value = ''; s.append(o); }
  for (const opt of options) {
    const o = el('option', null, opt.label);
    o.value = opt.value;
    s.append(o);
  }
  s.value = value ?? '';
  s.addEventListener('change', () => onChange(s.value));
  l.append(s);
  return l;
}

/* Pickers. Nothing in this panel should ever ask for a raw snowflake — you
   cannot check one by eye, and a wrong digit fails silently at use time. */

const channelList = () => state.overview?.settings?.channels || [];
const roleList = () => state.overview?.settings?.roles || [];

function pickOne(label, kind, value, onChange, { blank = 'Not set' } = {}) {
  const items = kind === 'role' ? roleList() : channelList();
  return select(label, value || '',
    items.map(i => ({ value: i.id, label: kind === 'role' ? i.name : `#${i.name}` })),
    v => onChange(v || null), { blank });
}

/**
 * Ping target: nothing, the two broadcast forms, or a role in this server.
 *
 * Up here with the other pickers rather than beside the one screen that first
 * needed it — the Composer's send form uses it too, and a ping target is the
 * same question wherever it is asked.
 */
function mentionPicker(label, value, onChange, { blank = 'No ping' } = {}) {
  const current = value && value.startsWith('<@&') ? value.replace(/[^0-9]/g, '') : value;
  return select(label, current || '', [
    { value: '@everyone', label: '@everyone' },
    { value: '@here', label: '@here' },
    ...roleList().map(r => ({ value: r.id, label: `@${r.name}` })),
  ], v => onChange(v || null), { blank });
}

/**
 * Multi-select as toggleable chips rather than a <select multiple>, which is
 * close to unusable on a phone — ctrl-click has no touch equivalent.
 */
function pickMany(label, kind, values, onChange) {
  const items = kind === 'role' ? roleList() : channelList();
  const chosen = new Set(values || []);
  const wrap = el('div', 'field');
  wrap.append(el('span', null, label));

  const box = el('div', 'chipset');
  if (!items.length) box.append(el('span', 'muted', kind === 'role' ? 'No roles found.' : 'No channels found.'));
  for (const i of items) {
    const b = el('button', 'chip-toggle', kind === 'role' ? i.name : `#${i.name}`);
    b.type = 'button';
    if (chosen.has(i.id)) b.setAttribute('aria-pressed', 'true');
    b.addEventListener('click', () => {
      if (chosen.has(i.id)) { chosen.delete(i.id); b.removeAttribute('aria-pressed'); }
      else { chosen.add(i.id); b.setAttribute('aria-pressed', 'true'); }
      onChange([...chosen]);
    });
    box.append(b);
  }
  wrap.append(box);
  return wrap;
}

/**
 * Multi-select over a fixed vocabulary — impact levels, currency codes.
 *
 * Same chips as the role and channel pickers, so "pick several from a list"
 * looks the same everywhere. Nothing selected means everything, which is what
 * an empty filter means to the calendar, so the field says so rather than
 * leaving it to be inferred from a blank row.
 */
function pickValues(label, options, values, onChange, { allNote = 'Nothing picked — everything is sent.' } = {}) {
  const chosen = new Set(values || []);
  const wrap = el('div', 'field');
  const head = el('div', 'field-head');
  const note = el('span', 'count');
  head.append(el('span', null, label), note);
  wrap.append(head);

  const sync = () => { note.textContent = chosen.size ? `${chosen.size} picked` : 'all'; };

  const box = el('div', 'chipset');
  for (const o of options) {
    const value = typeof o === 'string' ? o : o.value;
    const text = typeof o === 'string' ? o : o.label;
    const b = el('button', 'chip-toggle', text);
    b.type = 'button';
    // What the option actually covers, for vocabularies where the name alone
    // does not say — "Commodities" is not obviously oil, gold and gas.
    if (o && o.hint) b.title = o.hint;
    if (chosen.has(value)) b.setAttribute('aria-pressed', 'true');
    b.addEventListener('click', () => {
      if (chosen.has(value)) { chosen.delete(value); b.removeAttribute('aria-pressed'); }
      else { chosen.add(value); b.setAttribute('aria-pressed', 'true'); }
      sync();
      // Ordered by the vocabulary so what is sent matches what is stored.
      onChange(options.map(x => (typeof x === 'string' ? x : x.value)).filter(v => chosen.has(v)));
    });
    box.append(b);
  }
  sync();
  wrap.append(box);
  wrap.append(el('p', 'hint', allNote));
  return wrap;
}

/**
 * Member picker — a list, like channels and roles.
 *
 * It used to be a type-to-match box, which was a bad idea the moment a name
 * contained styled unicode: you cannot type 𝓎☆𝒮𝒮𝐸𝑅 on a phone keyboard, so
 * the field was effectively unusable for exactly the people most likely to
 * have a name like that.
 */
function pickMember(label, value, onChange) {
  const members = state.overview?.features?.members || [];
  const field = select(
    label,
    value || '',
    members.map(m => ({ value: m.id, label: m.name })),
    v => onChange(v || null),
    { blank: members.length ? 'Pick a member…' : 'No members loaded' },
  );
  // Search only on this control (Quick Action) — not every dropdown
  const sel = field.querySelector('select');
  if (sel) sel.dataset.searchable = '1';
  return field;
}

function areaField(label, value, onInput, rows = 4) {
  const l = el('label', 'field');
  l.append(el('span', null, label));
  const t = el('textarea');
  t.rows = rows;
  t.value = value ?? '';
  t.addEventListener('input', () => onInput(t.value));
  l.append(t);
  return l;
}


/* ── Image source control ─────────────────────────────────────────────────
 * Compact row: value pill (URL or label) + chevron menu of generated
 * banners + Upload. Giveaway defaults to Prize banner; picking "Image URL"
 * turns the pill into a text field; the menu still restores Prize banner.
 */
function dynamicImageLabel(keyOrDynamic) {
  const key = String(keyOrDynamic || '').replace(/^dynamic:/, '');
  const names = {
    prizeGiveawayBanner: 'Prize banner',
    tradingViewBanner: 'TradingView',
    economyShowcase: 'Economy showcase',
    reportGuide: 'Report guide',
    nyseOpen: 'NYSE open',
    futuresOpen: 'Futures open',
    riskGuide: 'Risk guide',
    newsfeedGuide: 'Newsfeed guide',
    whopBanner: 'Whop banner',
  };
  return names[key] || key.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()).trim();
}

function generatedImageOptions() {
  return (state.overview?.composerMeta?.dynamicImages || []).map(d => ({
    value: d,
    label: dynamicImageLabel(d),
  }));
}

async function fileToDataUrl(file, maxSide = 1600) {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
  const w = Math.max(1, Math.round(bmp.width * scale));
  const h = Math.max(1, Math.round(bmp.height * scale));
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  c.getContext('2d').drawImage(bmp, 0, 0, w, h);
  bmp.close?.();
  const type = (file.type && file.type.startsWith('image/')) ? file.type : 'image/png';
  return c.toDataURL(type === 'image/jpg' ? 'image/jpeg' : type, 0.92);
}

/**
 * @param {string} label
 * @param {string} value  dynamic:… | https… | ''
 * @param {(v: string) => void} onChange
 * @param {{ defaultValue?: string, giveaway?: boolean }} opts
 */
function imageSourceField(label, value, onChange, opts = {}) {
  const field = el('div', 'field img-source');
  field.append(el('label', null, label));

  const row = el('div', 'img-source-row');
  const pill = el('div', 'img-source-pill');
  const input = el('input');
  input.type = 'text';
  input.autocomplete = 'off';
  input.spellcheck = false;
  input.placeholder = opts.giveaway ? 'Prize banner (default)' : 'https://… or pick generated';

  const chev = el('button', 'img-source-chev');
  chev.type = 'button';
  chev.title = 'Generated images';
  chev.setAttribute('aria-label', 'Pick generated image');
  chev.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>';

  const menu = el('div', 'img-source-menu');
  menu.hidden = true;

  let current = value || opts.defaultValue || '';
  let urlMode = !!(current && !String(current).startsWith('dynamic:') && current !== (opts.defaultValue || ''));

  const paint = () => {
    if (urlMode && (!current || !String(current).startsWith('dynamic:'))) {
      input.readOnly = false;
      input.value = current && !String(current).startsWith('dynamic:') ? current : '';
      input.placeholder = 'https://…';
    } else if (current && String(current).startsWith('dynamic:')) {
      input.readOnly = true;
      input.value = dynamicImageLabel(current);
      input.placeholder = '';
    } else if (opts.giveaway && (!current || current === opts.defaultValue)) {
      input.readOnly = true;
      input.value = dynamicImageLabel(opts.defaultValue || 'dynamic:prizeGiveawayBanner');
      current = opts.defaultValue || 'dynamic:prizeGiveawayBanner';
    } else {
      input.readOnly = false;
      input.value = current || '';
    }
  };

  const setVal = (v, asUrlMode) => {
    current = v || '';
    if (asUrlMode !== undefined) urlMode = asUrlMode;
    paint();
    onChange(current);
  };

  input.addEventListener('input', () => {
    if (input.readOnly) return;
    urlMode = true;
    current = input.value.trim();
    onChange(current);
  });

  const closeMenu = () => { menu.hidden = true; };
  const openMenu = () => {
    menu.replaceChildren();
    if (opts.giveaway) {
      const def = opts.defaultValue || 'dynamic:prizeGiveawayBanner';
      const b = el('button', 'img-source-opt' + (current === def && !urlMode ? ' on' : ''), 'Prize banner');
      b.type = 'button';
      b.addEventListener('click', () => { setVal(def, false); closeMenu(); });
      menu.append(b);
    }
    for (const g of generatedImageOptions()) {
      if (opts.giveaway && g.value === (opts.defaultValue || 'dynamic:prizeGiveawayBanner')) continue;
      const b = el('button', 'img-source-opt' + (current === g.value ? ' on' : ''), g.label);
      b.type = 'button';
      b.addEventListener('click', () => { setVal(g.value, false); closeMenu(); });
      menu.append(b);
    }
    const urlBtn = el('button', 'img-source-opt' + (urlMode ? ' on' : ''), 'Image URL…');
    urlBtn.type = 'button';
    urlBtn.addEventListener('click', () => {
      urlMode = true;
      if (String(current).startsWith('dynamic:')) current = '';
      paint();
      onChange(current);
      closeMenu();
      setTimeout(() => input.focus(), 30);
    });
    menu.append(urlBtn);
    menu.hidden = false;
  };

  chev.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (menu.hidden) openMenu();
    else closeMenu();
  });
  document.addEventListener('click', (e) => {
    if (!field.contains(e.target)) closeMenu();
  });

  const upBtn = el('button', 'btn small img-source-up', 'Upload');
  upBtn.type = 'button';
  upBtn.title = 'Upload from your device';
  const fileIn = el('input');
  fileIn.type = 'file';
  fileIn.accept = 'image/png,image/jpeg,image/webp,image/gif';
  fileIn.hidden = true;
  upBtn.addEventListener('click', () => fileIn.click());
  fileIn.addEventListener('change', async () => {
    const file = fileIn.files?.[0];
    fileIn.value = '';
    if (!file) return;
    upBtn.disabled = true;
    upBtn.textContent = '…';
    try {
      const data = await fileToDataUrl(file);
      const res = await post('imageupload', { data });
      if (res?.url) {
        setVal(res.url, true);
        toast('Image uploaded.', 'ok');
      } else {
        toast(ERRORS[res?.error] || res?.detail || 'Upload failed.', 'bad');
      }
    } catch (err) {
      toast('Upload failed.', 'bad');
    }
    upBtn.disabled = false;
    upBtn.textContent = 'Upload';
  });

  pill.append(input, chev, menu);
  row.append(pill, upBtn, fileIn);
  field.append(row);
  paint();
  return field;
}


function renderComposerIndex() {
  const wrap = $('#tpl-index');
  const raw = state.overview?.composer;
  const list = Array.isArray(raw) ? raw : [];
  if (!list.length) {
    wrap.replaceChildren(
      el('p', 'muted', 'No messages yet.'),
      el('p', 'hint', 'Press New to create one, or build a template in Studio first.'),
    );
    return;
  }
  wrap.replaceChildren(...list.map(t => {
    const b = el('button', 'tpl-entry');
    b.type = 'button';
    const nm = el('span', 'nm');
    const hasEmbed = Array.isArray(t.embeds) && t.embeds.length > 0;
    if (hasEmbed) {
      const mark = el('span', 'tpl-embed-mark', '✦');
      mark.title = 'Has embed';
      nm.append(mark, document.createTextNode(' ' + t.name));
    } else {
      nm.textContent = t.name;
    }
    b.append(nm);
    const meta = el('span', 'mt');
    const eN = t.embeds?.length || 0;
    const bN = t.buttons?.length || 0;
    const pN = t.posts?.length || 0;
    meta.textContent = `${eN ? eN + '▦ ' : ''}${bN ? bN + '⬤ ' : ''}${pN ? pN + '↗' : ''}`.trim() || 'text';
    meta.title = `${eN} embeds · ${bN} buttons · ${pN} posted`;
    b.append(meta);
    if (t.name === state.tplName) b.setAttribute('aria-current', 'true');
    b.addEventListener('click', () => { state.tplName = t.name; state.draft = null; renderComposer(); });
    return b;
  }));
}

function newDraft(name = '') {
  return {
    name,
    embeds: [],
    around: { above: '', below: '', picture: '', pictureAbove: '' },
    buttons: [], posts: [],
  };
}

/* ── button types ──────────────────────────────────────────────────────────
 *
 * The server sends the machine names; these are what they actually do. "embed"
 * tells you nothing about the behaviour that makes it worth choosing — that
 * only the person who pressed sees the answer.
 */
const BUTTON_TYPE_LABELS = {
  role:   'Give or take a role',
  link:   'Open a link',
  ticket: 'Open a support ticket',
  embed:  'Show a message only they can see',
  custom: 'Reply with a line of text',
};

const buttonTypeOptions = (meta) =>
  (meta?.types || []).map(x => ({ value: x, label: BUTTON_TYPE_LABELS[x] || x }));

/**
 * Which saved message a "only they can see" button shows.
 *
 * From the Composer's own list — state.templates is Studio's banner artwork,
 * which is a different thing with a confusingly similar name.
 */
function templatePick(value, onChange) {
  const names = (state.overview?.composer || []).map(t => t.name).filter(Boolean);
  return select('Message it shows privately', value || '',
    names.map(n => ({ value: n, label: n })),
    v => onChange(v || ''),
    { blank: 'Only for "show a message" buttons' });
}

function renderComposer() {
  renderComposerIndex();
  const body = $('#composer-body');
  const raw = state.overview?.composer;
  const list = Array.isArray(raw) ? raw : [];
  const meta = state.overview?.composerMeta || {};

  const tpl = state.draft || list.find(t => t.name === state.tplName);
  if (!tpl) {
    body.replaceChildren(el('p', 'muted', 'Pick a message on the left, or create a new one.'));
    return;
  }

  // Everything below edits this local copy; nothing is written until Save.
  const draft = state.draft || JSON.parse(JSON.stringify(tpl));
  // Stored as null when nothing is set, so the editor always has one to bind
  // to rather than each field having to cope with it being absent.
  draft.around = draft.around || { above: '', below: '', picture: '', pictureAbove: '' };
  if (draft.around.pictureAbove == null) draft.around.pictureAbove = '';
  state.draft = draft;

  const parts = [];

  /* -- name + embeds --------------------------------------------------- */
  const head = el('div', 'panel');
  head.append(el('h2', null, 'Message'));
  head.append(textField('Name (how you refer to it)', draft.name, v => { draft.name = v; }));

  const a = draft.around;

  /* -- Plain text message (no embeds) ---------------------------------- */
  if (!draft.embeds.length) {
    const plain = el('div', 'composer-plain');
    plain.append(
      el('h2', null, 'Plain text'),
      el('p', 'muted', 'No embed — this posts as a normal Discord message.'),
      areaField('Message body', a.above, v => { a.above = v; }, 5),
      el('p', 'hint', 'Type #channel-name and it becomes a real channel link. Mentions and markdown work here.'),
      imageSourceField('Image above the text', a.pictureAbove || '', v => { a.pictureAbove = v; }),
      el('p', 'hint', 'Sent as its own message just above the text. Pick a generated image, paste a URL, or upload.'),
      imageSourceField('Image below the text', a.picture || '', v => { a.picture = v; }),
      el('p', 'hint', 'Sent under the text as a second message (optional note below).'),
      areaField('Note under the image below (optional)', a.below, v => { a.below = v; }, 2),
    );
    head.append(plain);
  }

  /* -- Embeds (optional) ----------------------------------------------- */
  draft.embeds.forEach((e, i) => {
    const embedIndex = i;
    const box = el('details', 'embed-box');
    if (!state._composerOpen) state._composerOpen = {};
    const openKey = `${draft.name || '_new'}:${embedIndex}`;
    box.open = state._composerOpen[openKey] !== false && (state._composerOpen[openKey] === true || embedIndex === 0);
    box.addEventListener('toggle', () => { state._composerOpen[openKey] = box.open; });

    const sum = el('summary');
    sum.append(el('span', 'swatch'), el('span', 'nm', e.title || `Embed ${embedIndex + 1}`));
    sum.querySelector('.swatch').style.background = e.color || '#5865F2';
    const inner = el('div', 'body');
    inner.append(
      textField('Title', e.title, v => { e.title = v; }),
      areaField('Description', e.description, v => { e.description = v; }, 5),
      el('p', 'hint', 'Type #channel-name here and it posts as a real channel link people can tap.'),
      textField('Colour (hex)', e.color, v => { e.color = v; }),
      textField('Footer', e.footer, v => { e.footer = v; }),
      el('p', 'hint', 'Discord draws the footer, the title and the author line as plain text — a #channel there stays writing, it cannot become a link. Put it in the description or under the embed instead.'),
      imageSourceField('Image', e.image || '', v => { e.image = v; }),
      el('p', 'hint', 'Generated image, URL, or upload — used as the large embed image.'),
      textField('Thumbnail URL', e.thumbnail, v => { e.thumbnail = v; }),
      toggle('Show a timestamp', !!e.timestamp, v => { e.timestamp = v; }),
    );

    const fieldWrap = el('div', 'subfields');
    fieldWrap.append(el('h2', null, 'Fields'));
    e.fields = e.fields || [];
    e.fields.forEach((f, fi) => {
      const rowEl = el('div', 'subfield');
      rowEl.append(
        textField('Name', f.name, v => { f.name = v; }),
        textField('Value', f.value, v => { f.value = v; }),
        toggle('Inline', !!f.inline, v => { f.inline = v; }),
      );
      const del = el('button', 'btn small danger', 'Remove field');
      del.type = 'button';
      del.addEventListener('click', () => {
        draft.embeds[embedIndex].fields.splice(fi, 1);
        renderComposer();
      });
      rowEl.append(del);
      fieldWrap.append(rowEl);
    });
    const addField = el('button', 'btn small', 'Add field');
    addField.type = 'button';
    addField.addEventListener('click', () => {
      draft.embeds[embedIndex].fields.push({ name: '', value: '', inline: false });
      renderComposer();
    });
    fieldWrap.append(addField);
    inner.append(fieldWrap);

    const rm = el('button', 'btn small danger', 'Remove this embed');
    rm.type = 'button';
    rm.addEventListener('click', () => {
      draft.embeds.splice(embedIndex, 1);
      renderComposer();
    });
    inner.append(rm);

    box.append(sum, inner);
    head.append(box);
  });

  const addEmbed = el('button', 'btn small', '＋ Add embed');
  addEmbed.type = 'button';
  addEmbed.disabled = draft.embeds.length >= (meta?.limits?.embeds || 10);
  addEmbed.addEventListener('click', () => {
    const idx = draft.embeds.length;
    draft.embeds.push({ title: '', description: '', color: '#5865F2', footer: '', thumbnail: '', image: '', fields: [], timestamp: false });
    // Leave plain-text mode — images live on embeds from here
    a.pictureAbove = '';
    if (!state._composerOpen) state._composerOpen = {};
    state._composerOpen[`${draft.name || '_new'}:${idx}`] = true;
    renderComposer();
  });

  /* -- Lines around ALL embeds (only when at least one embed exists) ----
     Discord order is fixed for the whole message:
       content (above) → embed 1 → embed 2 → … → buttons
     “Below” is always a second message under the whole stack — never
     between embeds, and not tied to a single embed. */
  if (draft.embeds.length) {
    const aroundLabel = draft.embeds.length > 1
      ? 'Text around all embeds'
      : 'Text around the embed';
    head.append(disclosure('composer:around', aroundLabel, [
      el('p', 'muted',
        draft.embeds.length > 1
          ? 'Discord stacks embeds in order. Text above sits once at the top of the stack — not between embeds. Put images on each embed. A note below is a second message under everything.'
          : 'Plain text outside the embed. Put images on the embed (image / thumbnail), not as plain-text slots. Order is always text → embed → buttons.'),
      areaField(
        draft.embeds.length > 1 ? 'Above all embeds' : 'Above the embed',
        a.above, v => { a.above = v; }, 2,
      ),
      areaField(
        draft.embeds.length > 1 ? 'Second message under all embeds' : 'Second message under the embed',
        a.below, v => { a.below = v; }, 2,
      ),
      textField('Picture under it (URL)', a.picture, v => { a.picture = v; }),
      el('p', 'hint', 'You cannot place different text between two embeds — Discord does not allow that. Use the description inside each embed for per-embed copy.'),
    ]));
  }

  const saveRow = el('div', 'actions');
  const saveBtn = el('button', 'btn primary small', 'Save message');
  saveBtn.type = 'button';
  saveBtn.addEventListener('click', async () => {
    const name = (draft.name || '').trim();
    if (!name) { toast('Give the message a name first.', 'bad'); return; }
    const around = draft.around || {};
    const hasAround = !!(around.above || around.below || around.picture || around.pictureAbove);
    if (!draft.embeds.length && !hasAround) {
      toast('Write a message body, add an image, or add an embed.', 'bad');
      return;
    }
    if (draft.embeds.length) draft.around.pictureAbove = '';
    for (const key of ['picture', 'pictureAbove']) {
      const u = String(draft.around[key] || '').trim();
      if (!u) continue;
      const okDyn = u.startsWith('dynamic:');
      const okUrl = /^https?:\/\//i.test(u);
      if (!okDyn && !okUrl) {
        toast('Pick a generated image, upload one, or paste an https image URL.', 'bad');
        return;
      }
    }
    for (let i = 0; i < draft.embeds.length; i++) {
      const e = draft.embeds[i];
      const c = String(e.color || '').trim();
      if (c && !/^#?[0-9a-fA-F]{6}$/.test(c)) {
        toast(`Embed ${i + 1}: colour must be a 6-digit hex (e.g. #5865F2).`, 'bad');
        return;
      }
      if (e.title && e.title.length > 256) { toast(`Embed ${i + 1}: title is too long (max 256).`, 'bad'); return; }
      if (e.description && e.description.length > 4096) { toast(`Embed ${i + 1}: description is too long (max 4096).`, 'bad'); return; }
      const bare = !(e.title || e.description || e.footer || e.image || e.thumbnail || (e.fields || []).some(f => f.name && f.value));
      if (bare) { toast(`Embed ${i + 1} is empty — add content or remove it.`, 'bad'); return; }
    }
    saveBtn.disabled = true;
    const res = await post('template', { name: draft.name, embeds: draft.embeds, around: draft.around });
    saveBtn.disabled = false;
    if (res?.ok) { state.tplName = draft.name; state.draft = null; renderComposer(); }
    else if (res?.error === 'empty_message') toast('Add an embed or some text around the message.', 'bad');
  });

  // Sits beside Save because that is where you are when you want to check your
  // work — and it previews the draft in hand, saved or not.
  const previewBtn = el('button', 'btn small', 'Preview');
  previewBtn.type = 'button';
  previewBtn.addEventListener('click', () => openEmbedPreview(draft));

  saveRow.append(addEmbed, previewBtn, saveBtn);

  if (!state.draft?.isNew && list.some(t => t.name === draft.name)) {
    const del = el('button', 'btn small danger', 'Delete message');
    del.type = 'button';
    del.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'Delete this message?',
        message: `“${draft.name}” and every button attached to it will be removed. Messages already posted in your channels stay where they are.`,
        confirmLabel: 'Delete it', danger: true,
      })) return;
      const res = await post('templatedelete', { name: draft.name });
      if (res?.ok) { state.tplName = null; state.draft = null; renderComposer(); }
    });
    saveRow.append(del);
  }
  head.append(saveRow);
  parts.push(head);

  /* -- buttons ---------------------------------------------------------- */
  const btnPanel = el('div', 'panel');
  btnPanel.append(el('h2', null, 'Buttons on this message'));
  const saved = list.find(t => t.name === draft.name);
  const savedButtons = saved?.buttons || [];

  if (!saved) {
    btnPanel.append(el('p', 'hint', 'Save the message first, then you can attach buttons to it.'));
  } else {
    if (!savedButtons.length) btnPanel.append(el('p', 'muted', 'No buttons yet.'));
    for (const b of savedButtons) {
      const d = el('details', 'item');
      const s = el('summary');
      s.append(
        el('span', `bstyle ${b.style.toLowerCase()}`, b.style),
        el('span', 'nm', b.label || b.id),
        el('span', 'pr', `${b.uses} uses`),
      );
      const inner = el('div', 'body');
      const draftBtn = { ...b, embedName: draft.name };
      inner.append(
        textField('Label', b.label, v => { draftBtn.label = v; }),
        textField('Emoji', b.emoji, v => { draftBtn.emoji = v; }),
        select('Style', b.style, (meta?.styles || []).map(x => ({ value: x, label: x })), v => { draftBtn.style = v; }),
        select('Does what', b.type, buttonTypeOptions(meta), v => { draftBtn.type = v; }),
        pickOne('Role it grants', 'role', b.roleId, v => { draftBtn.roleId = v; }, { blank: 'Not a role button' }),
        textField('URL (for link buttons)', b.url, v => { draftBtn.url = v; }),
        templatePick(b.responseEmbedName, v => { draftBtn.responseEmbedName = v; }),
      );
      const rowA = el('div', 'actions');
      const save = el('button', 'btn primary small', 'Save button');
      save.type = 'button';
      save.addEventListener('click', () => post('button', draftBtn));
      const rm = el('button', 'btn small danger', 'Remove');
      rm.type = 'button';
      rm.addEventListener('click', () => post('buttondelete', { id: b.id }));
      rowA.append(save, rm);
      inner.append(rowA);
      d.append(s, inner);
      btnPanel.append(d);
    }

    const add = el('details', 'item');
    const addSum = el('summary');
    addSum.append(el('span', 'nm', '＋ Add a button'));
    const addBody = el('div', 'body');
    // Always locked to THIS message — never another template
    const nb = { embedName: draft.name, id: '', label: '', style: 'Primary', type: 'custom', emoji: '', roleId: '', url: '', responseEmbedName: '' };
    addBody.append(
      el('p', 'hint', `Buttons attach to “${draft.name}” only.`),
      textField('Button id (letters, numbers, dashes)', '', v => { nb.id = v; }),
      textField('Label', '', v => { nb.label = v; }),
      textField('Emoji', '', v => { nb.emoji = v; }),
      select('Style', 'Primary', (meta?.styles || []).map(x => ({ value: x, label: x })), v => { nb.style = v; }),
      select('Does what', 'custom', buttonTypeOptions(meta), v => { nb.type = v; }),
      pickOne('Role it grants', 'role', '', v => { nb.roleId = v; }, { blank: 'Not a role button' }),
      textField('URL (link buttons)', '', v => { nb.url = v; }),
      templatePick('', v => { nb.responseEmbedName = v; }),
      actions(async () => {
        nb.embedName = draft.name; // re-bind in case name was edited
        if (!nb.id || !/^[\w-]+$/.test(nb.id)) { toast('Button id: letters, numbers, dashes only.', 'bad'); return; }
        if (!nb.label && nb.type !== 'link') { toast('Give the button a label.', 'bad'); return; }
        if (nb.type === 'link' && !/^https?:\/\//i.test(nb.url || '')) { toast('Link buttons need a full https URL.', 'bad'); return; }
        if (nb.type === 'role' && !nb.roleId) { toast('Pick a role for this button.', 'bad'); return; }
        if (nb.type === 'embed' && !nb.responseEmbedName) { toast('Pick which message it shows privately.', 'bad'); return; }
        await post('button', nb);
      }),
    );
    add.append(addSum, addBody);
    btnPanel.append(add);
  }
  parts.push(btnPanel);

  /* -- send + live posts ------------------------------------------------ */
  if (saved) {
    const sendPanel = el('div', 'panel');
    sendPanel.append(el('h2', null, 'Send and update'));
    const target = { name: draft.name, channelId: '', content: '', mention: null };
    const channels = state.overview?.settings?.channels || [];
    sendPanel.append(
      select('Channel', '', channels.map(c => ({ value: c.id, label: `#${c.name}` })), v => { target.channelId = v; }, { blank: 'Pick a channel' }),
      // Between the channel and the line above the embed, because it reads in
      // the order the post is built: where it goes, who it is for, what it
      // says. It belongs to this send rather than to the template, so it
      // resets every time this form is drawn.
      mentionPicker('Ping with the post', null, v => { target.mention = v; }),
      textField('Text above the embed (optional)', '', v => { target.content = v; }),
    );
    const sendRow = el('div', 'actions');
    const sendBtn = el('button', 'btn primary small', 'Send to channel');
    sendBtn.type = 'button';
    sendBtn.addEventListener('click', async () => {
      if (!target.channelId) { toast('Pick a channel first.', 'bad'); return; }
      sendBtn.disabled = true;
      await post('send', target);
      sendBtn.disabled = false;
    });
    sendRow.append(sendBtn);
    sendPanel.append(sendRow);

    if (saved.posts.length) {
      sendPanel.append(el('h2', null, 'Already posted'));
      for (const p of saved.posts) {
        const line = el('div', 'post-row');
        const ch = channels.find(c => c.id === p.channelId);
        line.append(el('span', 'k', `#${ch?.name || p.channelId} · ${new Date(p.sentAt).toLocaleString()}`));
        const up = el('button', 'btn small', 'Push update');
        up.type = 'button';
        up.title = 'Re-render this template into the message that is already posted';
        up.addEventListener('click', () => post('updatepost', { channelId: p.channelId, messageId: p.messageId, name: draft.name }));
        line.append(up);
        sendPanel.append(line);
      }
    }
    parts.push(sendPanel);
  }

  body.replaceChildren(...parts);
}

/* ── giveaways ─────────────────────────────────────────────────────────── */

function timeLeft(ts) {
  if (!ts) return 'no end time';
  const ms = ts - Date.now();
  if (ms <= 0) return 'ending now';
  return `${duration(ms)} left`;
}

/* Live countdowns. One timer for the whole page rather than one per giveaway,
   and it only touches text that changed. */
const ticking = new Set();
let tickTimer = null;

/**
 * @param {number} endsAt
 * @param {number|null} startedAt
 *   When the thing being counted actually began. Without it the bar measured
 *   from the moment the page opened, so every reload put it back to empty and
 *   it filled again over whatever was left — a bar that looked like progress
 *   and was really just "how long have you been looking at this". Given the
 *   real start it shows the same fraction on every device, at any time, and
 *   survives a refresh unchanged.
 */
function countdownEl(endsAt, startedAt = null) {
  const node = el('span', 'countdown');
  const bar = el('div', 'meter');
  const fill = el('i');
  // Continuous motion — no CSS width transition (that caused stop-go every 1s)
  fill.style.transition = 'none';
  bar.append(fill);
  const began = Number(startedAt) > 0 ? Number(startedAt) : Date.now();
  const span = Math.max(1, endsAt - began);
  let raf = 0;
  let lastSec = -1;

  const paint = () => {
    const now = Date.now();
    const left = endsAt - now;
    if (left <= 0) {
      node.textContent = 'ending now';
      node.className = 'countdown over';
      fill.style.width = '100%';
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
      if (!node.dataset.endedBump) {
        node.dataset.endedBump = '1';
        setTimeout(() => {
          try {
            if (typeof refreshOverview === 'function') refreshOverview();
            else if (typeof renderGiveaways === 'function') renderGiveaways();
          } catch (_) {}
        }, 600);
      }
      return false;
    }
    // Bar moves every frame (smooth until the end)
    const pct = Math.min(100, Math.max(0, ((now - began) / span) * 100));
    fill.style.width = pct.toFixed(2) + '%';

    // Text updates once per second (readable, no flicker)
    const s = Math.floor(left / 1000);
    if (s !== lastSec) {
      lastSec = s;
      const d = Math.floor(s / 86400), h = Math.floor(s / 3600) % 24, m = Math.floor(s / 60) % 60, sec = s % 60;
      node.textContent = d > 0
        ? `${d}d ${h}h ${m}m`
        : h > 0
          ? `${h}h ${String(m).padStart(2, '0')}m ${String(sec).padStart(2, '0')}s`
          : `${m}m ${String(sec).padStart(2, '0')}s`;
      node.className = left < 60_000 ? 'countdown soon' : 'countdown';
      if (left < 60_000) bar.classList.add('soon');
      else bar.classList.remove('soon');
    }
    return true;
  };

  const loop = () => {
    if (!paint()) return;
    raf = requestAnimationFrame(loop);
  };
  paint();
  raf = requestAnimationFrame(loop);
  // Still register with ticking so cleanup on re-render works
  const tickPaint = () => {
    if (!document.body.contains(node)) {
      if (raf) cancelAnimationFrame(raf);
      return false;
    }
    return paint();
  };
  ticking.add(tickPaint);
  return { node, bar };
}

function startTicking() {
  clearInterval(tickTimer);
  tickTimer = setInterval(() => {
    for (const paint of [...ticking]) if (!paint()) ticking.delete(paint);
  }, 1000);
}


/* Instant panel removals — animate out, update state, optional background refresh */
function gawIdOf(x) {
  return String(x?.shortId || x?.messageId || x?.id || '').toLowerCase();
}

function leaveNode(node, ms = 220) {
  return new Promise((resolve) => {
    if (!node) { resolve(); return; }
    node.classList.add('is-leaving');
    node.style.pointerEvents = 'none';
    setTimeout(() => {
      try { node.remove(); } catch (_) {}
      resolve();
    }, ms);
  });
}

function optimisticGawRemove(shortId) {
  const id = String(shortId || '').toLowerCase();
  if (!id || !state.overview?.giveaways) return;
  const g = state.overview.giveaways;
  g.active = (g.active || []).filter((x) => gawIdOf(x) !== id);
  g.ended = (g.ended || []).filter((x) => gawIdOf(x) !== id);
  document.querySelectorAll(`[data-gaw-id="${CSS.escape(id)}"]`).forEach((n) => {
    leaveNode(n);
  });
}

function optimisticGawEnd(shortId) {
  const id = String(shortId || '').toLowerCase();
  const g = state.overview?.giveaways;
  if (!g || !id) return;
  const idx = (g.active || []).findIndex((x) => gawIdOf(x) === id);
  if (idx >= 0) {
    const [item] = g.active.splice(idx, 1);
    item._justEnded = true;
    g.ended = [item, ...(g.ended || [])];
  }
}

async function softRefreshOverview() {
  try {
    if (typeof refreshOverview === 'function') {
      Promise.resolve(refreshOverview()).catch(() => {});
    }
  } catch (_) {}
}



async function openGiveawayParticipants(messageId, meta = {}) {
  const sheetTitle = meta.title ? `Participants · ${meta.title}` : 'Participants';

  // Keep one sheet open — do not tear down on every refresh
  if (!window.__gawRoster) window.__gawRoster = {};
  const roster = window.__gawRoster;
  roster.messageId = messageId;
  roster.title = meta.title || roster.title || '';

  // Stop previous poller
  if (roster.pollTimer) {
    clearInterval(roster.pollTimer);
    roster.pollTimer = null;
  }

  const paint = async (opts = {}) => {
    const silent = !!opts.silent;
    if (!silent) {
      openSheet(sheetTitle, [el('div', 'roster-loading', 'Pulling entrants…')], []);
    }

    const res = await post('giveawayparticipants', { messageId });
    // Sheet closed or switched to another drop
    if (roster.messageId !== messageId) return;
    if (!res?.ok) {
      if (!silent) {
        openSheet(sheetTitle, [
          el('p', 'hint bad', 'Could not load participants. The giveaway may have ended.'),
        ], [
          Object.assign(el('button', 'btn', 'Close'), { type: 'button', onclick: () => closeSheet() }),
        ]);
      }
      return;
    }

    // Skip full DOM rebuild when nothing changed (cuts lag while sheet is open)
    const fp = JSON.stringify({
      c: res.count,
      ids: (res.participants || []).map(p => p.id),
    });
    if (silent && roster.lastFp === fp) return;
    roster.lastFp = fp;

    const young = (res.participants || []).filter(p => p.young).length;
    const body = [];

    const hero = el('div', 'roster-hero');
    const count = el('div', 'roster-count');
    count.append(el('span', 'roster-count-num', String(res.count)));
    count.append(el('span', 'roster-count-label', res.count === 1 ? 'entrant' : 'entrants'));
    hero.append(count);
    const metaLine = el('div', 'roster-meta');
    if (res.prize) metaLine.append(el('span', 'roster-prize', res.prize));
    if (res.dropId) metaLine.append(el('span', 'roster-id mono', `QL-${res.dropId}`));
    if (young) {
      const flag = el('span', 'roster-flag', `${young} young account${young === 1 ? '' : 's'}`);
      flag.title = 'Account age under 14 days';
      metaLine.append(flag);
    }
    hero.append(metaLine);
    body.push(hero);

    if (!(res.participants || []).length) {
      body.push(el('div', 'roster-empty', 'No one has entered yet.'));
    } else {
      const list = el('div', 'roster-list');
      (res.participants || []).forEach((p, i) => {
        const row = el('div', 'roster-row' + (p.young ? ' is-young' : ''));
        row.dataset.userId = p.id;
        row.style.animationDelay = silent ? '0s' : `${Math.min(i, 12) * 0.04}s`;

        const av = el('div', 'roster-av');
        if (p.avatar) {
          const img = el('img');
          img.src = p.avatar;
          img.alt = '';
          av.append(img);
        } else {
          av.append(el('span', null, (p.tag || '?').slice(0, 1).toUpperCase()));
        }
        row.append(av);

        const info = el('div', 'roster-info');
        info.append(el('span', 'roster-name', p.tag || p.id));
        const bits = [
          p.accountAgeDays != null ? `Age ${p.accountAgeDays}d` : null,
          p.serverJoinDays != null ? `Server ${p.serverJoinDays}d` : null,
          p.young ? 'Young' : null,
        ].filter(Boolean);
        info.append(el('span', 'roster-sub', bits.join(' · ') || p.id));
        row.append(info);

        const actions = el('div', 'roster-actions');
        const rm = el('button', 'btn small danger roster-remove', 'Remove');
        rm.type = 'button';
        rm.addEventListener('click', async () => {
          if (!await askConfirm({
            title: 'Remove entrant?',
            message: `${p.tag} will lose their spot.`,
            confirmLabel: 'Remove entry',
            danger: true,
          })) return;
          rm.disabled = true;
          row.classList.add('is-leaving');
          const out = await post('giveawayremoveparticipant', { messageId, userId: p.id });
          if (out?.ok) {
            // Stay on the same sheet — quiet repaint, no full relaunch
            row.remove();
            const num = document.querySelector('.roster-count-num');
            if (num) num.textContent = String(out.count ?? Math.max(0, (res.count || 1) - 1));
            // Refresh list from server without closing
            await paint({ silent: true });
            // Update live cards in background (do not remount sheet)
            try {
              const data = await get(`/api/guild/${state.guildId}`);
              if (data) {
                state.overview = data;
                if (typeof renderGiveaways === 'function') renderGiveaways();
              }
            } catch (_) {}
          } else {
            row.classList.remove('is-leaving');
            rm.disabled = false;
          }
        });
        actions.append(rm);
        row.append(actions);
        list.append(row);
      });
      body.push(list);
    }

    openSheet(sheetTitle, body, [
      Object.assign(el('button', 'btn', 'Close'), {
        type: 'button',
        onclick: () => {
          if (roster.pollTimer) {
            clearInterval(roster.pollTimer);
            roster.pollTimer = null;
          }
          roster.messageId = null;
          closeSheet();
        },
      }),
    ]);
  };

  await paint({ silent: false });

  // Live poll while the sheet is open — only repaint when the list changes
  roster.pollTimer = setInterval(() => {
    if (roster.messageId !== messageId) {
      clearInterval(roster.pollTimer);
      roster.pollTimer = null;
      return;
    }
    const sheet = document.getElementById('sheet');
    if (sheet && sheet.hidden) {
      clearInterval(roster.pollTimer);
      roster.pollTimer = null;
      roster.messageId = null;
      return;
    }
    paint({ silent: true }).catch(() => {});
  }, 8000);
}


function renderGiveaways() {
  ticking.clear();
  const g = state.overview?.giveaways || { active: [], ended: [] };

  // Pending = ended prize drops waiting for prize DM (still shown in Live)
  const pending = (g.ended || []).filter(x => x.kind === 'prize' && !x.prizeDmSent);
  const history = (g.ended || []).filter(x => x.kind !== 'prize' || x.prizeDmSent);

  const liveCount = $('#gaw-live-count');
  if (liveCount) {
    const nLive = g.active.length + pending.length;
    liveCount.textContent = String(nLive);
    liveCount.classList.toggle('on', nLive > 0);
  }

  const activeWrap = $('#gaw-active');
  if (!activeWrap) return;

  const cards = [];

  for (const x of g.active) {
    cards.push(buildLiveDropCard(x, { phase: 'live' }));
  }
  for (const x of pending) {
    cards.push(buildLiveDropCard(x, { phase: 'ended' }));
  }

  if (!cards.length) {
    activeWrap.replaceChildren(el('p', 'muted', 'No live giveaways. Launch one below.'));
  } else {
    const pageSize = 3;
    const total = cards.length;
    const pages = Math.max(1, Math.ceil(total / pageSize));
    let page = Math.max(0, state.gawLivePage || 0);
    if (page >= pages) page = pages - 1;
    state.gawLivePage = page;
    const slice = cards.slice(page * pageSize, page * pageSize + pageSize);

    const nodes = [...slice];

    if (pages > 1) {
      const pager = el('div', 'drop-pager');
      const meta = el('div', 'drop-pager-meta');
      meta.append(
        el('span', 'drop-pager-label', 'Live desk'),
        el('span', 'drop-pager-count', `${page * pageSize + 1}–${Math.min((page + 1) * pageSize, total)} of ${total}`),
      );

      const dots = el('div', 'drop-pager-dots');
      for (let i = 0; i < pages; i++) {
        const dot = el('button', 'drop-pager-dot' + (i === page ? ' on' : ''), String(i + 1));
        dot.type = 'button';
        dot.setAttribute('aria-label', `Page ${i + 1}`);
        if (i === page) dot.setAttribute('aria-current', 'page');
        dot.addEventListener('click', () => {
          state.gawLivePage = i;
          renderGiveaways();
        });
        dots.append(dot);
      }

      const nav = el('div', 'drop-pager-nav');
      const prev = el('button', 'btn small drop-pager-btn', '←');
      prev.type = 'button';
      prev.disabled = page <= 0;
      prev.title = 'Previous';
      prev.addEventListener('click', () => {
        if (state.gawLivePage > 0) {
          state.gawLivePage -= 1;
          renderGiveaways();
        }
      });
      const next = el('button', 'btn small drop-pager-btn', '→');
      next.type = 'button';
      next.disabled = page >= pages - 1;
      next.title = 'Next';
      next.addEventListener('click', () => {
        if (state.gawLivePage < pages - 1) {
          state.gawLivePage += 1;
          renderGiveaways();
        }
      });
      nav.append(prev, dots, next);

      pager.append(meta, nav);
      nodes.push(pager);
    }

    activeWrap.replaceChildren(...nodes);
  }

  // Recent history — collapsed by default, 5 per page
  const endedWrap = $('#gaw-ended');
  const endedCount = $('#gaw-ended-count');
  if (endedCount) endedCount.textContent = history.length ? String(history.length) : '';

  if (!endedWrap) return;

  if (!state.gawHistoryOpen) {
    const btn = el('button', 'btn', 'Show recent giveaways');
    btn.type = 'button';
    btn.addEventListener('click', () => { state.gawHistoryOpen = true; state.gawHistoryPage = 0; renderGiveaways(); });
    endedWrap.replaceChildren(
      el('p', 'muted', history.length ? `${history.length} in history` : 'Nothing finished yet.'),
      btn,
    );
    return;
  }

  const pageSize = 5;
  const page = Math.max(0, state.gawHistoryPage || 0);
  const pages = Math.max(1, Math.ceil(history.length / pageSize));
  const slice = history.slice(page * pageSize, page * pageSize + pageSize);

  const head = el('div', 'actions');
  const hide = el('button', 'btn small', 'Hide history');
  hide.type = 'button';
  hide.addEventListener('click', () => { state.gawHistoryOpen = false; renderGiveaways(); });
  head.append(hide);

  if (history.length) {
    const clearAll = el('button', 'btn small danger', 'Delete all');
    clearAll.type = 'button';
    clearAll.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'Delete all giveaway history?',
        message: `Removes ${history.length} finished giveaway${history.length === 1 ? '' : 's'} from the panel. Channel messages stay. Reroll will no longer be available for them.`,
        confirmLabel: 'Delete all', danger: true,
      })) return;
      clearAll.disabled = true;
      const out = await post('giveawayclearhistory', {});
      if (out && out.ok !== false && out.error == null) {
        if (state.overview?.giveaways) {
          // Keep only pending prize sends; wipe the rest of history
          const pending = (state.overview.giveaways.ended || []).filter(
            (x) => x.kind === 'prize' && !x.prizeDmSent,
          );
          state.overview.giveaways.ended = pending;
        }
        state.gawHistoryOpen = false;
        state.gawHistoryPage = 0;
        try { renderGiveaways(); } catch (_) {}
        softRefreshOverview();
      } else {
        clearAll.disabled = false;
      }
    });
    head.append(clearAll);
  }

  const mention = (w) => {
    const label = (w && (w.name || w.id)) || '';
    return label.startsWith('@') ? label : `@${label}`;
  };

  const list = slice.map(x => {
    const d = el('button', 'gaw tappable');
    d.type = 'button';
    const top = el('div', 'gaw-top');
    top.append(
      el('span', 'kind prize', x.kind === 'coins' ? 'COINS' : 'PRIZE'),
      el('span', 'nm', x.title || 'Drop'),
      el('span', 'idtag', x.shortId ? `QL-${x.shortId}` : ''),
    );
    d.append(top);
    d.append(el('p', 'hint', `${num(x.entrants)} entered · ${x.winners} winner${x.winners === 1 ? '' : 's'}`));
    if (x.winnersList?.length) {
      const row = el('div', null);
      row.style.display = 'flex';
      row.style.flexWrap = 'wrap';
      row.style.gap = '0.35rem';
      x.winnersList.forEach((w) => {
        const name = String(w.name || '').trim();
        const id = String(w.id || '');
        const label = name && name !== id ? `@${name}` : (id ? `@${id}` : '@unknown');
        const pill = el('span', 'win-inline');
        pill.append(el('span', 'dot'), document.createTextNode(label));
        row.append(pill);
      });
      d.append(row);
    }
    d.append(el('span', 'chev', '›'));
    d.addEventListener('click', () => openEndedGiveaway(x));
    return d;
  });

  const nav = el('div', 'actions');
  const prev = el('button', 'btn small', 'Previous');
  prev.type = 'button';
  prev.disabled = page <= 0;
  prev.addEventListener('click', () => { state.gawHistoryPage = page - 1; renderGiveaways(); });
  const next = el('button', 'btn small', 'Next');
  next.type = 'button';
  next.disabled = page >= pages - 1;
  next.addEventListener('click', () => { state.gawHistoryPage = page + 1; renderGiveaways(); });
  nav.append(prev, el('span', 'muted', `Page ${page + 1} / ${pages}`), next);

  endedWrap.replaceChildren(head, ...list, nav);
}

function buildLiveDropCard(x, { phase }) {
  const d = el('div', `drop-card kind-prize ${phase === 'ended' ? 'is-ended' : 'is-live'}`);
  const gid = gawIdOf(x);
  if (gid) d.dataset.gawId = gid;
  const top = el('div', 'drop-card-top');
  top.append(el('span', 'kind prize', 'PRIZE'));
  const emptyDrop = phase === 'ended' && !!(x.empty || x.needsRestart || (Number(x.entrants) === 0 && !(x.winnersList || []).length));
  const badge = el(
    'span',
    phase === 'ended' ? (emptyDrop ? 'ended-dot empty-dot' : 'ended-dot') : 'live-dot',
    phase === 'ended' ? (emptyDrop ? 'EMPTY' : 'ENDED') : 'LIVE',
  );
  top.append(badge);
  d.append(top);
  d.append(el('div', 'drop-card-title', x.title || 'Drop'));

  if (phase === 'live' && x.endsAt) {
    const c = countdownEl(x.endsAt, x.startedAt);
    const timeBox = el('div', 'drop-card-time');
    timeBox.append(c.node);
    d.append(timeBox);
    d.append(c.bar);
  } else if (phase === 'ended') {
    const emptyDrop = !!(x.empty || x.needsRestart || (Number(x.entrants) === 0 && !(x.winnersList || []).length));
    if (emptyDrop) {
      d.append(el('p', 'hint', 'Ended with no entries — restart to run it again.'));
    } else {
      d.append(el('p', 'hint', `Waiting for prize message → Send to winner${(x.winnersList?.length > 1 || x.winners > 1) ? 's' : ''}`));
      if (x.winnersList?.length) {
        const w = el('div', 'drop-winners');
        for (const win of x.winnersList) {
          const chip = el('span', 'winner-chip', win.name || win.id || 'Winner');
          w.append(chip);
        }
        d.append(w);
      }
    }
  }

  d.append(el('p', 'hint', `${num(x.entrants || 0)} entrants · ${x.winners || 1} winner${(x.winners || 1) === 1 ? '' : 's'}`));
  if (x.shortId) d.append(el('p', 'hint mono', `QL-${x.shortId}`));

  const act = el('div', 'actions');
  if (phase === 'live') {
    const parts = el('button', 'btn small primary', 'Participants');
    parts.type = 'button';
    parts.title = 'View and manage who entered';
    parts.addEventListener('click', () => {
      openGiveawayParticipants(x.messageId, { title: x.title });
    });
    act.append(parts);

    const end = el('button', 'btn small danger', 'End now');
    end.type = 'button';
    end.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'End this giveaway?',
        message: 'Entries lock. Participants can Open Box to see if they won.',
        confirmLabel: 'End giveaway',
      })) return;
      end.disabled = true;
      const out = await post('giveawayend', { messageId: x.messageId, kind: x.kind || 'prize' });
      if (out && out.ok !== false && out.error == null) {
        optimisticGawEnd(x.shortId || x.messageId);
        await leaveNode(d);
        try { renderGiveaways(); } catch (_) {}
        softRefreshOverview();
      } else {
        end.disabled = false;
      }
    });
    act.append(end);
  } else {
    const emptyDrop = !!(x.empty || x.needsRestart || (Number(x.entrants) === 0 && !(x.winnersList || []).length));
    if (emptyDrop) {
      const restart = el('button', 'btn small primary', 'Restart');
      restart.type = 'button';
      restart.title = 'Launch this drop again with fresh settings';
      restart.addEventListener('click', () => openRestartGiveaway(x));
      act.append(restart);

      const del = el('button', 'btn small danger', 'Delete');
      del.type = 'button';
      del.title = 'Remove from panel and delete the channel message if it still exists';
      del.addEventListener('click', async () => {
        if (!await askConfirm({
          title: 'Delete this empty giveaway?',
          message: 'Removes it from the panel and deletes the Discord message when possible.',
          confirmLabel: 'Delete',
          danger: true,
        })) return;
        del.disabled = true;
        const out = await post('giveawaydelete', { shortId: x.shortId, kind: x.kind || 'prize' });
        if (out && out.ok !== false && out.error == null) {
          optimisticGawRemove(x.shortId);
          await leaveNode(d);
          try { renderGiveaways(); } catch (_) {}
          softRefreshOverview();
          toast('Empty giveaway removed.', 'good');
        } else {
          del.disabled = false;
          toast('Could not delete — try again.', 'bad');
        }
      });
      act.append(del);
    } else {
      const open = el('button', 'btn small primary', 'Send prize');
      open.type = 'button';
      open.addEventListener('click', () => openEndedGiveaway(x));
      act.append(open);
    }
  }
  d.append(act);
  return d;
}

/**
 * The detail sheet for a finished giveaway.
 *
 * Reroll and delete both live here rather than as buttons on the card: they
 * are the two destructive-ish things you can do to a finished giveaway, and
 * putting them behind a deliberate tap keeps them off a list you scroll past.
 */

/**
 * Restart sheet for a giveaway that ended with zero entries.
 * Same family as Send prize sheet — channel, duration, ping, winners, then launch.
 */
function openRestartGiveaway(x) {
  const draft = {
    prize: x.title || '',
    winners: Number(x.winners) || 1,
    duration: '1h',
    channelId: x.channelId || '',
    mention: null,
    hostId: x.hostId || null,
    requiredRoleId: x.requiredRoleId || null,
    bonusRoleId: x.bonusRoleId || null,
    minAccountAgeDays: Number(x.minAccountAgeDays) || 0,
    imageUrl: x.imageUrl || 'dynamic:prizeGiveawayBanner',
  };

  const body = [];
  body.push(el('p', 'muted', 'This drop closed with nobody entered. Set the relaunch options and go live again — same prize, fresh timer.'));
  body.push(textField('Prize', draft.prize, v => { draft.prize = v; }));
  body.push(textField('Winners', String(draft.winners), v => {
    const n = parseInt(String(v).trim(), 10);
    if (Number.isInteger(n) && n >= 1 && n <= 100) draft.winners = n;
  }));

  const durBox = el('div', 'field');
  durBox.append(el('label', null, 'How long it runs'));
  const chips = el('div', 'chipset drop-chips');
  const paintDur = () => {
    chips.replaceChildren();
    for (const val of ['30m', '1h', '6h', '24h', '7d']) {
      const b = el('button', 'chip-toggle' + (draft.duration === val ? ' on' : ''), val);
      b.type = 'button';
      b.addEventListener('click', () => { draft.duration = val; paintDur(); });
      chips.append(b);
    }
  };
  paintDur();
  durBox.append(chips);
  if (typeof durationField === 'function') {
    durBox.append(durationField('Custom', draft.duration, v => { draft.duration = v; paintDur(); }, { hideChips: true }));
  } else {
    durBox.append(textField('Custom (e.g. 90m)', draft.duration, v => { draft.duration = v; }));
  }
  body.push(durBox);

  body.push(pickOne('Channel', 'channel', draft.channelId, v => { draft.channelId = v; }, { blank: 'Where it posts' }));
  if (typeof mentionPicker === 'function') {
    body.push(mentionPicker('Optional ping', draft.mention, v => { draft.mention = v; }));
  }
  body.push(pickOne('Required role', 'role', draft.requiredRoleId, v => { draft.requiredRoleId = v; }, { blank: 'Anyone can enter' }));
  body.push(pickOne('Bonus role (extra chance)', 'role', draft.bonusRoleId, v => { draft.bonusRoleId = v; }, { blank: 'No bonus role' }));

  const admins = state.overview?.features?.admins || [];
  if (admins.length) {
    body.push(select(
      'Host',
      draft.hostId || '',
      admins.map(a => ({ value: a.id, label: a.name })),
      v => { draft.hostId = v || null; },
      { blank: 'Pick an admin' },
    ));
  }

  if (x.shortId) body.push(sheetRow('Previous drop', el('span', 'v mono', 'QL-' + x.shortId)));

  const actions = [];
  const go = el('button', 'btn primary', 'Restart giveaway');
  go.type = 'button';
  go.addEventListener('click', async () => {
    if (!draft.prize.trim()) { toast('Set a prize name.', 'bad'); return; }
    if (!draft.channelId) { toast('Pick a channel.', 'bad'); return; }
    go.disabled = true;
    try {
      const res = await post('giveawayrestart', {
        shortId: x.shortId,
        prize: draft.prize.trim(),
        winners: draft.winners,
        duration: draft.duration,
        channelId: draft.channelId,
        mention: draft.mention,
        hostId: draft.hostId,
        requiredRoleId: draft.requiredRoleId,
        bonusRoleId: draft.bonusRoleId,
        minAccountAgeDays: draft.minAccountAgeDays,
        imageUrl: draft.imageUrl,
      });
      if (res?.ok) {
        toast('Giveaway restarted in #' + (res.channelName || 'channel') + '.', 'good');
        closeSheet?.();
        softRefreshOverview();
        try { renderGiveaways(); } catch (_) {}
      }
    } finally {
      go.disabled = false;
    }
  });
  actions.push(go);

  openSheet('Restart · ' + (x.title || 'Giveaway'), body, actions);
}

function openEndedGiveaway(x) {
  const body = [
    sheetRow('Kind', x.kind === 'coins' ? 'Coins giveaway' : 'Prize giveaway'),
    sheetRow('Prize', x.title || 'Giveaway'),
    sheetRow('Entered', num(x.entrants)),
    sheetRow('Winners', String(x.winners)),
    sheetRow('ID', el('span', 'v mono', x.shortId)),
  ];
  if (x.endedAt) body.push(sheetRow('Ended', new Date(x.endedAt).toLocaleString()));

  const winners = Array.isArray(x.winnersList) ? x.winnersList : [];
  if (winners.length) {
    const podium = el('div', 'win-podium');
    podium.append(el('div', 'win-podium-label',
      winners.length === 1 ? 'Selected winner' : `${winners.length} selected winners`));
    const list = el('div', 'win-podium-list');
    winners.forEach((w, i) => {
      const name = String(w.name || '').trim();
      const id = String(w.id || '');
      const display = name && name !== id ? `@${name}` : (id ? `@${id}` : 'Unknown');
      const chip = el('div', 'win-chip');
      chip.append(el('span', 'win-chip-rank', String(i + 1)));
      chip.append(el('span', 'win-chip-name', display));
      if (name && name !== id && id) chip.append(el('span', 'win-chip-meta', id.slice(-4)));
      list.append(chip);
    });
    podium.append(list);
    body.push(podium);
  } else {
    body.push(el('p', 'hint', 'No winner on record for this giveaway yet.'));
  }

  // Prize DM — template system (code / follow-up / custom)
  if (x.kind !== 'coins') {
    const prizeName = x.title || 'your prize';
    let mode = 'code'; // code | followup | custom
    let codeVal = '';
    let customVal = '';

    body.push(el('p', 'hint', 'Pick how the prize is delivered. Code templates put the code in `backticks` in the DM.'));

    const modeRow = el('div', 'chipset drop-chips');
    const codeBox = el('div', 'field prize-code-box');
    const customBox = el('div', 'field prize-custom-box');
    customBox.style.display = 'none';

    const paintModes = () => {
      modeRow.replaceChildren();
      for (const [id, label] of [['code', 'Checkout code'], ['followup', 'Mod follow-up'], ['custom', 'Custom message']]) {
        const b = el('button', 'chip-toggle' + (mode === id ? ' on' : ''), label);
        b.type = 'button';
        b.addEventListener('click', () => {
          mode = id;
          codeBox.style.display = mode === 'code' ? '' : 'none';
          customBox.style.display = mode === 'custom' || mode === 'followup' ? '' : 'none';
          if (mode === 'followup') {
            const ta = customBox.querySelector('textarea, input');
            if (ta && !customVal) {
              customVal = `You won ${prizeName}. A moderator will follow up with you shortly.`;
              ta.value = customVal;
            }
          }
          paintModes();
        });
        modeRow.append(b);
      }
    };
    paintModes();
    body.push(modeRow);

    codeBox.append(el('label', null, 'Checkout / redeem code'));
    const codeInput = el('input');
    codeInput.type = 'text';
    codeInput.placeholder = 'e.g. SAVE50-WEEKEND';
    codeInput.autocomplete = 'off';
    codeInput.spellcheck = false;
    codeInput.addEventListener('input', () => { codeVal = codeInput.value.trim(); });
    codeBox.append(codeInput);
    codeBox.append(el('p', 'hint', 'Only the code is wrapped in backticks in the DM. Not the giveaway ID.'));
    body.push(codeBox);

    customBox.append(el('label', null, 'Message'));
    const customInput = el('textarea');
    customInput.rows = 3;
    customInput.placeholder = 'Optional custom wording for the winner…';
    customInput.addEventListener('input', () => { customVal = customInput.value; });
    customBox.append(customInput);
    body.push(customBox);

    const buildMessage = () => {
      const dropRef = x.shortId ? `QL-${x.shortId}` : '—';
      if (mode === 'code') {
        if (!codeVal) return null;
        return (
          `🎁 Your quantlab prize is ready!\n\n`
          + `**Drop:** \`${dropRef}\`\n`
          + `**Prize:** ${prizeName}\n`
          + `**Your code:** \`${codeVal}\``
        );
      }
      if (mode === 'followup') {
        const extra = customVal.trim();
        if (extra) return extra;
        return (
          `🎁 Your quantlab prize is ready!\n\n`
          + `**Drop:** \`${dropRef}\`\n`
          + `**Prize:** ${prizeName}\n`
          + `A moderator will follow up with next steps.`
        );
      }
      const extra = customVal.trim();
      if (!extra) return null;
      return (
        `🎁 Your quantlab prize is ready!\n\n`
        + `**Drop:** \`${dropRef}\`\n`
        + `**Prize:** ${prizeName}\n\n`
        + extra
      );
    };


    const winners = Array.isArray(x.winnersList) ? x.winnersList : [];
    const multi = winners.length > 1;
    const prizeByWinner = {};
    winners.forEach((w, i) => { prizeByWinner[String(w.id || i)] = { code: '', custom: '' }; });
    let activeWinnerKey = winners[0] ? String(winners[0].id || 0) : '0';

    const winnerTabs = el('div', 'prize-winner-tabs');
    const syncWinnerTabs = () => {
      winnerTabs.replaceChildren();
      if (!multi) return;
      winners.forEach((w, i) => {
        const key = String(w.id || i);
        const name = (w.name || w.id || ('Winner ' + (i + 1)));
        const label = name.startsWith('@') ? name : '@' + name;
        const b = el('button', 'prize-winner-tab' + (key === activeWinnerKey ? ' on' : ''), label);
        b.type = 'button';
        b.addEventListener('click', () => {
          // stash current fields
          const prev = prizeByWinner[activeWinnerKey] || { code: '', custom: '' };
          prev.code = codeVal;
          prev.custom = customVal;
          prizeByWinner[activeWinnerKey] = prev;
          activeWinnerKey = key;
          const next = prizeByWinner[key] || { code: '', custom: '' };
          codeVal = next.code || '';
          customVal = next.custom || '';
          codeInput.value = codeVal;
          customInput.value = customVal;
          syncWinnerTabs();
        });
        winnerTabs.append(b);
      });
    };
    if (multi) {
      body.push(el('p', 'hint', 'Set a prize message per winner, then send.'));
      body.push(winnerTabs);
      syncWinnerTabs();
    }

    const sendLabel = multi ? 'Send to winners' : 'Send to winner';
    const sendPrize = el('button', 'btn primary small', sendLabel);

    sendPrize.type = 'button';
    sendPrize.addEventListener('click', async () => {
      if (multi) {
        const prev = prizeByWinner[activeWinnerKey] || { code: '', custom: '' };
        prev.code = codeVal;
        prev.custom = customVal;
        prizeByWinner[activeWinnerKey] = prev;
      }
      sendPrize.disabled = true;
      sendPrize.textContent = 'Sending…';
      try {
        let sent = 0, total = 0;
        const list = multi ? winners : (winners.length ? winners : [{ id: null }]);
        for (let i = 0; i < list.length; i++) {
          const w = list[i];
          const key = String(w.id || i);
          if (multi) {
            const bag = prizeByWinner[key] || {};
            codeVal = bag.code || '';
            customVal = bag.custom || '';
          }
          const text = buildMessage();
          if (!text) {
            toast(multi ? ('Missing prize text for ' + (w.name || w.id || 'a winner')) : (mode === 'code' ? 'Enter the checkout code first.' : 'Write a prize message first.'), 'bad');
            sendPrize.disabled = false;
            sendPrize.textContent = sendLabel;
            return;
          }
          const payload = { shortId: x.shortId, text };
          if (w.id) payload.winnerId = String(w.id);
          const out = await post('giveawaysendprize', payload);
          total += 1;
          if (out && out.ok !== false) sent += (out.sent != null ? out.sent : 1);
        }
        toast(multi ? ('Prize DMs sent (' + sent + '/' + total + ').') : (sent ? 'Prize DM sent.' : 'Prize DM sent.'), 'good');
        sendPrize.textContent = 'Sent';
        // Leave Live immediately → Recent drops (soft animation)
        try {
          const g = state.overview && state.overview.giveaways;
          const id = String(x.shortId || '').toLowerCase();
          if (g && id) {
            const hit = (g.ended || []).find((e) => String(e.shortId || '').toLowerCase() === id);
            if (hit) hit.prizeDmSent = true;
          }
          document.querySelectorAll('[data-gaw-id="' + CSS.escape(String(x.shortId || '').toLowerCase()) + '"]').forEach((n) => {
            if (typeof leaveNode === 'function') leaveNode(n);
            else { n.classList.add('is-leaving'); setTimeout(() => n.remove(), 220); }
          });
          closeSheet();
          if (typeof renderGiveaways === 'function') renderGiveaways();
          if (typeof softRefreshOverview === 'function') softRefreshOverview();
        } catch (_) {}
      } catch (e) {
        sendPrize.disabled = false;
        sendPrize.textContent = sendLabel;
      }
    });
    body.push(sendPrize);
  }

  const multiW = (Array.isArray(x.winnersList) ? x.winnersList.length : Number(x.winners || 1)) > 1;
  const reroll = el('button', 'btn primary small', multiW ? 'Reroll winners' : 'Reroll winner');
  reroll.type = 'button';
  reroll.addEventListener('click', async () => {
    reroll.disabled = true;
    reroll.textContent = 'Drawing…';
    const out = await post('giveawayreroll', { shortId: x.shortId, kind: x.kind });
    if (out && out.ok !== false && out.error == null) {
      closeSheet();
      softRefreshOverview().then(() => { try { renderGiveaways(); } catch (_) {} });
    } else {
      reroll.disabled = false;
      reroll.textContent = multiW ? 'Reroll winners' : 'Reroll winner';
    }
  });

  const del = el('button', 'btn small danger', 'Delete from panel');
  del.type = 'button';
  del.addEventListener('click', async () => {
    if (del.dataset.armed !== '1') {
      del.dataset.armed = '1';
      del.textContent = 'Tap again to delete';
      return;
    }
    del.disabled = true;
    const out = await post('giveawaydelete', { shortId: x.shortId, kind: x.kind });
    if (out && out.ok !== false && out.error == null) {
      optimisticGawRemove(x.shortId);
      closeSheet();
      try { renderGiveaways(); } catch (_) {}
      softRefreshOverview();
    } else {
      del.disabled = false;
      del.dataset.armed = '';
      del.textContent = 'Delete from panel';
    }
  });

  openSheet(x.title || 'Giveaway', body, [reroll, del]);

}

/* ── previewing an embed ───────────────────────────────────────────────────
   A rendering of the draft in hand, in the sheet, so the page behind blurs
   away and the only thing left to look at is the message.

   It is a likeness, not Discord: the colour spine, the type scale and the
   field grid are what make an embed recognisable at a glance, and those are
   what this reproduces. */

/** The placeholders embed.js substitutes at send time, filled in as it would. */
function fillPlaceholders(text) {
  const g = state.overview?.guild;
  return String(text ?? '')
    .replace(/\{user\}/g, `@${state.me?.name || 'you'}`)
    .replace(/\{username\}/g, state.me?.name || 'you')
    .replace(/\{server\}/g, g?.name || 'this server')
    .replace(/\{membercount\}/g, g ? num(g.members) : '0')
    .replace(/\{channel\}/g, '#channel');
}

/**
 * Fetches a generated image into an <img>.
 *
 * The blob URL is handed back so the sheet can revoke it on close — an
 * object URL left behind pins the whole buffer in memory for the life of the
 * page, and a preview is the last thing that should leak.
 */
async function loadDynamicPreview(img, key, revocables) {
  try {
    const url = `/api/preview-image/${encodeURIComponent(key)}${state.guildId ? `?g=${state.guildId}` : ''}`;
    const res = await fetch(url, { credentials: 'same-origin', headers: authHeaders() });
    if (!res.ok) throw new Error(String(res.status));
    const objectUrl = URL.createObjectURL(await res.blob());
    revocables.push(objectUrl);
    img.src = objectUrl;
    img.hidden = false;
  } catch {
    // The alternative is a broken-image icon, which reads as a bug rather
    // than as art that could not be drawn right now.
    img.replaceWith(el('p', 'hint', `Generated image “${key}” could not be drawn just now — it will still be attached when this is sent.`));
  }
}

/** A picture in the preview, only shown once it has actually loaded. */
function previewPicture(url, className) {
  const img = el('img');
  img.className = className;
  img.alt = '';
  img.hidden = true;
  img.addEventListener('load', () => { img.hidden = false; });
  // A URL that does not resolve leaves nothing rather than a broken-image
  // glyph, which reads as the preview being broken rather than the address.
  img.addEventListener('error', () => { img.replaceWith(el('p', 'hint', 'That picture would not load.')); });
  img.src = url;
  return img;
}

function openEmbedPreview(draft) {
  const revocables = [];
  const body = [];

  const buttons = (state.overview?.composer || []).find(t => t.name === draft.name)?.buttons
    || draft.buttons || [];

  // The line over the top is part of the message, so it is part of the
  // likeness — and seeing it above the box is the only way to tell it is
  // going where you meant.
  const around = draft.around || {};
  if (!draft.embeds?.length && around.pictureAbove) {
    if (String(around.pictureAbove).startsWith('dynamic:')) {
      const img = el('img');
      img.className = 'big';
      img.alt = '';
      img.hidden = true;
      body.push(img);
      loadDynamicPreview(img, around.pictureAbove.slice(8), revocables);
    } else {
      body.push(previewPicture(around.pictureAbove, 'big'));
    }
    body.push(el('p', 'hint', 'Image above (own message)'));
  }
  if (around.above) body.push(el('p', 'demb-say', fillPlaceholders(around.above)));

  draft.embeds.forEach(e => {
    const box = el('div', 'demb');
    box.style.borderLeftColor = /^#[0-9a-f]{6}$/i.test(e.color || '') ? e.color : '#5865F2';

    if (e.authorName) {
      const author = el('p', 'demb-auth');
      if (e.authorIcon) author.append(previewPicture(e.authorIcon, 'demb-auth-ic'));
      author.append(el('span', null, fillPlaceholders(e.authorName)));
      box.append(author);
    }
    if (e.title) box.append(el('p', 't', fillPlaceholders(e.title)));
    if (e.description) box.append(el('p', 'd', fillPlaceholders(e.description)));

    if (e.fields?.length) {
      const f = el('div', 'f');
      for (const fd of e.fields) {
        if (!fd.name && !fd.value) continue;
        const cell = el('div');
        // Inline fields sit side by side; block fields take the full width,
        // which is the single most visible thing the inline switch does.
        if (!fd.inline) cell.style.flexBasis = '100%';
        cell.append(el('b', null, fillPlaceholders(fd.name || '​')));
        cell.append(el('span', null, fillPlaceholders(fd.value || '')));
        f.append(cell);
      }
      if (f.childElementCount) box.append(f);
    }

    if (e.thumbnail) {
      // Wrapped, so the square sits beside what came before it rather than
      // on top of it — the same row the Appearance preview uses.
      const row = el('div', 'demb-row');
      const main = el('div', 'demb-main');
      while (box.firstChild) main.append(box.firstChild);
      row.append(main, previewPicture(e.thumbnail, 'demb-thumb-img'));
      box.append(row);
    }

    if (e.image) {
      if (e.image.startsWith('dynamic:')) {
        const img = el('img');
        img.className = 'big';
        img.alt = '';
        img.hidden = true;
        box.append(img);
        loadDynamicPreview(img, e.image.slice(8), revocables);
      } else {
        box.append(previewPicture(e.image, 'big'));
      }
    }

    const footBits = [];
    if (e.footer) footBits.push(fillPlaceholders(e.footer));
    if (e.timestamp) footBits.push(new Date().toLocaleString());
    if (footBits.length) {
      const ft = el('p', 'ft');
      if (e.footerIcon) ft.append(previewPicture(e.footerIcon, 'demb-auth-ic'));
      ft.append(el('span', null, footBits.join(' • ')));
      box.append(ft);
    }

    body.push(box);
  });

  if (buttons.length) {
    const row = el('div', 'demb-btns');
    for (const b of buttons) {
      const chip = el('span', b.type === 'link' ? 'link' : (b.style || 'Primary'),
        `${b.emoji ? `${b.emoji} ` : ''}${b.label || b.id}`);
      row.append(chip);
    }
    body.push(row);
  }

  if (around.below || around.picture) {
    const second = el('div', 'demb-second');
    second.append(el('p', 'hint', 'Sent as a second message, right underneath'));
    if (around.below) second.append(el('p', 'demb-say', fillPlaceholders(around.below)));
    if (around.picture) second.append(previewPicture(around.picture, 'big'));
    body.push(second);
  }

  if (!body.length) body.push(el('p', 'muted', 'Nothing to show yet — add a title or description.'));
  body.push(el('p', 'hint', 'A likeness of the message, not a screenshot of Discord. Placeholders are filled in the way they will be when it is sent.'));

  openSheet(draft.name ? `Preview · ${draft.name}` : 'Preview', body, [], () => {
    for (const url of revocables) URL.revokeObjectURL(url);
  });
}

/* ── social ────────────────────────────────────────────────────────────────
   Accounts on YouTube and TikTok, relayed into a channel as
   they post. The cards are styled on Appearance — this screen is only about
   which accounts, where they land and how often they are checked. */

const SOCIAL_ERRORS = {
  bad_bridge: 'The bridge address must start with https.',
  bad_interval: 'Check between every 2 minutes and every 6 hours.',
  bad_batch: 'Post between 1 and 10 at a time.',
  bad_platform: 'Pick one of the four platforms.',
  bad_feed_url: 'A feed address must start with https.',
  need_handle: 'Give it an account name, or a feed address.',
  too_many_accounts: 'That is as many accounts as one server can watch.',
  unknown_account: 'That account is no longer listed.',
  bad_keywords: 'One of those words is too long.',
  no_channel: 'Set a channel for it to post in first.',
  fetch_failed: 'Could not read that feed.',
  send_failed: 'Could not post to that channel.',
  nothing_to_post: 'That feed has nothing in it right now.',
};
Object.assign(WRITE_ERRORS, SOCIAL_ERRORS);

const ago = ms => {
  if (!ms) return 'never';
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} d ago`;
};

/**
 * The bits of Discord markdown worth drawing in a preview.
 *
 * Nodes, never HTML: every piece of this is either something typed into a box
 * on this page or a value from the server, and the whole panel's rule is that
 * nothing is ever assigned as markup. **bold**, *italic* and [text](url) are
 * the three that change how a card reads — the social cards default to a
 * bolded link, which without this shows as a line of asterisks and brackets.
 */
function mdNodes(text, depth = 0) {
  const out = [];
  const src = String(text ?? '');
  const re = /\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)|\*\*([\s\S]+?)\*\*|\*([^*\n]+)\*|`([^`\n]+)`/g;
  let last = 0;
  for (const m of src.matchAll(re)) {
    if (m.index > last) out.push(document.createTextNode(src.slice(last, m.index)));
    if (m[1] !== undefined) {
      const a = el('span', 'md-link', m[1]);
      a.title = m[2];
      out.push(a);
    } else if (m[3] !== undefined) {
      // Recursive, because these nest: the social cards default to a bolded
      // link, and reading ** first swallowed the whole [text](url) inside it
      // and drew the brackets literally. Depth-capped so a pathological
      // string cannot spin.
      const b = el('b');
      b.append(...(depth < 4 ? mdNodes(m[3], depth + 1) : [document.createTextNode(m[3])]));
      out.push(b);
    } else if (m[4] !== undefined) {
      const i = el('i');
      i.append(...(depth < 4 ? mdNodes(m[4], depth + 1) : [document.createTextNode(m[4])]));
      out.push(i);
    } else {
      // Code is literal by definition — nothing inside it is markup.
      out.push(el('code', null, m[5]));
    }
    last = m.index + m[0].length;
  }
  if (last < src.length) out.push(document.createTextNode(src.slice(last)));
  return out.length ? out : [document.createTextNode(src)];
}


/** The words box — comma separated, because that is how people write lists. */
function wordsField(label, values, onChange, hint) {
  const l = el('label', 'field');
  l.append(el('span', null, label));
  const input = el('input');
  input.type = 'text';
  input.value = (values || []).join(', ');
  input.placeholder = 'clip, live, giveaway';
  input.addEventListener('input', () => {
    onChange(input.value.split(',').map(s => s.trim()).filter(Boolean));
  });
  l.append(input);
  const wrap = el('div');
  wrap.append(l);
  if (hint) wrap.append(el('p', 'hint', hint));
  return wrap;
}

function renderSocial() {
  /* Social feature removed — no-op */
  return;
  /* dead code below kept only so structure stays valid until a later cleanup */

  const d = state.overview?.social;
  if (!d) return;

  const statePill = $('#social-state');
  if (statePill) {
    const live = d.enabled && !!d.channelId;
    statePill.textContent = d.enabled ? (d.channelId ? 'Watching' : 'No channel set') : 'Off';
    // On when it is actually working, amber when it is switched on but cannot
    // post anywhere, grey when it is off. A pill with no state class at all
    // takes its colour from whatever it sits inside, which reads as neither.
    statePill.className = `pill ${live ? 'on' : d.enabled ? 'wait' : 'off'}`;
  }

  /* -- where posts land --------------------------------------------------- */
  const s = {
    enabled: d.enabled, channelId: d.channelId, mentionRoleId: d.mentionRoleId,
  };
  const landNote = el('p', 'hint', '');
  const syncLand = () => {
    const watching = d.accounts.filter(a => a.enabled).length;
    landNote.textContent = !s.enabled
      ? 'Nothing is being checked.'
      : !s.channelId
        ? 'Pick a channel — until then there is nowhere for a post to go.'
        : `${watching} account${watching === 1 ? '' : 's'} being watched.`;
    landNote.className = `hint${s.enabled && !s.channelId ? ' bad' : ''}`;
  };

  $('#form-social').replaceChildren(
    toggle('Watch social accounts', s.enabled, v => { s.enabled = v; syncLand(); }),
    pickOne('Channel', 'channel', s.channelId, v => { s.channelId = v; syncLand(); }),
    pickOne('Ping this role', 'role', s.mentionRoleId, v => { s.mentionRoleId = v; }),
    landNote,
    actions(() => post('social', s)),
  );
  syncLand();

  /* -- how often ----------------------------------------------------------
     Everything about *how* a platform is reached lives behind Advanced. Most
     of it is jargon nobody should have to learn to watch a YouTube channel,
     and all of it has a working default. */
  const b = { pollMinutes: d.pollMinutes, maxPerCheck: d.maxPerCheck };

  // The helper-service box and its connection test are gone with the three
  // platforms that needed one. YouTube publishes its own feed, so there is
  // nothing in between to configure or to test — and a box that changes
  // nothing is worse than no box.
  const note = el('p', 'hint', '');
  const failing = d.accounts.filter(a => a.lastError).length;
  note.textContent = failing
    ? `${failing} channel${failing === 1 ? ' is' : 's are'} not loading — open one to see why.`
    : 'YouTube hands out its posts directly, so there is nothing in between to set up.';
  note.className = `hint${failing ? ' bad' : ''}`;

  $('#form-social-bridge').replaceChildren(
    textField('Check every (minutes)', String(b.pollMinutes), v => { b.pollMinutes = Number(v); }),
    textField('At most this many per check', String(b.maxPerCheck), v => { b.maxPerCheck = Number(v); }),
    el('p', 'hint', 'The cap stops a channel that has been quiet for a week filling your server the moment it posts again.'),
    note,
    actions(() => post('social', b)),
  );

  /* -- the accounts ------------------------------------------------------- */
  const wrap = $('#social-accounts');
  const rows = [];

  if (state.socialDraft) rows.push(socialAccountCard(state.socialDraft, d, true));
  if (!d.accounts.length && !state.socialDraft) {
    rows.push(el('p', 'muted', 'No accounts watched yet. Add one and its posts will land in your channel as they go out.'));
  }
  for (const a of d.accounts) {
    rows.push(state.socialOpen?.has(a.id) ? socialAccountCard(a, d, false) : socialStrip(a, d));
  }

  // The cards are styled with every other message the bot sends, not here.
  // Saying so with a button beats leaving someone to find it.
  const toStyle = el('button', 'btn small', 'Style these cards on Appearance');
  toStyle.type = 'button';
  toStyle.addEventListener('click', () => {
    state.styleKey = 'social.youtube';
    showSection('appearance');
    renderAppearance();
    paintBar();
  });
  const styleRow = el('div', 'actions');
  styleRow.append(toStyle);
  rows.push(styleRow);

  wrap.replaceChildren(...rows);
}

/**
 * A brand colour, lifted just far enough to be seen on the panel's own cards.
 *
 * X's brand colour is black, and the panel's card is nearly black, so the
 * stripe down the side of its row disappeared and the row read as broken. The
 * lift is for the panel only — the posted card keeps the real colour, where
 * the background is lighter and black is exactly right.
 */
function visibleBrand(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
  if (!m) return hex;
  const n = parseInt(m[1], 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  // The brightest channel, not perceptual luma. Luma weights red at a tenth of
  // green, so it scores pure #FF0000 as dark and would have quietly lightened
  // YouTube's red — a colour that is perfectly visible as a stripe. What
  // actually matters against a near-black card is whether any channel is lit
  // at all, which is what this measures.
  const peak = Math.max(r, g, b);
  // High enough that the stripe still reads on a paused row, which is drawn
  // at just over half opacity.
  const floor = 96;
  if (peak >= floor) return `#${m[1]}`;
  // Lifted towards white rather than towards its own hue, so a black stays a
  // grey instead of becoming some colour the brand never chose.
  const k = (floor - peak) / 255;
  r = Math.round(r + (255 - r) * k);
  g = Math.round(g + (255 - g) * k);
  b = Math.round(b + (255 - b) * k);
  return `#${[r, g, b].map(v => v.toString(16).padStart(2, '0')).join('')}`;
}

/**
 * The platform's mark.
 *
 * The picture the panel serves, which is the same one the posted card carries
 * — one drawing, so the list and the message can never show different logos.
 * The platform's colour sits behind it as a plain disc until it loads, so a
 * slow or blocked image leaves the row its shape rather than a gap.
 */
function platformMark(platform) {
  const badge = el('span', 'social-badge');
  badge.style.background = platform.color;
  if (!platform.mark) return badge;
  const img = el('img');
  img.src = platform.mark;
  img.alt = '';
  img.addEventListener('load', () => { badge.style.background = 'none'; });
  badge.append(img);
  return badge;
}

/**
 * A fold-away section. Native <details>, so it needs no script to open.
 *
 * The key is what makes it survive a redraw. Saving re-renders the screen from
 * the server's reply, and a fresh <details> starts closed — so a section you
 * had opened would snap shut under you, taking with it whatever you had just
 * asked for. The Test-the-connection result landed inside one of these.
 */
function disclosure(key, label, nodes) {
  const box = el('details', 'disc');
  const head = el('summary', null, label);
  box.append(head, ...nodes);
  if (state.openFolds?.has(key)) box.open = true;
  box.addEventListener('toggle', () => {
    if (!state.openFolds) state.openFolds = new Set();
    if (box.open) state.openFolds.add(key);
    else state.openFolds.delete(key);
  });
  return box;
}

/**
 * How an account is doing, in one word and one colour.
 *
 * Green once it is posting, amber while it has not been looked at yet, red
 * when the last look failed, grey when it is switched off.
 */
function socialHealth(a) {
  if (!a.enabled) return { tone: 'off', word: 'Paused' };
  if (a.lastError) return { tone: 'bad', word: 'Not loading' };
  if (!a.lastCheckedAt) return { tone: 'wait', word: 'Not checked yet' };
  if (a.posts) return { tone: 'on', word: `${a.posts} posted` };
  return { tone: 'on', word: 'Watching' };
}

/**
 * The collapsed account: a strip you can read a list of at a glance.
 *
 * A watched account is mostly something you set up once and then only want to
 * see the state of. Fifteen inputs each is unreadable at four accounts, so
 * the list collapses to this and opens on a tap.
 */
function socialStrip(account, d) {
  const platform = d.platforms.find(p => p.key === account.platform) || d.platforms[0];
  const health = socialHealth(account);

  const strip = el('button', 'social-strip');
  strip.type = 'button';
  strip.style.borderLeftColor = visibleBrand(platform.color);
  strip.setAttribute('aria-expanded', 'false');
  if (!account.enabled) strip.classList.add('off');

  const names = el('span', 'social-names');
  names.append(
    el('span', 'nm', account.label || account.handle || platform.label),
    el('span', 'mt', `${platform.label}${account.label && account.handle ? ` · ${account.handle}` : ''}`),
  );

  const state_ = el('span', `pill ${health.tone}`, health.word);
  const chev = el('span', 'social-chev', '›');

  strip.append(platformMark(platform), names, state_, chev);
  strip.addEventListener('click', () => {
    if (!state.socialOpen) state.socialOpen = new Set();
    state.socialOpen.add(account.id);
    renderSocial();
  });
  return strip;
}

/** One account, opened up: the few things worth changing, and the rest folded away. */
function socialAccountCard(account, d, isNew) {
  const platform = d.platforms.find(p => p.key === account.platform) || d.platforms[0];
  const draft = { id: isNew ? '' : account.id, ...account };

  const card = el('article', 'panel social-card');
  card.style.borderLeftColor = visibleBrand(platform.color);
  if (!isNew && !account.enabled) card.classList.add('off');

  const head = el('div', 'queue-head');
  const title = el('h2', null, isNew ? 'New account' : (account.label || account.handle));
  const headLeft = el('div', 'social-head-left');
  headLeft.append(platformMark(platform), title);
  head.append(headLeft);

  if (!isNew) {
    const fold = el('button', 'btn small', 'Collapse');
    fold.type = 'button';
    fold.addEventListener('click', () => {
      state.socialOpen?.delete(account.id);
      renderSocial();
    });
    head.append(fold);
  }
  card.append(head);

  /* -- the few things worth asking for ----------------------------------- */
  const basics = el('div');
  basics.append(
    select('Platform', draft.platform, d.platforms.map(p => ({ value: p.key, label: p.label })),
      v => {
        draft.platform = v;
        // The hint under the name box is per platform, so the card is redrawn
        // rather than left describing the wrong one.
        if (isNew) { state.socialDraft = { ...draft }; renderSocial(); }
      }),
    textField('Account name', draft.handle, v => { draft.handle = v; },
      { placeholder: platform.direct ? '@channelhandle' : '@username' }),
    el('p', 'hint', platform.direct
      ? 'A @handle, or the link to the channel — either works.'
      : 'The @name from their profile.'),
    textField('Show them as (optional)', draft.label || '', v => { draft.label = v; }),
    toggle('Watching', draft.enabled !== false, v => { draft.enabled = v; }),
  );
  card.append(basics);

  /* -- and the rest, folded away ------------------------------------------ */
  card.append(disclosure(`social:more:${draft.id || 'new'}`, 'More options', [
    pickOne('Post to (leave blank for the main channel)', 'channel', draft.postChannelId, v => { draft.postChannelId = v; }),
    pickOne('Ping (leave blank for the main role)', 'role', draft.mentionRoleId, v => { draft.mentionRoleId = v; }),
    wordsField('Only post if it mentions', draft.includeKeywords, v => { draft.includeKeywords = v; },
      'Comma separated. Leave empty to post everything.'),
    wordsField('Never post if it mentions', draft.excludeKeywords, v => { draft.excludeKeywords = v; },
      'Checked first — a post matching both is skipped.'),
    textField('Read from this address instead', draft.feedUrl || '', v => { draft.feedUrl = v; },
      { placeholder: 'https://…' }),
    el('p', 'hint', 'Only if somebody has given you one. It replaces the normal way this account is read.'),
  ]));

  /* -- how it is doing ---------------------------------------------------- */
  if (!isNew) {
    const status = el('div', 'rows social-status');
    status.append(
      row('Last checked', ago(account.lastCheckedAt)),
      row('Last posted', ago(account.lastPostedAt)),
      row('Posted so far', num(account.posts)),
    );
    if (account.lastError) {
      const errRow = row('Last error', account.lastError);
      errRow.classList.add('bad');
      status.append(errRow);
    }
    card.append(status);
  }

  // Same reason as the bridge result: kept in state so a re-render does not
  // take the answer off the screen a moment after it appeared.
  const out = el('div', 'social-out');
  if (!isNew && state.socialTests?.[account.id]) {
    out.append(socialTestResult(state.socialTests[account.id]));
  }
  card.append(out);

  const foot = el('div', 'actions');
  const save = el('button', 'btn primary small', isNew ? 'Start watching' : 'Save');
  save.type = 'button';
  save.addEventListener('click', async () => {
    save.disabled = true;
    try {
      const res = await post('socialaccount', {
        id: draft.id || undefined,
        platform: draft.platform,
        handle: draft.handle,
        label: draft.label || '',
        feedUrl: draft.feedUrl || '',
        postChannelId: draft.postChannelId || null,
        mentionRoleId: draft.mentionRoleId || null,
        includeKeywords: draft.includeKeywords || [],
        excludeKeywords: draft.excludeKeywords || [],
        enabled: draft.enabled !== false,
      });
      if (res?.ok) {
        state.socialDraft = null;
        // A newly added account opens, so its status is visible straight away
        // rather than needing to be found and tapped.
        if (!state.socialOpen) state.socialOpen = new Set();
        if (res.id) state.socialOpen.add(res.id);
        state.overview = await get(`/api/guild/${state.guildId}`);
        renderOverview();
      }
    } finally { save.disabled = false; }
  });
  foot.append(save);

  if (isNew) {
    const cancel = el('button', 'btn small', 'Cancel');
    cancel.type = 'button';
    cancel.addEventListener('click', () => { state.socialDraft = null; renderSocial(); });
    foot.append(cancel);
  } else {
    const test = el('button', 'btn small', 'Test');
    test.type = 'button';
    test.addEventListener('click', async () => {
      test.disabled = true;
      test.textContent = 'Reading…';
      try {
        const res = await post('socialtest', { id: account.id }, { quiet: true });
        if (!state.socialTests) state.socialTests = {};
        state.socialTests[account.id] = res?.ok
          ? res
          : { failed: true, detail: 'The check could not be run.' };
        renderSocial();
      } finally { test.disabled = false; test.textContent = 'Test'; }
    });

    const now = el('button', 'btn small', 'Post the latest');
    now.type = 'button';
    now.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'Post the latest one now?',
        message: 'The newest post goes into the channel straight away. It does not skip anything — the next real check still posts whatever is new.',
        confirmLabel: 'Post it',
      })) return;
      now.disabled = true;
      try { await post('socialpost', { id: account.id }); }
      finally { now.disabled = false; }
    });

    const del = el('button', 'btn small danger', 'Stop watching');
    del.type = 'button';
    del.addEventListener('click', async () => {
      if (!await askConfirm({
        title: `Stop watching ${account.label || account.handle}?`,
        message: 'Its posts stop arriving. Nothing already in the channel is touched.',
        confirmLabel: 'Stop watching',
      })) return;
      const res = await post('socialaccount', { id: account.id, remove: true });
      if (res?.ok) {
        state.socialOpen?.delete(account.id);
        state.overview = await get(`/api/guild/${state.guildId}`);
        renderOverview();
      }
    });

    foot.append(test, now, del);
  }
  card.append(foot);
  return card;
}

/** What a Test came back with — the three newest, or the reason there are none. */
function socialTestResult(res) {
  const box = el('div', 'social-test');
  if (res.failed) {
    box.append(el('p', 'hint bad', res.detail || 'Could not read it.'));
    // Every address that was tried, and what each one said. When a route has
    // been renamed this is the difference between "404" and knowing which
    // address 404'd.
    for (const t of res.tried || []) {
      box.append(el('p', 'hint mono', `${t.url} — ${t.why}`));
    }
    if (!(res.tried || []).length && res.url) box.append(el('p', 'hint mono', res.url));
    return box;
  }

  box.append(el('p', 'hint', `${res.found} post${res.found === 1 ? '' : 's'} found · ${res.keptByFilters} would pass your filters`));
  if (!res.baselineSet) {
    box.append(el('p', 'hint', 'Nothing has been posted from this account yet — the first check sets a starting point, and everything after that arrives. Use "Post the latest" if you want to see the card now.'));
  }
  const list = el('div', 'rows');
  for (const item of res.sample) {
    const r = row(new Date(item.published).toLocaleString(), item.title);
    if (!item.keptByFilters) r.classList.add('dim');
    list.append(r);
  }
  box.append(list);
  return box;
}

/* ── appearance: the messages the bot sends on its own ─────────────────────
   The Composer covers messages you write. This covers the other kind — the
   warning card, the mod-log entry, the goodbye, the level-up — which used to
   be hard-coded and needed a redeploy to change. */

/**
 * Token substitution, matching utils/messageStyle.js fill().
 *
 * There are deliberately two implementations. The server's is the one that
 * actually sends, and the preview you see on load comes from it; this one
 * exists so the preview keeps up while you type, which a round trip per
 * keystroke could not. The rule is small enough to hold in both places: a
 * token nobody supplied becomes nothing, and a line whose tokens *all* came
 * back empty is dropped rather than left as a label for something absent.
 */
function fillTokens(text, values) {
  if (!text) return '';
  const kept = [];
  for (const line of String(text).split('\n')) {
    let sawToken = false;
    let sawValue = false;
    const filled = line.replace(/\{(\w+)\}/g, (whole, name) => {
      sawToken = true;
      const lower = name.toLowerCase();
      const raw = Object.hasOwn(values, name) ? values[name]
        : (name === name.toUpperCase() && Object.hasOwn(values, lower) ? String(values[lower]).toUpperCase() : '');
      const value = raw === null || raw === undefined ? '' : String(raw);
      if (value !== '') sawValue = true;
      return value;
    });
    if (sawToken && !sawValue) continue;
    kept.push(filled.replace(/[ \t]+$/, ''));
  }
  return kept.join('\n').trim();
}

/** Draws one message the way Discord will, from the values being edited. */
/**
 * The editors for one message's buttons.
 *
 * A row each: what it says, what it says it with, and what colour it is. The
 * id is shown but never editable — it is what the bot routes the press on, so
 * a typed one would be a button that looks right and does nothing.
 */
function buttonEditors(entry, values, repaint) {
  const wrap = el('div', 'subfields');
  wrap.append(el('h2', null, 'Buttons'));
  values.buttons = values.buttons || [];

  if (!values.buttons.length) {
    wrap.append(el('p', 'hint', 'This message has no buttons.'));
    return wrap;
  }

  for (const b of values.buttons) {
    const row = el('div', 'subfield');
    const head = el('div', 'btn-editor-head');
    head.append(el('span', 'tag', b.id));
    if (b.does) head.append(el('span', 'hint', b.does));
    row.append(head);
    row.append(
      textField('What it says', b.label, v => { b.label = v; repaint(); }),
      textField('Emoji', b.emoji, v => { b.emoji = v; repaint(); }),
      select('Colour', b.style, (entry.buttonStyles || []).map(x => ({ value: x, label: BUTTON_STYLE_LABEL[x] || x })),
        v => { b.style = v; repaint(); }),
    );
    wrap.append(row);
  }
  wrap.append(el('p', 'hint', 'Leave the words empty to have the emoji stand alone — but not both, or Discord refuses the whole message.'));
  return wrap;
}

// Discord's names for these are about intent, not colour, and the colour is
// the thing you are actually choosing.
const BUTTON_STYLE_LABEL = {
  Primary: 'Blurple', Secondary: 'Grey', Success: 'Green', Danger: 'Red',
};

/**
 * The colour of each kind of card the bot sends without an entry of its own.
 *
 * A swatch each rather than a card each: there are seventeen, they differ only
 * in colour, and a list of seventeen near-identical editors is a screen nobody
 * can find anything on.
 */
function paletteEditors(entry, values, repaint) {
  const wrap = el('div', 'palette');
  values.palette = { ...(values.palette || {}) };
  for (const kind of entry.palette || []) {
    const row = el('div', 'palette-row');
    const head = el('div', 'palette-head');
    head.append(el('span', 'nm', kind.label));
    if (kind.does) head.append(el('span', 'hint', kind.does));
    row.append(head);
    row.append(colorField('', values.palette[kind.key] || kind.color, v => {
      values.palette[kind.key] = v;
      repaint();
    }));
    wrap.append(row);
  }
  return wrap;
}

function stylePreview(entry, values, sample) {
  // The palette has no one card to preview — it is the colour of two hundred
  // of them. A row of spines is a truer likeness than an empty box.
  if (entry.parts.includes('palette')) {
    const wrap = el('div', 'palette-preview');
    for (const kind of entry.palette || []) {
      const chip = el('div', 'demb');
      chip.style.borderLeftColor = values.palette?.[kind.key] || kind.color;
      chip.append(el('p', 't', kind.label));
      wrap.append(chip);
    }
    return wrap;
  }

  const box = el('div', 'demb');
  box.style.borderLeftColor = /^#[0-9a-f]{6}$/i.test(values.color || '') ? values.color : '#5865F2';

  const title = fillTokens(values.title, sample);
  const body = fillTokens(values.body, sample);

  if (entry.shape === 'action') {
    // The compact card: avatar and the line together on one row. The avatar is
    // drawn rather than fetched — a real one would be a request to Discord's
    // CDN for a picture nobody is looking at, and it would show as broken
    // anywhere the panel is opened without a route out.
    const a = el('div', 'a lead');
    a.append(el('span', 'av'), el('span', null, title || 'Update'));
    box.append(a);
    if (body) { const d = el('p', 'd'); d.append(...mdNodes(body)); box.append(d); }
    return box;
  }

  // The corner picture is a real element beside the text rather than something
  // floated over the top of it. It used to be an ::after pinned to the
  // corner, which on a card shorter than the square itself — a card that is
  // only a timestamp, say — hung out of the bottom and sat on the sentence
  // underneath.
  const main = el('div', 'demb-main');
  if (title) main.append(el('p', 't', title));
  if (body) { const d = el('p', 'd'); d.append(...mdNodes(body)); main.append(d); }

  // The rows the bot fills in at send time. Shown greyed so it is clear the
  // card will be taller than the parts on the left, without implying they can
  // be edited here.
  for (const f of entry.fixedFields || []) {
    const fixed = el('div', 'f fixed');
    const cell = el('div');
    cell.style.flexBasis = '100%';
    cell.append(el('b', null, f));
    cell.append(el('span', null, 'added when it is sent'));
    fixed.append(cell);
    main.append(fixed);
  }

  const footer = fillTokens(values.footer, sample);
  const bits = [];
  if (footer) bits.push(footer);
  if (values.timestamp) bits.push(new Date().toLocaleString());
  if (bits.length) main.append(el('p', 'ft', bits.join(' • ')));

  const row = el('div', 'demb-row');
  row.append(main);
  if (values.thumbnail) row.append(el('span', 'demb-thumb'));
  box.append(row);

  // The buttons under the card, in the colours they will actually be. This is
  // the point of editing them here rather than guessing — "Danger" and "red"
  // are the same thing and only one of them is visible.
  if (values.buttons?.length) {
    const btns = el('div', 'demb-btns');
    for (const b of values.buttons) {
      const chip = el('span', b.style || 'Secondary',
        `${b.emoji ? `${b.emoji} ` : ''}${b.label || ''}`.trim() || b.id);
      btns.append(chip);
    }
    // Outside the card: Discord draws a message's buttons under the embed,
    // not inside it, and putting them in the box would teach the wrong thing.
    const shell = el('div');
    shell.append(box, btns);
    return shell;
  }
  return box;
}

/** A colour picker and its hex box, kept in step with each other. */
function colorField(label, value, onChange) {
  const l = el('label', 'field');
  l.append(el('span', null, label));
  const row = el('div', 'color-row');

  const swatch = el('input');
  swatch.type = 'color';
  swatch.value = /^#[0-9a-f]{6}$/i.test(value || '') ? value : '#5865F2';

  const hex = el('input');
  hex.type = 'text';
  hex.value = swatch.value.toUpperCase();
  hex.spellcheck = false;
  hex.setAttribute('aria-label', `${label} hex code`);

  swatch.addEventListener('input', () => {
    hex.value = swatch.value.toUpperCase();
    hex.classList.remove('bad');
    onChange(hex.value);
  });
  hex.addEventListener('input', () => {
    const v = hex.value.trim();
    const full = v.startsWith('#') ? v : `#${v}`;
    // Typing a hex goes character by character, so half of what is typed is
    // never going to be valid. Marking it rather than rejecting it lets the
    // field finish being typed into.
    if (!/^#[0-9a-f]{6}$/i.test(full)) { hex.classList.add('bad'); return; }
    hex.classList.remove('bad');
    swatch.value = full;
    onChange(full.toUpperCase());
  });

  row.append(swatch, hex);
  l.append(row);
  return l;
}

/**
 * The {token} chips.
 *
 * Clicking one drops it into whichever box you were last typing in, at the
 * cursor. Typing them by hand works too — this is so you do not have to
 * remember which message understands which.
 */
function tokenChips(tokens, focusRef) {
  const wrap = el('div', 'field');
  const head = el('div', 'field-head');
  head.append(el('span', null, 'Placeholders'), el('span', 'count', 'click to insert'));
  wrap.append(head);

  const box = el('div', 'chipset');
  for (const t of tokens) {
    const b = el('button', 'chip-toggle mono', t);
    b.type = 'button';
    b.addEventListener('click', () => {
      const input = focusRef.el;
      if (!input) return;
      const start = input.selectionStart ?? input.value.length;
      const end = input.selectionEnd ?? start;
      input.value = input.value.slice(0, start) + t + input.value.slice(end);
      input.setSelectionRange(start + t.length, start + t.length);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.focus();
    });
    box.append(b);
  }
  wrap.append(box);
  return wrap;
}

/** Remembers the last box you typed in, so a chip knows where to go. */
function trackFocus(node, focusRef) {
  for (const input of node.querySelectorAll('input[type="text"], textarea')) {
    input.addEventListener('focus', () => { focusRef.el = input; });
  }
  return node;
}

// Which rows the bot appends itself, per message. Named here rather than sent
// from the server because they are a fact about the preview, not about the
// stored style.
const FIXED_FIELDS = {
  'log.action': ['User', 'Moderator', 'Reason'],
  'dm.action': ['📋 Reason'],
  'member.leave': ['👥 Members Left', '⏳ Time in Server'],
  'ticket.opened': ['Support Team'],
};

const PART_LABEL = {
  enabled: 'Send this message',
  thumbnail: 'Show a picture in the corner',
  timestamp: 'Show the time',
};

function appearanceEntries() {
  return (state.overview?.appearance?.groups || []).flatMap(g => g.entries);
}

function renderAppearanceIndex() {
  const wrap = $('#appearance-index');
  const groups = state.overview?.appearance?.groups || [];
  if (!groups.length) { wrap.replaceChildren(el('p', 'muted', 'Nothing to style yet.')); return; }

  if (!state.appearanceCat) state.appearanceCat = groups[0]?.name || '';
  if (!groups.some(g => g.name === state.appearanceCat)) {
    state.appearanceCat = groups[0]?.name || '';
  }

  const titleCase = (s) => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
  const nodes = [];
  const tabs = el('div', 'appear-seg');
  for (const g of groups) {
    const t = el('button', 'appear-seg-btn' + (g.name === state.appearanceCat ? ' on' : ''), titleCase(g.name));
    t.type = 'button';
    t.addEventListener('click', () => {
      state.appearanceCat = g.name;
      renderAppearanceIndex();
    });
    tabs.append(t);
  }
  nodes.push(tabs);

  const active = groups.find(g => g.name === state.appearanceCat) || groups[0];
  const list = el('div', 'appear-list');
  for (const e of (active?.entries || [])) {
    const b = el('button', 'tpl-entry');
    b.type = 'button';
    b.append(el('span', 'nm', e.label));
    const meta = el('span', 'mt');
    meta.textContent = `${e.values.enabled === false ? '⃠' : ''}${e.changed ? '●' : ''}`;
    meta.title = [e.changed ? 'changed from the shipped wording' : null,
      e.values.enabled === false ? 'not being sent' : null].filter(Boolean).join(' · ');
    b.append(meta);
    if (e.key === state.styleKey) b.setAttribute('aria-current', 'true');
    b.addEventListener('click', () => { state.styleKey = e.key; renderAppearance(); });
    list.append(b);
  }
  nodes.push(list);
  wrap.replaceChildren(...nodes);
}

function renderAppearance() {
  const data = state.overview?.appearance;
  const body = $('#appearance-body');
  if (!body) return;
  if (!data) { body.replaceChildren(); return; }

  const entries = appearanceEntries();
  if (!entries.length) { body.replaceChildren(el('p', 'muted', 'Nothing to style yet.')); return; }
  if (!entries.some(e => e.key === state.styleKey)) state.styleKey = entries[0].key;

  const count = $('#appearance-count');
  if (count) {
    count.textContent = data.changedCount ? `${data.changedCount} changed` : 'all default';
    count.classList.toggle('on', data.changedCount > 0);
  }
  renderAppearanceIndex();

  const entry = entries.find(e => e.key === state.styleKey);
  const values = { ...entry.values };
  const sample = { ...(data.sample || {}), server: state.overview?.guild?.name || 'your server' };
  const focusRef = { el: null };

  const card = el('article', 'panel');
  const head = el('div', 'queue-head');
  head.append(el('h2', null, entry.label), el('span', 'tag', entry.key));
  card.append(head, el('p', 'muted', entry.blurb));
  if (entry.wordingNote) card.append(el('p', 'hint', entry.wordingNote));

  const preview = el('div', 'style-preview');
  const previewEntry = { ...entry, fixedFields: FIXED_FIELDS[entry.key] || [] };
  const repaint = () => {
    preview.replaceChildren(
      values.enabled === false
        ? el('p', 'muted', 'Switched off — this message is not sent at all.')
        : stylePreview(previewEntry, values, sample),
    );
  };

  const fields = el('div');
  for (const part of entry.parts) {
    if (part === 'enabled') {
      fields.append(toggle(PART_LABEL.enabled, values.enabled !== false, v => { values.enabled = v; repaint(); }));
    } else if (part === 'format') {
      fields.append(select('Delivery', values.format === 'plain' ? 'plain' : 'embed', [
        { value: 'embed', label: 'Embed card' },
        { value: 'plain', label: 'Plain message' },
      ], v => { values.format = v; repaint(); }));
      fields.append(el('p', 'hint', 'Embed card = coloured Discord embed. Plain message = normal text in chat (good for lock/unlock).'));
    } else if (part === 'color') {
      fields.append(colorField('Colour', values.color, v => { values.color = v; repaint(); }));
    } else if (part === 'title') {
      fields.append(textField(entry.shape === 'action' ? 'The line' : 'Title',
        values.title, v => { values.title = v; repaint(); }));
    } else if (part === 'body') {
      fields.append(areaField(entry.bodyLabel || 'Body', values.body, v => { values.body = v; repaint(); }, 3));
      if (entry.bodyHint) fields.append(el('p', 'hint', entry.bodyHint));
    } else if (part === 'footer') {
      fields.append(textField('Footer', values.footer, v => { values.footer = v; repaint(); }));
    } else if (part === 'thumbnail' || part === 'timestamp') {
      fields.append(toggle(PART_LABEL[part], !!values[part], v => { values[part] = v; repaint(); }));
    } else if (part === 'buttons') {
      fields.append(buttonEditors(entry, values, repaint));
    } else if (part === 'palette') {
      fields.append(paletteEditors(entry, values, repaint));
    }
  }
  card.append(trackFocus(fields, focusRef));
  card.append(tokenChips(entry.tokens, focusRef));

  const save = el('button', 'btn primary small', 'Save');
  save.type = 'button';
  save.addEventListener('click', async () => {
    save.disabled = true;
    save.textContent = 'Saving…';
    try {
      const payload = { key: entry.key };
      for (const part of entry.parts) payload[part] = values[part];
      // Sent as a map keyed by id — the server matches those against the ids
      // the message actually declares, so a stale tab cannot invent one.
      if (entry.parts.includes('palette')) payload.palette = values.palette;
      if (entry.parts.includes('buttons')) {
        payload.buttons = Object.fromEntries((values.buttons || []).map(b =>
          [b.id, { label: b.label, emoji: b.emoji, style: b.style }]));
      }
      const res = await post('appearance', payload);
      /* post() may call renderOverview; editor is sticky via section guard */
      if (res?.ok) {
        state.overview = await get(`/api/guild/${state.guildId}`);
        renderOverview();
      }
    } finally {
      save.disabled = false;
      save.textContent = 'Save';
    }
  });

  const revert = el('button', 'btn small', 'Undo my edits');
  revert.type = 'button';
  revert.addEventListener('click', () => renderAppearance());

  const reset = el('button', 'btn small danger', 'Back to default');
  reset.type = 'button';
  reset.disabled = !entry.changed;
  reset.addEventListener('click', async () => {
    if (!await askConfirm({
      title: `Put "${entry.label}" back?`,
      message: 'Your wording and colour for this one message are dropped and the shipped version comes back. Nothing else is touched.',
      confirmLabel: 'Put it back',
    })) return;
    const res = await post('appearancereset', { key: entry.key });
    if (res?.ok) {
      state.overview = await get(`/api/guild/${state.guildId}`);
      renderOverview();
    }
  });

  const foot = el('div', 'actions');
  foot.append(save, revert, reset);
  card.append(foot);

  const shown = el('article', 'panel');
  shown.append(el('h2', null, 'How it will look'), preview,
    el('p', 'hint', 'A likeness, not a screenshot. The names and numbers are stand-ins — the real ones go in when it is sent.'));

  repaint();
  body.replaceChildren(card, shown);
}

/* ── start a giveaway ──────────────────────────────────────────────────── */

let gawPreviewTimer = null;

// Bounded on purpose. An unbounded retry would keep the page requesting
// forever whenever the render pacer stayed busy, and a preview is cosmetic —
// it is not worth a permanent poll.
const PREVIEW_RETRIES = 4;

function refreshGawPreview(draft, attempt = 0) {
  clearTimeout(gawPreviewTimer);
  gawPreviewTimer = setTimeout(async () => {
    try {
      const res = await fetch(`/api/preview/giveaway?amount=${draft.amount}&winners=${draft.winners}`,
        { credentials: 'same-origin', headers: authHeaders() });
      if (res.status === 429) {
        if (attempt < PREVIEW_RETRIES) gawPreviewTimer = setTimeout(() => refreshGawPreview(draft, attempt + 1), 320);
        return;
      }
      if (!res.ok) return;
      const img = $('#gaw-preview');
      const previous = img.src;
      img.src = URL.createObjectURL(await res.blob());
      if (previous.startsWith('blob:')) URL.revokeObjectURL(previous);
    } catch { /* preview is cosmetic; a failure must not block launching */ }
  }, 320);
}

function renderGiveawayForm(opts = {}) {
  const form = $('#form-gaw');
  if (!form) return;
  // Once the launch form is built, keep it. Live overview / tab focus must
  // not rebuild and wipe prize, duration, winners, etc.
  // Pass { force: true } after a successful launch or when entering the tab.
  if (form.dataset.ready === '1' && !opts.force) return;
  if (isEditingPanel() && form.dataset.ready === '1') return;

  const draft = {
    kind: 'prize',
    hostId: null,
    prize: '',
    winners: 1,
    duration: '1h',
    channelId: '',
    mention: null,
    requiredRoleId: null,
    bonusRoleId: null,
    minAccountAgeDays: 0,
    imageUrl: 'dynamic:prizeGiveawayBanner',
  };

  // Duration chips
  const durBox = el('div', 'field');
  durBox.append(el('label', null, 'How long it runs'));
  const durChips = el('div', 'chipset drop-chips');
  const paintDur = () => {
    durChips.replaceChildren();
    for (const val of ['30m', '1h', '6h', '24h', '7d']) {
      const b = el('button', 'chip-toggle' + (draft.duration === val ? ' on' : ''), val);
      b.type = 'button';
      b.addEventListener('click', () => {
        draft.duration = val;
        const inp = durBox.querySelector('input');
        if (inp) { inp.value = val; inp.dispatchEvent(new Event('input', { bubbles: true })); }
        paintDur();
      });
      durChips.append(b);
    }
  };
  paintDur();
  durBox.append(durChips);
  durBox.append(durationField('Custom duration', draft.duration, v => {
    draft.duration = v;
    paintDur();
  }, { hideChips: true }));

  // Winners chips — only exact match lights a chip (100 must not highlight 10)
  const winBox = el('div', 'field');
  winBox.append(el('label', null, 'Winners'));
  const winChips = el('div', 'chipset drop-chips');
  const WIN_MAX = 100;
  const paintWin = () => {
    winChips.replaceChildren();
    const current = Number(draft.winners);
    for (const n of [1, 2, 3, 5, 10]) {
      const on = Number.isInteger(current) && current === n;
      const b = el('button', 'chip-toggle' + (on ? ' on' : ''), String(n));
      b.type = 'button';
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
      b.addEventListener('click', () => {
        draft.winners = n;
        const inp = winBox.querySelector('input');
        if (inp) inp.value = String(n);
        paintWin();
      });
      winChips.append(b);
    }
  };
  paintWin();
  winBox.append(winChips);
  winBox.append(textField('Or type a number', String(draft.winners || 1), v => {
    const n = parseInt(String(v).trim(), 10);
    if (Number.isInteger(n) && n >= 1 && n <= WIN_MAX) {
      draft.winners = n;
      paintWin();
    } else if (String(v).trim() === '') {
      // empty while typing — no chip selected
      draft.winners = 1;
      paintWin();
    } else {
      // invalid / out of range — keep typed digits in the box but clear chips
      paintWin();
    }
  }));

  form.replaceChildren(
    textField('Prize name', '', v => { draft.prize = v; }, {
      placeholder: 'e.g. Weekend Coin Rain · VIP role · $50 credit',
    }),
    imageSourceField(
      'Banner',
      'dynamic:prizeGiveawayBanner',
      v => { draft.imageUrl = v || 'dynamic:prizeGiveawayBanner'; },
      { giveaway: true, defaultValue: 'dynamic:prizeGiveawayBanner' },
    ),
    winBox,
    durBox,
    (() => {
      const admins = state.overview?.features?.admins || [];
      if (!draft.hostId && admins.length) draft.hostId = admins[0].id;
      return select(
        'Host (admin)',
        draft.hostId || '',
        admins.map(a => ({ value: a.id, label: a.name })),
        v => { draft.hostId = v || null; },
        { blank: admins.length ? 'Pick an admin' : 'No admins loaded — refresh the panel' },
      );
    })(),
    pickOne('Channel', 'channel', '', v => { draft.channelId = v; }, { blank: 'Where it posts' }),
    mentionPicker('Optional ping', null, v => { draft.mention = v; }),
    pickOne('Required role', 'role', '', v => { draft.requiredRoleId = v; }, { blank: 'Anyone can enter' }),
    (() => {
      const box = el('div', 'field');
      box.append(el('label', null, 'Bonus entry roles'));
      draft.bonusRoles = draft.bonusRoles || []; // [{ id, extra }]
      const log = el('div', 'bonus-role-log');
      const paint = () => {
        log.replaceChildren();
        if (!draft.bonusRoles.length) {
          log.append(el('p', 'muted', 'No bonus roles — everyone has 1 entry.'));
          draft.bonusRoleId = null;
          draft.bonusRoleIds = [];
          return;
        }
        draft.bonusRoleIds = draft.bonusRoles.map(r => r.id);
        draft.bonusRoleId = draft.bonusRoles[0]?.id || null;
        for (const entry of draft.bonusRoles) {
          const role = (state.overview?.settings?.roles || []).find(r => r.id === entry.id);
          const row = el('div', 'bonus-role-row');
          row.append(el('span', 'nm', role?.name || entry.id));
          const extraWrap = el('label', 'bonus-extra');
          extraWrap.append(document.createTextNode('+'));
          const numIn = el('input');
          numIn.type = 'number';
          numIn.min = '1';
          numIn.max = '10';
          numIn.value = String(entry.extra || 1);
          numIn.title = 'Extra entries (on top of the base 1)';
          numIn.addEventListener('input', () => {
            let v = Number(numIn.value);
            if (!Number.isInteger(v) || v < 1) v = 1;
            if (v > 10) v = 10;
            entry.extra = v;
            numIn.value = String(v);
          });
          extraWrap.append(numIn);
          extraWrap.append(document.createTextNode(' extra'));
          row.append(extraWrap);
          const rm = el('button', 'btn small danger', 'Remove');
          rm.type = 'button';
          rm.addEventListener('click', () => {
            draft.bonusRoles = draft.bonusRoles.filter(r => r.id !== entry.id);
            paint();
          });
          row.append(rm);
          log.append(row);
        }
      };
      paint();
      const addRow = el('div', 'bonus-add-row');
      const pick = pickOne('', 'role', '', v => {}, { blank: 'Pick a role' });
      pick.classList.add('bonus-pick');
      const add = el('button', 'btn small', 'Add');
      add.type = 'button';
      add.className = 'btn small bonus-add-btn';
      add.addEventListener('click', () => {
        const sel = pick.querySelector('select');
        const id = sel?.value;
        if (!id) { toast('Pick a role first.', 'bad'); return; }
        if (draft.bonusRoles.some(r => r.id === id)) { toast('Already added.', 'bad'); return; }
        draft.bonusRoles.push({ id, extra: 1 });
        paint();
      });
      addRow.append(pick, add);
      box.append(log, addRow);
      return box;
    })(),
    textField('Min account age (days)', '0', v => { draft.minAccountAgeDays = Number(v) || 0; }),
    actions(async () => {
      if (!String(draft.prize || '').trim()) { toast('Name the prize for this giveaway.', 'bad'); return; }
      if (!draft.channelId) { toast('Pick a channel first.', 'bad'); return; }
      if (!draft.hostId) { toast('Pick a host (admin) for this giveaway.', 'bad'); return; }
      if (!parseDurationMs(draft.duration)) {
        toast('Duration must look like 30m, 1h, 6h or 2d.', 'bad');
        return;
      }
      if (!await askConfirm({
        title: 'Launch this giveaway?',
        message: `**${draft.prize}** · ${draft.winners} winner${draft.winners === 1 ? '' : 's'} · ${humanDuration(draft.duration)}. Posts to the channel with **Enter**.`,
        confirmLabel: 'Launch giveaway',
      })) return;
      await post('giveawaystart', draft);
    }, { label: 'Launch giveaway', busyLabel: 'Launching…' }),
  );

  state.gawBump = () => {};
  form.dataset.ready = '1';

}

/* ── lottery ───────────────────────────────────────────────────────────── */

function renderLottery() {
  const wrap = $('#lottery-live');
  if (!wrap) return; /* lottery panel removed with economy */
  const l = state.overview?.features?.lottery;
  if (!l) { wrap.replaceChildren(); return; }

  const nodes = [
    row('Tickets in the pot', num(l.totalTickets)),
    row('Players today', num(l.participants)),
    row('Prize', `${num(l.reward)} coins`),
  ];

  if (l.open && l.nextDrawAt) {
    // The draw is daily, so the bar runs from the previous one. Without that
    // it filled from whenever the page happened to be opened.
    const c = countdownEl(l.nextDrawAt, l.lastDrawAt || l.nextDrawAt - 86400000);
    const line = el('div', 'row');
    line.append(el('span', 'k', 'Next draw'), c.node);
    nodes.push(line, c.bar);
  } else if (!l.open) {
    // No countdown when there is nothing to count down to, and a plain
    // statement of what that means for the coins already in the pot. A
    // paused lottery holding tickets is real money frozen, and the person
    // who paused it is the only one who can unfreeze it.
    const why = l.closedReason === 'economy_off'
      ? 'The economy is switched off for this server, so the lottery is closed too. Turn it back on in Settings to reopen it.'
      : l.closedReason === 'paused'
        ? 'Paused — no draw will run, and tickets are not on sale.'
        : 'No results channel set, so no draw can run. Tickets are not on sale.';
    const note = el('p', 'hint bad', l.totalTickets
      ? `${why} ${num(l.totalTickets)} ticket${l.totalTickets === 1 ? '' : 's'} are held in the pot and stay there until it runs again.`
      : why);
    nodes.push(note);
  }

  if (l.top.length) {
    nodes.push(el('h2', null, 'Most tickets'));
    const board = el('ol', 'board');
    board.append(...l.top.map((t, i) => {
      const li = el('li');
      li.append(
        el('span', 'rank', `${i + 1}`),
        el('span', 'name', t.name || 'left the server'),
        el('span', 'bal', `${num(t.tickets)}`),
      );
      return li;
    }));
    nodes.push(board);
  } else {
    nodes.push(el('p', 'muted', 'Nobody has bought a ticket today.'));
  }

  const act = el('div', 'actions');
  const clear = el('button', 'btn small danger', 'Void today\'s pool');
  clear.type = 'button';
  clear.title = 'Clears entries without paying anyone. Drawing stays on its schedule.';
  clear.addEventListener('click', async () => {
    if (!await askConfirm({
      title: "Clear today's lottery?",
      message: 'Every entry is discarded. Nobody is paid out and no tickets are refunded.',
      confirmLabel: 'Clear the pool', danger: true,
    })) return;
    await post('lotteryclear', {});
  });
  act.append(clear);
  nodes.push(act);

  wrap.replaceChildren(...nodes);
}

/* ── economy ───────────────────────────────────────────────────────────────
   Eight activity cards, a jobs board and the two dials above them. The cards
   are built from the field descriptions the server sends rather than written
   out here, so adding a setting to utils/economySettings.js puts it on screen
   without touching this file. */

const HOUR_LABEL = h => `${String(h).padStart(2, '0')}:00`;

function econField(f, value, onChange) {
  if (f.type === 'bool') return toggle(f.label, !!value, onChange);
  if (f.type === 'duration') return durationField(f.label, value ?? '', onChange);
  const range = f.min != null ? ` (${f.min}–${num(f.max)})` : '';
  return textField(`${f.label}${range}`, value == null ? '' : String(value), v => onChange(Number(v)));
}

function renderEconomy() {
  const e = state.overview?.economy;
  if (!e) return;

  /* -- the server-wide dials --------------------------------------------- */
  const g = { multiplier: e.global.multiplier, boost: { ...e.global.boost } };
  const boostPill = $('#boost-state');
  if (boostPill) {
    boostPill.hidden = !e.global.active;
    boostPill.textContent = 'Boost hour running';
    boostPill.className = 'pill on';
  }

  const gNote = el('p', 'hint', '');
  const syncG = () => {
    const wraps = g.boost.startHour > g.boost.endHour;
    const empty = g.boost.startHour === g.boost.endHour;
    if (g.boost.enabled && empty) {
      gNote.textContent = 'Start and end are the same hour, so the window never opens. Pick two different hours.';
      gNote.className = 'hint bad';
      return;
    }
    const window = `${HOUR_LABEL(g.boost.startHour)}–${HOUR_LABEL(g.boost.endHour)}${wraps ? ' (over midnight)' : ''}`;
    gNote.textContent = g.boost.enabled
      ? `Everything pays ${g.multiplier}× normally, and ${Math.round(g.multiplier * g.boost.multiplier * 100) / 100}× between ${window}.`
      : `Everything pays ${g.multiplier}× — 1 is the shipped economy.`;
    gNote.className = 'hint';
  };

  const hourOptions = Array.from({ length: 24 }, (_, h) => ({ value: String(h), label: HOUR_LABEL(h) }));

  $('#form-econ-global').replaceChildren(
    textField('Payout multiplier (0.1–10)', String(g.multiplier), v => { g.multiplier = Number(v); syncG(); }),
    toggle('Run a boost hour', g.boost.enabled, v => { g.boost.enabled = v; syncG(); }),
    textField('Boost multiplier (1–10)', String(g.boost.multiplier), v => { g.boost.multiplier = Number(v); syncG(); }),
    select('Starts at', String(g.boost.startHour), hourOptions, v => { g.boost.startHour = Number(v); syncG(); }),
    select('Ends at', String(g.boost.endHour), hourOptions, v => { g.boost.endHour = Number(v); syncG(); }),
    gNote,
    actions(() => post('economyglobal', {
      multiplier: g.multiplier,
      // The hours mean the hours here, on this device — which is what someone
      // typing "6pm" means. The offset travels with them so the bot can work
      // out which UTC hour that actually is.
      boost: { ...g.boost, offsetMinutes: -new Date().getTimezoneOffset() },
    })),
  );
  syncG();

  /* -- one card per activity --------------------------------------------- */
  const wrap = $('#econ-activities');
  wrap.replaceChildren(...e.activities.map(a => {
    const draft = { activity: a.key };
    const card = el('article', 'panel econ-card');
    if (!a.enabled) card.classList.add('off');

    const head = el('div', 'queue-head');
    head.append(el('h2', null, `${a.emoji} ${a.label}`), el('span', 'tag', a.command));
    card.append(head, el('p', 'muted', a.blurb));

    const note = el('p', 'hint', '');
    const values = { ...a.values };
    const syncNote = () => {
      // Only the pairs can be wrong on their own; everything else is bounded
      // by the input itself.
      const bad = ('min' in values && Number(values.min) > Number(values.max))
        || ('rewardMin' in values && Number(values.rewardMin) > Number(values.rewardMax));
      note.textContent = bad
        ? 'The lowest payout is above the highest — nothing could be rolled between them.'
        : values.enabled === false ? 'Members are told this command is closed.' : '';
      note.className = `hint${bad ? ' bad' : ''}`;
    };

    for (const f of a.fields) {
      card.append(econField(f, values[f.key], v => {
        values[f.key] = v;
        draft[f.key] = v;
        if (f.key === 'enabled') card.classList.toggle('off', v === false);
        syncNote();
      }));
    }
    card.append(note, actions(() => post('economy', { ...draft, activity: a.key })));
    syncNote();
    return card;
  }));

  /* -- the jobs board ---------------------------------------------------- */
  const jobs = Object.fromEntries(e.jobs.map(j => [j.id, j.open]));
  const jobNote = el('p', 'hint', '');
  const syncJobs = () => {
    const open = Object.values(jobs).filter(Boolean).length;
    jobNote.textContent = open === 0
      ? 'At least one job has to stay open — use the switch on the Jobs card to close the command instead.'
      : `${open} of ${e.jobs.length} hiring.`;
    jobNote.className = `hint${open === 0 ? ' bad' : ''}`;
  };

  $('#form-econ-jobs').replaceChildren(
    ...e.jobs.map(j => {
      const t = toggle(`${j.label} · ${j.pay} · ${j.shift}`, j.open, v => { jobs[j.id] = v; syncJobs(); });
      return t;
    }),
    jobNote,
    actions(() => post('economyjobs', { jobs })),
  );
  syncJobs();
}

/* ── trading cards ─────────────────────────────────────────────────────── */

const RARITY_TINT = {
  common: '#9E9E9E', uncommon: '#43A047', rare: '#1E88E5',
  epic: '#8E24AA', legendary: '#FFD700', mythic: '#FF1744',
};

function renderCards() {
  const c = state.overview?.cards;
  if (!c) return;

  /* -- how often they drop ---------------------------------------------- */
  const drops = { ...c.values };
  $('#cards-count').textContent = `${c.totals.enabled}/${c.totals.catalogue} dropping`;
  $('#cards-count').hidden = false;

  $('#form-cards').replaceChildren(
    ...c.fields.flatMap(f => [
      textField(`${f.label} (${f.min}–${f.max})`, drops[f.key], v => { drops[f.key] = Number(v); }),
      el('p', 'hint', f.hint),
    ]),
    pickOne('Drop channel', 'channel', drops.channelId, v => { drops.channelId = v; }, { blank: 'Anywhere members talk' }),
    el('p', 'hint', 'Left blank, a card can drop in any channel that reaches the count.'),
    actions(() => post('carddrops', drops)),
  );

  /* -- the odds and the payouts ------------------------------------------ */
  const rarity = Object.fromEntries(c.rarities.map(r => [r.key, { weight: r.weight, price: r.price }]));
  const oddsNote = el('p', 'hint', '');
  const syncOdds = () => {
    const total = Object.values(rarity).reduce((s, r) => s + (Number(r.weight) || 0), 0);
    oddsNote.textContent = total > 0
      ? c.rarities.map(r => `${r.label} ${Math.round(((Number(rarity[r.key].weight) || 0) / total) * 1000) / 10}%`).join('  ·  ')
      : 'Every tier is at zero, so nothing could drop — give at least one a weight.';
    oddsNote.className = `hint${total > 0 ? '' : ' bad'}`;
  };

  $('#form-card-rarity').replaceChildren(
    ...c.rarities.map(r => {
      const row = el('div', 'subfield');
      const head = el('span', 'k', `${r.emoji} ${r.label} · ${r.cards} card${r.cards === 1 ? '' : 's'}`);
      head.style.borderLeft = `3px solid ${RARITY_TINT[r.key] || 'var(--rule)'}`;
      head.style.paddingLeft = '0.5rem';
      row.append(
        head,
        textField('Weight', r.weight, v => { rarity[r.key].weight = Number(v); syncOdds(); }),
        textField('Sells for (coins)', r.price, v => { rarity[r.key].price = Number(v); }),
      );
      return row;
    }),
    oddsNote,
    actions(() => post('cardrarity', { rarity })),
  );
  syncOdds();

  /* -- the catalogue ------------------------------------------------------ */
  $('#cards-collected').textContent = `${c.totals.collected.toLocaleString()} held by ${c.totals.collectors}`;
  $('#cards-collected').hidden = false;

  const picked = Object.fromEntries(c.cards.map(x => [x.id, x.enabled]));
  const listNote = el('p', 'hint', '');
  const syncList = () => {
    const on = Object.values(picked).filter(Boolean).length;
    listNote.textContent = on === 0
      ? 'At least one card has to stay on, or there would be nothing to drop.'
      : `${on} of ${c.cards.length} dropping.`;
    listNote.className = `hint${on === 0 ? ' bad' : ''}`;
  };

  // Grouped by tier, in the order they get rarer — a flat list of sixty-odd
  // switches is a wall, and the tier is the thing you are usually filtering by.
  const list = $('#card-list');
  list.replaceChildren(...c.rarities.map(r => {
    const group = el('details', 'item');
    const sum = el('summary');
    const badge = el('span', 'bstyle secondary', r.label);
    badge.style.borderLeft = `3px solid ${RARITY_TINT[r.key] || 'var(--rule)'}`;
    const mine = c.cards.filter(x => x.rarity === r.key);
    sum.append(
      badge,
      el('span', 'nm', `${mine.length} cards`),
      el('span', 'pr', `${mine.reduce((s, x) => s + x.held, 0).toLocaleString()} held`),
    );
    const body = el('div', 'body');
    body.append(...mine.map(x => toggle(
      `${x.emoji} ${x.name} — ${x.desc}${x.held ? `  ·  ${x.held} held` : ''}`,
      x.enabled,
      v => { picked[x.id] = v; syncList(); },
    )));
    group.append(sum, body);
    return group;
  }));

  $('#form-card-list').replaceChildren(listNote, actions(() => post('cardlist', { cards: picked })));
  syncList();
}

/* ── verification ──────────────────────────────────────────────────────── */

function renderVerifyPanel() {
  const draft = { channelId: state.overview?.features?.groups?.verify?.values?.channelId || null };
  const form = $('#form-verifypanel');
  if (!form) return;

  form.replaceChildren(
    pickOne('Channel', 'channel', draft.channelId, v => { draft.channelId = v; }),
    actions(async () => {
      if (!draft.channelId) { toast('Pick a channel first.', 'bad'); return; }
      if (!await askConfirm({
        title: 'Post the verification panel?',
        message: 'Members in that channel will see it straight away. Posting again makes a second panel — it does not move the first.',
        confirmLabel: 'Post it',
      })) return;
      await post('verifypanel', draft);
    }, { label: 'Post it', busyLabel: 'Posting…' }),
  );
}

/* ── settings ──────────────────────────────────────────────────────────── */

function renderSettings() {
  const s = state.overview?.settings;
  if (!s) return;
  const form = $('#form-settings');
  if (!form) return;
  // Keep chips selectable — live overview refresh must not wipe in-progress picks
  if (form.dataset.dirty === '1' && root.dataset.section === 'settings') return;

  const draft = {};
  for (const f of s.fields) draft[f.key] = s.values[f.key];

  const markDirty = () => { form.dataset.dirty = '1'; };
  const nodes = [];
  const roleItems = s.roles || roleList();

  for (const f of s.fields) {
    const value = draft[f.key];
    if (f.type === 'bool') {
      nodes.push(toggle(f.label, !!value, v => { draft[f.key] = v; markDirty(); }));
    } else if (f.type === 'channel') {
      nodes.push(select(f.label, value || '', s.channels.map(c => ({ value: c.id, label: `#${c.name}` })),
        v => { draft[f.key] = v || null; markDirty(); }, { blank: 'Not set' }));
    } else if (f.type === 'role') {
      nodes.push(select(f.label, value || '', roleItems.map(r => ({ value: r.id, label: r.name })),
        v => { draft[f.key] = v || null; markDirty(); }, { blank: 'Not set' }));
    } else if (f.type === 'roles') {
      nodes.push(pickManyRoles(f.label, roleItems, value || [], v => { draft[f.key] = v; markDirty(); }));
    } else if (f.type === 'choice') {
      nodes.push(select(f.label, value || f.choices[0], f.choices.map(c => ({ value: c, label: c })),
        v => { draft[f.key] = v; markDirty(); }));
    } else if (f.type === 'string') {
      nodes.push(textField(f.label, value == null ? '' : String(value),
        v => { draft[f.key] = v; markDirty(); }, { placeholder: 'e.g. Quantlab' }));
    } else {
      const scale = f.scale || 0;
      const shown = value == null || value === ''
        ? ''
        : String(scale ? Math.round(Number(value) / scale) : value);
      nodes.push(textField(
        `${f.label}${f.min != null ? ` (${f.min}–${f.max})` : ''}`,
        shown,
        v => {
          const t = String(v).trim();
          draft[f.key] = t === '' ? null : Number(t);
          markDirty();
        },
      ));
    }
  }

  nodes.push(actions(async () => {
    // Build a clean payload: omit blank ints so channel/role saves are not
    // rejected by empty "Warnings before action" / "Mute length" boxes.
    const payload = {};
    for (const f of s.fields) {
      const v = draft[f.key];
      if (f.type === 'int') {
        if (v == null || v === '' || Number.isNaN(Number(v))) continue;
        const n = Number(v);
        if (!Number.isInteger(n)) {
          toast('That number is outside the range this setting allows.', 'bad');
          return null;
        }
        payload[f.key] = n;
      } else if (f.type === 'choice') {
        // UI may show choices[0] while draft is still null — never send null.
        payload[f.key] = (v == null || v === '') ? (f.choices && f.choices[0]) : v;
      } else {
        payload[f.key] = v;
      }
    }
    const out = await post('settings', payload);
    if (out) form.dataset.dirty = '0';
    return out;
  }));
  form.replaceChildren(...nodes);
  form.dataset.dirty = '0';
}

/** Multi role chips using an explicit list (settings.roles), not a stale roleList(). */
function pickManyRoles(label, items, values, onChange) {
  const list = items || [];
  const chosen = new Set(values || []);
  const wrap = el('div', 'field');
  wrap.append(el('span', null, label));
  const box = el('div', 'chipset');
  if (!list.length) box.append(el('span', 'muted', 'No roles found.'));
  for (const i of list) {
    const b = el('button', 'chip-toggle', i.name);
    b.type = 'button';
    if (chosen.has(i.id)) b.setAttribute('aria-pressed', 'true');
    b.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      if (chosen.has(i.id)) { chosen.delete(i.id); b.removeAttribute('aria-pressed'); }
      else { chosen.add(i.id); b.setAttribute('aria-pressed', 'true'); }
      onChange([...chosen]);
    });
    box.append(b);
  }
  wrap.append(box);
  return wrap;
}

/**
 * Every module of the bot, with one switch each. Off stops the slash
 * commands (they reply saying so) and anything the feature does without one
 * — XP on messages, the news feed's own scheduler, join cards.
 */

function featureOn(key) {
  const groups = state.overview?.featureToggles?.groups || [];
  const g = groups.find(x => x.key === key);
  // Missing group → treat as on (default). Explicit enabled:false → off.
  return !g || g.enabled !== false;
}

function syncFeatureNav() {
  const hide = (el, off) => {
    if (!el) return;
    el.hidden = !!off;
    el.style.display = off ? 'none' : '';
    el.setAttribute('aria-hidden', off ? 'true' : 'false');
  };
  const nav = (name) =>
    document.getElementById('nav-' + name) || document.querySelector('[data-goto="' + name + '"]');

  const econOff = !featureOn('economy');
  const casOff  = !featureOn('casino');
  const calOff  = !featureOn('econ_calendar');
  const whopOff = !featureOn('whop');
  const gawOff  = !featureOn('giveaways');
  const tixOff  = !featureOn('tickets');
  const lvlOff  = !featureOn('leveling');
  // Feeds holds calendar + Whop — keep the tab if either is on.
  const feedsOff = calOff && whopOff;

  hide(nav('economy'), econOff);
  hide(nav('casino'), casOff);
  hide(nav('feeds'), feedsOff);
  hide(nav('giveaways'), gawOff);
  hide(nav('tickets'), tixOff);
  hide(nav('engagement'), lvlOff);

  // Calendar panels only
  hide($('#form-econcal')?.closest('.panel'), calOff);
  hide($('#release-desk'), calOff);
  // Whop panel only
  hide($('#whop-panel'), whopOff);

  const sec = root?.dataset?.section;
  if ((sec === 'economy' && econOff) || (sec === 'casino' && casOff)
      || (sec === 'feeds' && feedsOff) || (sec === 'giveaways' && gawOff)
      || (sec === 'tickets' && tixOff) || (sec === 'engagement' && lvlOff)) {
    if (typeof showSection === 'function') showSection('overview');
  }
}

function renderFeatureToggles() {
  const ft = state.overview?.featureToggles;
  const box = $('#form-featuretoggles');
  if (!box) return;
  if (!ft) { box.replaceChildren(); return; }

  // Don't wipe in-progress edits when live overview refresh fires.
  if (box.dataset.dirty === '1' && root?.dataset?.section === 'settings') return;

  const draft = {};
  for (const g of ft.groups) draft[g.key] = g.enabled !== false;

  const rows = ft.groups.map(g => {
    const row = el('div', 'toggle-row');
    row.append(
      toggle(g.label, !!draft[g.key], v => {
        draft[g.key] = v;
        box.dataset.dirty = '1';
      }),
      el('p', 'hint', g.description),
    );
    return row;
  });

  box.replaceChildren(...rows, actions(async () => {
    const out = await post('featuretoggles', draft);
    if (!out) return null; // keep dirty so the user can retry

    // Live update: apply server groups (or optimistic draft) without full reload.
    if (out.featureToggles?.groups && state.overview) {
      state.overview.featureToggles = out.featureToggles;
    } else if (state.overview?.featureToggles?.groups) {
      for (const g of state.overview.featureToggles.groups) {
        if (g.key in draft) g.enabled = !!draft[g.key];
      }
    }
    box.dataset.dirty = '0';
    try { syncFeatureNav(); } catch {}
    // Soft refresh overview in background so other cards stay truthful.
    try {
      const fresh = await get(`/api/guild/${state.guildId}`);
      if (fresh?.guild?.id === state.guildId) {
        const keepDirty = box.dataset.dirty === '1';
        state.overview = fresh;
        if (!keepDirty) renderFeatureToggles();
        syncFeatureNav();
      }
    } catch {}
    return out;
  }, { label: 'Save changes', busyLabel: 'Saving…' }));

  box.dataset.dirty = '0';
}

/* ── bot profile ──────────────────────────────────────────────────────────
   Global identity + presence is operator-only.
   Per-server nickname is available when the operator allows it.
   Presence (status mode + activity) is saved so it survives restarts. */

const STATUS_OPTIONS = [
  { value: 'online',    label: 'Online',    hint: 'Green' },
  { value: 'idle',      label: 'Idle',      hint: 'Yellow' },
  { value: 'dnd',       label: 'Do Not Disturb', hint: 'Red' },
  { value: 'invisible', label: 'Invisible', hint: 'Appears offline' },
];

const ACTIVITY_OPTIONS = [
  { value: 'watching',  label: 'Watching' },
  { value: 'playing',   label: 'Playing' },
  { value: 'listening', label: 'Listening to' },
  { value: 'competing', label: 'Competing in' },
];

// Shipped defaults — what "Reset" puts back.
const DEFAULT_PRESENCE = {
  status: 'online',
  activityType: 'watching',
  activityText: 'QuantLab | /help',
};

function renderBotProfile() {
  const box = $('#bot-profile');
  if (!box) return;
  const bp = state.overview?.botProfile;
  if (!bp) { box.replaceChildren(el('p', 'muted', 'Profile unavailable.')); return; }

  const nodes = [];
  const g = bp.global || {};
  const guild = bp.guild || {};
  const presence = bp.presence || { ...DEFAULT_PRESENCE };

  // ── Live preview ──────────────────────────────────────────────────────
  const preview = el('div', 'gaw');
  const top = el('div', 'gaw-top');
  if (g.avatarUrl) {
    const img = el('img');
    img.src = g.avatarUrl;
    img.alt = '';
    img.style.cssText = 'width:48px;height:48px;border-radius:50%;object-fit:cover;flex:none';
    top.append(img);
  }
  const nameBlock = el('div', 'social-names');
  nameBlock.append(el('span', 'nm', guild.displayName || g.globalName || g.username || 'Bot'));
  const statusLine = [
    presence.activityText
      ? `${ACTIVITY_OPTIONS.find(a => a.value === presence.activityType)?.label || 'Watching'} ${presence.activityText}`
      : null,
    STATUS_OPTIONS.find(s => s.value === presence.status)?.label || presence.status,
  ].filter(Boolean).join(' · ');
  nameBlock.append(el('span', 'mt', statusLine || 'No status set'));
  top.append(nameBlock);
  preview.append(top);
  if (g.bio) preview.append(el('p', 'hint', g.bio));
  nodes.push(preview);

  // Who can do what — shown so a failed save is not a mystery.
  if (!bp.canEditPresence && !bp.canEditGlobal && !bp.canEditNickname) {
    nodes.push(el('p', 'hint bad', 'You cannot edit this bot profile. Only the bot operator can change status, name, avatar and bio. Server nickname is locked until the operator allows it.'));
  }

  // ── Status mode + activity (owner only) ───────────────────────────────
  if (bp.canEditPresence) {
    nodes.push(el('h2', null, 'Status'));
    nodes.push(el('p', 'hint', 'How the bot appears in the member list. Saved so it survives a restart.'));

    const presenceDraft = {
      status: presence.status || 'online',
      activityType: presence.activityType || 'watching',
      activityText: presence.activityText || '',
    };

    const statusWrap = el('div', 'field');
    statusWrap.append(el('span', null, 'Status mode'));
    const statusChips = el('div', 'chipset');
    for (const opt of STATUS_OPTIONS) {
      const b = el('button', 'chip-toggle', opt.label);
      b.type = 'button';
      b.title = opt.hint;
      if (opt.value === presenceDraft.status) b.setAttribute('aria-pressed', 'true');
      b.addEventListener('click', () => {
        presenceDraft.status = opt.value;
        for (const c of statusChips.querySelectorAll('.chip-toggle')) c.removeAttribute('aria-pressed');
        b.setAttribute('aria-pressed', 'true');
      });
      statusChips.append(b);
    }
    statusWrap.append(statusChips);
    nodes.push(statusWrap);

    nodes.push(select('Activity type', presenceDraft.activityType, ACTIVITY_OPTIONS,
      v => { presenceDraft.activityType = v; }));
    nodes.push(textField('Status text', presenceDraft.activityText, v => {
      presenceDraft.activityText = v.slice(0, 128);
    }, { placeholder: 'e.g. charts · /help · live signals' }));
    nodes.push(el('p', 'hint', 'Leave blank to clear the activity line. Max 128 characters.'));

    const statusActions = el('div', 'actions');
    const saveStatus = el('button', 'btn primary small', 'Save status');
    saveStatus.type = 'button';
    saveStatus.addEventListener('click', async () => {
      saveStatus.disabled = true;
      saveStatus.textContent = 'Saving…';
      try {
        const res = await post('bot-profile-presence', {
          status: presenceDraft.status,
          activityType: presenceDraft.activityType,
          activityText: presenceDraft.activityText,
        });
        if (res?.ok) {
          if (res.presence && state.overview?.botProfile) {
            state.overview.botProfile.presence = res.presence;
          }
          // Refresh from server so the preview matches Discord.
          try {
            state.overview = await get(`/api/guild/${state.guildId}`);
          } catch { /* keep local */ }
          renderBotProfile();
        }
      } finally {
        saveStatus.disabled = false;
        saveStatus.textContent = 'Save status';
      }
    });

    const resetStatus = el('button', 'btn small', 'Reset status');
    resetStatus.type = 'button';
    resetStatus.title = 'Back to Online · Watching QuantLab | /help';
    resetStatus.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'Reset bot status?',
        message: 'Puts status back to Online and the activity to “Watching QuantLab | /help”.',
        confirmLabel: 'Reset status',
      })) return;
      resetStatus.disabled = true;
      try {
        const res = await post('bot-profile-presence', { ...DEFAULT_PRESENCE });
        if (res?.ok) {
          try { state.overview = await get(`/api/guild/${state.guildId}`); } catch { /* keep */ }
          renderBotProfile();
        }
      } finally { resetStatus.disabled = false; }
    });

    statusActions.append(saveStatus, resetStatus);
    nodes.push(statusActions);
  }

  // ── Nickname (this server) ────────────────────────────────────────────
  nodes.push(el('h2', null, 'Nickname in this server'));
  const nickDraft = { nickname: guild.nickname || '' };
  if (bp.canEditNickname) {
    nodes.push(textField('Nickname', nickDraft.nickname, v => { nickDraft.nickname = v; }, {
      placeholder: 'Leave empty to use the global name',
    }));
    nodes.push(el('p', 'hint', 'Only affects this server. Max 32 characters.'));
    const nickActions = el('div', 'actions');
    const saveNick = el('button', 'btn primary small', 'Save nickname');
    saveNick.type = 'button';
    saveNick.addEventListener('click', async () => {
      saveNick.disabled = true;
      saveNick.textContent = 'Saving…';
      try {
        const res = await post('bot-profile-nick', { nickname: nickDraft.nickname });
        if (res?.ok) {
          try { state.overview = await get(`/api/guild/${state.guildId}`); } catch { /* keep */ }
          renderBotProfile();
        }
      } finally {
        saveNick.disabled = false;
        saveNick.textContent = 'Save nickname';
      }
    });
    const clearNick = el('button', 'btn small', 'Reset nickname');
    clearNick.type = 'button';
    clearNick.title = 'Remove the server nickname so the global name shows';
    clearNick.addEventListener('click', async () => {
      clearNick.disabled = true;
      try {
        const res = await post('bot-profile-nick', { nickname: '' });
        if (res?.ok) {
          try { state.overview = await get(`/api/guild/${state.guildId}`); } catch { /* keep */ }
          renderBotProfile();
        }
      } finally { clearNick.disabled = false; }
    });
    nickActions.append(saveNick, clearNick);
    nodes.push(nickActions);
  } else {
    nodes.push(el('p', 'hint',
      guild.nickname
        ? `Current nickname: “${guild.nickname}”. The bot operator has not allowed servers to change it.`
        : 'Server nickname is locked. The bot operator has not allowed servers to change it.'));
  }


  // ── Server display image (this server only) ───────────────────────────
  nodes.push(el('h2', null, 'Bot image in this server'));
  nodes.push(el('p', 'hint',
    'Used on giveaway cards and branded embeds here. This does not change the bot’s Discord avatar worldwide — only the operator can change that.'));
  if (bp.canEditServerImage || bp.canEditNickname) {
    const imgDraft = { url: guild.brandAvatar || '' };
    if (guild.brandAvatar) {
      const prev = el('img');
      prev.src = guild.brandAvatar;
      prev.alt = '';
      prev.style.cssText = 'width:64px;height:64px;border-radius:12px;object-fit:cover;display:block;margin:0.4rem 0';
      nodes.push(prev);
    }
    nodes.push(textField('Image URL (https)', imgDraft.url, v => { imgDraft.url = v.trim(); }, {
      placeholder: 'https://…',
    }));
    // High-quality upload (same path as before) — baked at 1024² then sent to Discord CDN
    const fileRow = el('div', 'field');
    fileRow.append(el('span', null, 'Or upload'));
    const fileInput = el('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/png,image/jpeg,image/webp,image/gif';
    fileInput.style.cssText = 'display:block;margin-top:0.35rem';
    const uploadHint = el('p', 'hint', 'PNG / JPG / WebP. Framed at high resolution so it stays sharp on the giveaway card.');
    const studioHost = el('div');
    studioHost.style.cssText = 'display:none;margin-top:0.75rem';
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files && fileInput.files[0];
      if (!file) return;
      try {
        const img = await loadImageFromFile(file);
        studioHost.style.display = '';
        openAvatarStudio(studioHost, img, file.name, (dataUrl) => {
          imgDraft.url = '';
          imgDraft.data = dataUrl;
          uploadHint.textContent = (file.name || 'Photo') + ' · framed and ready to save';
          // Live preview under the uploader
          let prev = studioHost.parentElement?.querySelector('img.brand-prev');
          if (!prev) {
            prev = el('img', 'brand-prev');
            prev.alt = '';
            prev.style.cssText = 'width:64px;height:64px;border-radius:12px;object-fit:cover;display:block;margin:0.4rem 0';
            studioHost.parentElement?.insertBefore(prev, studioHost);
          }
          prev.src = dataUrl;
        });
      } catch (err) {
        console.warn(err);
      }
    });
    fileRow.append(fileInput, uploadHint, studioHost);
    nodes.push(fileRow);

    const imgActions = el('div', 'actions');
    const saveImg = el('button', 'btn primary small', 'Save server image');
    saveImg.type = 'button';
    saveImg.addEventListener('click', async () => {
      if (!imgDraft.data && !(imgDraft.url && imgDraft.url.trim())) {
        toast('Pick a photo or paste an https image URL first.', 'bad');
        return;
      }
      saveImg.disabled = true;
      saveImg.textContent = 'Saving…';
      try {
        const payload = imgDraft.data
          ? { data: imgDraft.data }
          : { url: String(imgDraft.url || '').trim() };
        const res = await post('bot-profile-server-image', payload);
        if (res?.ok) {
          imgDraft.data = null;
          if (res.overview) state.overview = res.overview;
          else try { state.overview = await get(`/api/guild/${state.guildId}`); } catch {}
          renderBotProfile();
          toast('Server bot image saved.', 'good');
        } else if (res?.unchanged) {
          toast('That image is already set for this server.');
        }
      } finally {
        saveImg.disabled = false;
        saveImg.textContent = 'Save server image';
      }
    });
    const clearImg = el('button', 'btn small', 'Clear image');
    clearImg.type = 'button';
    clearImg.addEventListener('click', async () => {
      clearImg.disabled = true;
      try {
        const res = await post('bot-profile-server-image', { url: '' });
        if (res?.ok || res?.unchanged) {
          try { state.overview = await get(`/api/guild/${state.guildId}`); } catch {}
          renderBotProfile();
        }
      } finally { clearImg.disabled = false; }
    });
    imgActions.append(saveImg, clearImg);
    nodes.push(imgActions);
  }

  // ── Global identity (owner only) ──────────────────────────────────────
  if (bp.canEditGlobal) {
    nodes.push(el('h2', null, 'Global identity'));
    nodes.push(el('p', 'hint', 'These change the bot in every server. Username changes are rate-limited by Discord. To change the picture, choose a new photo and save — there is no remove toggle.'));

    const globalDraft = {
      username: g.username || '',
      bio: g.bio || '',
      avatar: null,
    };

    nodes.push(textField('Username', globalDraft.username, v => { globalDraft.username = v; }));
    nodes.push(textField('Bio / About me', globalDraft.bio, v => { globalDraft.bio = v; }, {
      placeholder: 'Optional, max 190 characters',
    }));

    // Creative avatar studio: pick a photo, then zoom + drag inside a circle.
    const avWrap = el('div', 'field');
    avWrap.append(el('span', null, 'Avatar image'));
    const fileInput = el('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/png,image/jpeg,image/webp,image/gif';
    const avHint = el('p', 'hint', 'Choose a photo, then zoom and drag to frame it. What you see in the circle is what Discord gets.');
    const studioHost = el('div');
    studioHost.style.cssText = 'display:none;margin-top:0.75rem';
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files && fileInput.files[0];
      globalDraft.avatar = null;
      studioHost.replaceChildren();
      studioHost.style.display = 'none';
      if (!file) {
        avHint.textContent = 'Choose a photo, then zoom and drag to frame it. What you see in the circle is what Discord gets.';
        return;
      }
      try {
        const bitmap = await loadImageElement(file);
        openAvatarStudio(studioHost, bitmap, file.name, (dataUri) => {
          globalDraft.avatar = dataUri;
          avHint.textContent = file.name + ' · framed and ready to save';
        });
        studioHost.style.display = '';
        avHint.textContent = 'Zoom and drag, then the framed circle is used when you save.';
      } catch (err) {
        toast(err.message || 'Could not read that image.', 'bad');
        fileInput.value = '';
      }
    });
    avWrap.append(fileInput);
    nodes.push(avWrap, avHint, studioHost);

    const globalActions = el('div', 'actions');
    const saveGlobal = el('button', 'btn primary small', 'Save global profile');
    saveGlobal.type = 'button';
    saveGlobal.addEventListener('click', async () => {
      const body = {};
      if (globalDraft.username && globalDraft.username !== g.username) body.username = globalDraft.username;
      if (globalDraft.bio !== (g.bio || '')) body.bio = globalDraft.bio;
      if (globalDraft.avatar) body.avatar = globalDraft.avatar;

      if (!Object.keys(body).length) {
        toast('Nothing to change. Edit the name, bio, or choose a new photo.');
        return;
      }

      if (body.username) {
        if (!await askConfirm({
          title: 'Change the bot username?',
          message: `Discord will rename the bot to “${body.username}” in every server. Username changes are rate-limited — if it fails, wait and try again later.`,
          confirmLabel: 'Change username',
        })) return;
      }

      saveGlobal.disabled = true;
      saveGlobal.textContent = 'Saving…';
      try {
        const res = await post('bot-profile-global', body);
        if (res?.ok) {
          try { state.overview = await get(`/api/guild/${state.guildId}`); } catch { /* keep */ }
          renderBotProfile();
        }
      } finally {
        saveGlobal.disabled = false;
        saveGlobal.textContent = 'Save global profile';
      }
    });
    globalActions.append(saveGlobal);
    nodes.push(globalActions);
  } else if (!bp.canEditGlobal && !bp.canEditPresence) {
    nodes.push(el('p', 'hint', 'Only the bot operator can change global name, avatar, bio and status.'));
  }

  // ── Reset everything the panel controls back to defaults ─────────────
  if (bp.canEditPresence || bp.canEditNickname || bp.canEditGlobal) {
    nodes.push(el('h2', null, 'Reset'));
    nodes.push(el('p', 'hint',
      'Puts status back to Online · Watching QuantLab | /help, clears this server’s nickname, and clears the bio. Username and avatar are not changed (upload a new photo if you want a different picture).'));

    const resetAll = el('button', 'btn small danger', 'Reset to defaults');
    resetAll.type = 'button';
    resetAll.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'Reset bot panel settings?',
        message: 'Status → Online, activity → “QuantLab | /help”, this server’s nickname cleared, bio cleared. Username and avatar stay as they are.',
        confirmLabel: 'Reset to defaults',
        danger: true,
      })) return;

      resetAll.disabled = true;
      resetAll.textContent = 'Resetting…';
      try {
        if (bp.canEditPresence) {
          await post('bot-profile-presence', { ...DEFAULT_PRESENCE });
        }
        if (bp.canEditNickname) {
          await post('bot-profile-nick', { nickname: '' });
        }
        if (bp.canEditGlobal) {
          await post('bot-profile-global', { bio: '' });
        }
        try { state.overview = await get(`/api/guild/${state.guildId}`); } catch { /* keep */ }
        renderBotProfile();
        toast('Reset to defaults.', 'good');
      } finally {
        resetAll.disabled = false;
        resetAll.textContent = 'Reset to defaults';
      }
    });
    const wrap = el('div', 'actions');
    wrap.append(resetAll);
    nodes.push(wrap);
  }

  box.replaceChildren(...nodes);
}

/** Read an image file and return a data URI, resized to fit Discord avatars. */
/** Load a File into an HTMLImageElement. */
function loadImageElement(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type || !file.type.startsWith('image/')) {
      reject(new Error('Pick an image file.'));
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      reject(new Error('Image is too large (max 12 MB).'));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read that file.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('That file is not a valid image.'));
      img.onload = () => {
        if (!img.naturalWidth || !img.naturalHeight) {
          reject(new Error('That image has no size.'));
          return;
        }
        resolve(img);
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Creative avatar studio.
 * Circular frame, zoom slider, drag to pan — the circle is exactly what is uploaded.
 * Renders at high resolution (1024²) with retina-sharp preview so the Discord
 * avatar stays crisp, not soft from a 256px bake.
 */
function openAvatarStudio(host, img, fileName, onReady) {
  // Discord accepts avatars up to 1024×1024. Baking at 256 made every upload soft.
  const SIZE = 1024;
  const cssView = Math.min(300, Math.floor((window.innerWidth || 320) * 0.75));
  // Draw the on-screen stage at device pixel ratio so the preview is sharp on phones.
  const dpr = Math.min(3, Math.max(1, window.devicePixelRatio || 1));
  const VIEW = Math.round(cssView * dpr);

  const state = {
    zoom: 1,
    x: 0, // pan in CSS pixels
    y: 0,
    dragging: false,
    lastX: 0,
    lastY: 0,
  };

  // Cover scale in CSS-pixel space
  const cover = Math.max(cssView / img.naturalWidth, cssView / img.naturalHeight);

  const shell = el('div');
  shell.style.cssText = [
    'border:1px solid var(--rule)',
    'border-radius:16px',
    'background:var(--sunken)',
    'padding:1rem',
    'display:flex',
    'flex-direction:column',
    'gap:0.85rem',
    'align-items:center',
  ].join(';');

  const title = el('p', 'hint', 'Frame your avatar');
  title.style.cssText = 'margin:0;align-self:stretch;text-align:center;letter-spacing:0.06em;text-transform:uppercase;font-size:0.72rem';

  const stage = el('div');
  stage.style.cssText = [
    `width:${cssView}px`,
    `height:${cssView}px`,
    'border-radius:50%',
    'overflow:hidden',
    'position:relative',
    'cursor:grab',
    'touch-action:none',
    'box-shadow:0 0 0 2px color-mix(in srgb, var(--accent) 55%, transparent), 0 12px 40px rgba(0,0,0,0.45)',
    'background:#0a0c10',
  ].join(';');

  const canvas = document.createElement('canvas');
  canvas.width = VIEW;
  canvas.height = VIEW;
  canvas.style.cssText = 'width:100%;height:100%;display:block;';
  stage.append(canvas);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  function draw() {
    const scale = cover * state.zoom * dpr;
    const w = img.naturalWidth * scale;
    const h = img.naturalHeight * scale;
    const dx = (VIEW - w) / 2 + state.x * dpr;
    const dy = (VIEW - h) / 2 + state.y * dpr;
    ctx.clearRect(0, 0, VIEW, VIEW);
    ctx.save();
    ctx.beginPath();
    ctx.arc(VIEW / 2, VIEW / 2, VIEW / 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, dx, dy, w, h);
    ctx.restore();
    // Soft vignette (preview only — not baked into the upload)
    const g = ctx.createRadialGradient(VIEW / 2, VIEW / 2, VIEW * 0.42, VIEW / 2, VIEW / 2, VIEW / 2);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, 'rgba(0,0,0,0.28)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, VIEW, VIEW);
  }

  function clampPan() {
    const scale = cover * state.zoom;
    const w = img.naturalWidth * scale;
    const h = img.naturalHeight * scale;
    const maxX = Math.max(0, (w - cssView) / 2);
    const maxY = Math.max(0, (h - cssView) / 2);
    state.x = Math.min(maxX, Math.max(-maxX, state.x));
    state.y = Math.min(maxY, Math.max(-maxY, state.y));
  }

  function bake() {
    // Full 1024² export — same framing as the preview, no vignette.
    const out = document.createElement('canvas');
    out.width = SIZE;
    out.height = SIZE;
    const octx = out.getContext('2d');
    octx.imageSmoothingEnabled = true;
    octx.imageSmoothingQuality = 'high';
    const scale = cover * state.zoom * (SIZE / cssView);
    const w = img.naturalWidth * scale;
    const h = img.naturalHeight * scale;
    const dx = (SIZE - w) / 2 + state.x * (SIZE / cssView);
    const dy = (SIZE - h) / 2 + state.y * (SIZE / cssView);
    // Opaque background so JPEG has no black edges from transparency
    octx.fillStyle = '#0a0c10';
    octx.fillRect(0, 0, SIZE, SIZE);
    octx.drawImage(img, dx, dy, w, h);

    // Prefer PNG when the result is small enough; otherwise high-quality JPEG.
    // PNG keeps sharp edges/logos; JPEG is smaller for photos.
    const png = out.toDataURL('image/png');
    // ~700KB raw base64 is still under a raised 900KB server limit after decode.
    if (png.length < 900_000) return png;
    return out.toDataURL('image/jpeg', 0.95);
  }

  const onDown = (e) => {
    state.dragging = true;
    stage.style.cursor = 'grabbing';
    const pt = e.touches ? e.touches[0] : e;
    state.lastX = pt.clientX;
    state.lastY = pt.clientY;
    e.preventDefault();
  };
  const onMove = (e) => {
    if (!state.dragging) return;
    const pt = e.touches ? e.touches[0] : e;
    state.x += pt.clientX - state.lastX;
    state.y += pt.clientY - state.lastY;
    state.lastX = pt.clientX;
    state.lastY = pt.clientY;
    clampPan();
    draw();
    e.preventDefault();
  };
  const onUp = () => {
    state.dragging = false;
    stage.style.cursor = 'grab';
    onReady(bake());
  };
  stage.addEventListener('mousedown', onDown);
  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
  stage.addEventListener('touchstart', onDown, { passive: false });
  stage.addEventListener('touchmove', onMove, { passive: false });
  stage.addEventListener('touchend', onUp);

  const zoomField = el('label', 'field');
  zoomField.style.cssText = 'width:100%;max-width:' + cssView + 'px';
  const zoomHead = el('div', 'field-head');
  const zoomLabel = el('span', null, 'Zoom');
  const zoomVal = el('span', 'count', '100%');
  zoomHead.append(zoomLabel, zoomVal);
  zoomField.append(zoomHead);
  const range = el('input');
  range.type = 'range';
  range.min = '100';
  range.max = '300';
  range.value = '100';
  range.step = '1';
  range.style.cssText = 'width:100%;accent-color:var(--accent)';
  range.addEventListener('input', () => {
    state.zoom = Number(range.value) / 100;
    zoomVal.textContent = Math.round(state.zoom * 100) + '%';
    clampPan();
    draw();
    onReady(bake());
  });
  zoomField.append(range);

  const chips = el('div', 'chipset');
  for (const z of [100, 125, 150, 200]) {
    const b = el('button', 'chip', z + '%');
    b.type = 'button';
    b.addEventListener('click', () => {
      range.value = String(z);
      state.zoom = z / 100;
      zoomVal.textContent = z + '%';
      clampPan();
      draw();
      onReady(bake());
    });
    chips.append(b);
  }

  const hint = el('p', 'hint', 'Drag to reposition · zoom for detail · exported at 1024×1024');
  hint.style.cssText = 'margin:0;text-align:center';

  stage.addEventListener('wheel', (e) => {
    e.preventDefault();
    const next = Math.min(3, Math.max(1, state.zoom + (e.deltaY < 0 ? 0.08 : -0.08)));
    state.zoom = next;
    range.value = String(Math.round(next * 100));
    zoomVal.textContent = Math.round(next * 100) + '%';
    clampPan();
    draw();
    onReady(bake());
  }, { passive: false });

  shell.append(title, stage, zoomField, chips, hint);
  host.replaceChildren(shell);
  draw();
  onReady(bake());
}





/* ── reports, cases and warnings ───────────────────────────────────────────
   Reports lead the section because they are the only thing here waiting on a
   person. Everything below is reference or settings. */


function openCase(c) {
  const kind = c.type === 'mute' ? 'timeout' : c.type;
  const when = c.at ? relativeTime(c.at) : '—';
  const body = [
    sheetRow('Case', `#${c.id}`),
    sheetRow('Action', `${c.icon || ''} ${String(c.type).toUpperCase()}`.trim()),
    sheetRow('Member', `${c.userName || c.userTag || 'Unknown'}`),
    sheetRow('User ID', el('span', 'v mono wrap', c.userId || '—')),
    sheetRow('Moderator', c.moderator || '—'),
    sheetRow('When', when),
  ];
  if (c.durationMs) body.push(sheetRow('Duration', `${Math.round(c.durationMs / 60000)} min`));
  if (c.clearedAt) body.push(sheetRow('Status', 'Warning forgiven'));
  else if (c.inServer === false) body.push(sheetRow('Status', 'Left the server'));
  if (c.reason) body.push(sheetRow('Reason', c.reason));

  const btns = [];

  // Follow-up actions — same double-tap arm pattern as report sheet
  const arm = (label, danger, run) => {
    const b = el('button', `btn ${danger ? 'danger' : ''}`.trim(), label);
    b.type = 'button';
    b.addEventListener('click', async () => {
      if (b.dataset.armed !== '1') {
        b.dataset.armed = '1';
        b.textContent = `Tap again to confirm`;
        return;
      }
      b.disabled = true;
      try { await run(); }
      finally {
        if (!$('#sheet').hidden) {
          b.disabled = false;
          b.dataset.armed = '';
          b.textContent = label;
        }
      }
    });
    return b;
  };

  if (c.type === 'warn' && !c.clearedAt && c.userId) {
    btns.push(arm('Clear warnings', true, async () => {
      const out = await post('warnclear', { userId: c.userId });
      if (out && state.overview?.mod) {
        const uid = c.userId;
        state.overview.mod.warned = (state.overview.mod.warned || []).filter(x => x.userId !== uid);
        state.overview.mod.cases = (state.overview.mod.cases || []).filter(x =>
          !(x.type === 'warn' && x.userId === uid)
        );
        if (out.overview?.mod) state.overview.mod = out.overview.mod;
        try { renderModeration(); } catch (_) {}
      }
      if (out) closeSheet();
    }));
  }

  if (c.userId) {
    const fill = el('button', 'btn', 'Use in Quick action');
    fill.type = 'button';
    fill.addEventListener('click', () => {
      state.modQuick = state.modQuick || { userId: '', action: 'warn', reason: '', timeoutMinutes: 60 };
      state.modQuick.userId = String(c.userId);
      closeSheet();
      renderModeration();
      toast('User ID filled in Quick action.', 'good');
    });
    btns.push(fill);

    // Escalate from an existing case
    if (kind === 'warn' || kind === 'timeout') {
      btns.push(arm('Timeout 1h', false, async () => {
        const out = await post('modaction', {
          userId: c.userId, action: 'timeout', reason: c.reason || `Follow-up on case #${c.id}`,
          timeoutMinutes: 60,
        });
        if (out) closeSheet();
      }));
    }
    if (kind !== 'ban') {
      btns.push(arm('Kick', true, async () => {
        const out = await post('modaction', {
          userId: c.userId, action: 'kick', reason: c.reason || `Follow-up on case #${c.id}`,
        });
        if (out) closeSheet();
      }));
      btns.push(arm('Ban', true, async () => {
        const out = await post('modaction', {
          userId: c.userId, action: 'ban', reason: c.reason || `Follow-up on case #${c.id}`,
        });
        if (out) closeSheet();
      }));
    }
  }

  openSheet(`Case #${c.id} · ${String(c.type).toUpperCase()}`, body, btns);
}


function renderModeration() {

  const m = state.overview?.mod;
  if (!m) return;

  /* -- the report queue -------------------------------------------------- */
  const chState = $('#report-channel-state');
  chState.textContent = m.reports.channel
    ? `Filed to #${m.reports.channel}`
    : 'No report channel set — /report cannot be used';
  chState.className = `hint${m.reports.channel ? '' : ' bad'}`;

  const count = $('#report-count');
  count.hidden = m.reports.open.length === 0;
  count.textContent = String(m.reports.open.length);

  const open = $('#report-open');
  open.replaceChildren(...(m.reports.open.length ? m.reports.open.map(r => {
    const d = el('button', 'gaw tappable');
    d.type = 'button';
    const top = el('div', 'gaw-top');
    // Repeat offenders are the ones worth spotting from the list.
    const repeat = r.priorActioned > 0 || r.warnings > 0;
    top.append(
      el('span', `kind ${repeat ? 'sev-warn' : 'sev-clear'}`, repeat ? 'REPEAT' : 'NEW'),
      el('span', 'nm', r.targetName),
    );
    d.append(top);
    d.append(el('p', 'hint', `${r.reason} · from ${r.reporterName}${r.createdAt ? ` · ${relativeTime(r.createdAt)}` : ''}`));
    const bits = [];
    if (r.warnings) bits.push(`${r.warnings} warning${r.warnings === 1 ? '' : 's'}`);
    if (r.priorActioned) bits.push(`${r.priorActioned} report${r.priorActioned === 1 ? '' : 's'} actioned before`);
    if (!r.inServer) bits.push('no longer in the server');
    if (bits.length) d.append(el('p', 'hint', bits.join(' · ')));
    d.append(el('span', 'chev', '›'));
    d.addEventListener('click', () => openReport(r));
    return d;
  }) : [el('p', 'muted', 'No reports waiting.')]));

  /* -- members with warnings --------------------------------------------- */
  const warned = $('#warned-list');
  warned.replaceChildren(...(m.warned.length ? m.warned.map(w => {
    const r = el('div', 'permit');
    r.append(el('span', 'who', w.name));
    const right = el('div', 'permit-right');
    right.append(el('span', `pill ${w.count >= 3 ? 'wait' : 'off'}`, `${w.count} warning${w.count === 1 ? '' : 's'}`));
    const clear = el('button', 'btn small', 'Clear');
    clear.type = 'button';
    clear.addEventListener('click', async () => {
      if (!await askConfirm({
        title: `Clear warnings for ${w.name}?`,
        message: `All ${w.count} warning${w.count === 1 ? '' : 's'} are removed. Kicks and bans stay on the case log — those are a record of something that happened.`,
        confirmLabel: 'Clear them', danger: true,
      })) return;
      clear.disabled = true;
      const out = await post('warnclear', { userId: w.userId });
      // Optimistic: drop them from warned list + case log immediately
      if (state.overview?.mod?.warned) {
        state.overview.mod.warned = state.overview.mod.warned.filter(x => x.userId !== w.userId);
      }
      if (state.overview?.mod?.cases) {
        state.overview.mod.cases = state.overview.mod.cases.filter(x =>
          !(x.type === 'warn' && x.userId === w.userId)
        );
      }
      if (out?.overview?.mod) {
        state.overview.mod = out.overview.mod;
      } else if (out?.ok !== false) {
        try {
          const fresh = await get(`/api/guild/${state.guildId}`);
          if (fresh?.mod) state.overview.mod = fresh.mod;
          else if (fresh?.guild) state.overview = fresh;
        } catch {}
      }
      renderModeration();
      if (out?.ok !== false && out?.unchanged !== true) toast('Warnings cleared.', 'good');
      else if (out?.unchanged) {
        // Still remove from UI if backend said nothing left to clear
        renderModeration();
      } else {
        clear.disabled = false;
      }
    });
    right.append(clear);
    r.append(right);
    return r;
  }) : [el('p', 'muted', 'Nobody has a warning.')]));

  $('#case-total').textContent = m.caseTotal ? `${num(m.caseTotal)} cases logged` : '';

  /* -- case log + filters ------------------------------------------------ */
  if (!state.caseFilter) state.caseFilter = 'all';
  const CASE_FILTERS = [
    { id: 'all', label: 'All' },
    { id: 'warn', label: 'Warns' },
    { id: 'timeout', label: 'Timeouts' },
    { id: 'kick', label: 'Kicks' },
    { id: 'ban', label: 'Bans' },
  ];
  const typeAlias = t => (t === 'mute' ? 'timeout' : t);
  const allCases = m.cases || [];
  const filtered = state.caseFilter === 'all'
    ? allCases
    : allCases.filter(c => typeAlias(c.type) === state.caseFilter);

  const filtersEl = $('#case-filters');
  if (filtersEl) {
    filtersEl.replaceChildren(...CASE_FILTERS.map(f => {
      const b = el('button', `chip-toggle${state.caseFilter === f.id ? ' on' : ''}`, f.label);
      b.type = 'button';
      b.setAttribute('aria-pressed', state.caseFilter === f.id ? 'true' : 'false');
      b.addEventListener('click', () => {
        state.caseFilter = f.id;
        renderModeration();
      });
      return b;
    }));
  }

  const logCount = $('#case-log-count');
  if (logCount) {
    logCount.hidden = filtered.length === 0;
    logCount.textContent = String(filtered.length);
  }
  const logHint = $('#case-log-hint');
  if (logHint) {
    logHint.textContent = m.caseTotal
      ? `${num(m.caseTotal)} total on record · showing latest ${allCases.length}`
      : 'No cases yet';
  }

  const logEl = $('#case-log');
  if (logEl) {
    logEl.replaceChildren(...(filtered.length ? filtered.map(c => {
      const d = el('button', 'gaw tappable');
      d.type = 'button';
      const kind = typeAlias(c.type);
      const sev = kind === 'ban' || kind === 'kick' ? 'sev-warn'
        : kind === 'timeout' ? 'sev-clear'
        : kind === 'warn' ? 'sev-clear' : '';

      const top = el('div', 'gaw-top');
      top.append(
        el('span', `kind ${sev}`.trim(), String(c.type).toUpperCase()),
        el('span', 'nm', c.userName || c.userTag || c.userId || 'Unknown'),
        el('span', 'idtag', `#${c.id}`),
      );
      d.append(top);

      const when = c.at ? relativeTime(c.at) : null;
      const bits = [];
      bits.push(`by ${c.moderator || 'unknown'}`);
      if (when) bits.push(when);
      if (c.clearedAt) bits.push('forgiven');
      if (c.inServer === false) bits.push('left server');
      if (c.durationMs) bits.push(`${Math.round(c.durationMs / 60000)}m timeout`);
      d.append(el('p', 'hint', bits.join(' · ')));

      if (c.reason) {
        const reason = c.reason.length > 140 ? c.reason.slice(0, 137) + '…' : c.reason;
        d.append(el('p', 'hint', reason));
      }

      d.append(el('span', 'chev', '›'));
      d.addEventListener('click', () => openCase(c));
      return d;
    }) : [el('p', 'muted', state.caseFilter === 'all'
      ? 'No cases logged yet.'
      : 'No cases in this filter.')]));
  }

  /* -- quick action form ------------------------------------------------- */
  const qa = state.modQuick || (state.modQuick = {
    userId: '', action: 'warn', reason: '', timeoutMinutes: 60,
  });
  const qaForm = $('#form-modaction');
  if (qaForm) {
    const timeoutField = textField('Timeout minutes (timeout only)', String(qa.timeoutMinutes), v => {
      qa.timeoutMinutes = Number(v) || 60;
    });
    timeoutField.style.display = qa.action === 'timeout' ? '' : 'none';
    qaForm.replaceChildren(
      pickMember('Member', qa.userId, v => { qa.userId = v || ''; }),
      select('Action', qa.action, [
        { value: 'warn', label: 'Warn' },
        { value: 'timeout', label: 'Timeout' },
        { value: 'kick', label: 'Kick' },
        { value: 'ban', label: 'Ban' },
      ], v => {
        qa.action = v;
        timeoutField.style.display = v === 'timeout' ? '' : 'none';
      }),
      timeoutField,
      areaField('Reason', qa.reason, v => { qa.reason = v; }, 2),
      actions(async () => {
        if (!/^\d{5,25}$/.test(qa.userId || '')) {
          toast('Pick a member from the list.', 'bad');
          return;
        }
        const label = qa.action === 'timeout' ? 'timeout' : qa.action;
        const who = (state.overview?.features?.members || []).find(m => m.id === qa.userId);
        const whoName = who?.displayName || who?.name || qa.userId;
        if (!await askConfirm({
          title: `${label[0].toUpperCase() + label.slice(1)} ${whoName}?`,
          message: `${whoName} will be ${label === 'timeout' ? 'timed out' : label + 'ed'} from the panel. A case is logged and they are DMed when possible.`,
          confirmLabel: 'Do it', danger: qa.action === 'ban' || qa.action === 'kick',
        })) return;
        await post('modaction', {
          userId: qa.userId,
          action: qa.action,
          reason: qa.reason,
          timeoutMinutes: qa.timeoutMinutes,
        });
        qa.reason = '';
      }, { label: 'Run action', busyLabel: 'Working…' }),
    );
  }

  /* -- automatic punishment ---------------------------------------------- */
  const ws = { ...m.warnSettings };
  const muteField = textField('Mute length (minutes)', String(ws.muteMinutes), v => { ws.muteMinutes = Number(v); });
  muteField.style.display = ws.action === 'mute' ? '' : 'none';

  $('#form-warnsettings').replaceChildren(
    textField('Act after this many warnings — 0 for never', String(ws.threshold), v => { ws.threshold = Number(v); }),
    select('What to do', ws.action, [
      { value: 'kick', label: 'Kick them' },
      { value: 'ban', label: 'Ban them' },
      { value: 'mute', label: 'Time them out' },
    ], v => { ws.action = v; muteField.style.display = v === 'mute' ? '' : 'none'; }),
    muteField,
    actions(() => post('warnsettings', ws)),
  );

  /* -- auto-role on join --------------------------------------------------- */
  const roleOptions = (m.roles || []).map(r => ({ value: r.id, label: r.name }));
  const autoRole = { roleId: m.autoRole || '' };
  $('#form-autorole').replaceChildren(
    select('Role to give new members', autoRole.roleId, roleOptions,
      v => { autoRole.roleId = v; }, { blank: 'Not set' }),
    actions(() => post('autorole', autoRole)),
  );

  /* -- filtered words ----------------------------------------------------- */
  const words = { customWords: m.filters.customWords.slice() };
  $('#form-badwords').replaceChildren(
    areaField(`Words and phrases, one per line (${m.filters.customWords.length})`,
      words.customWords.join('\n'),
      v => { words.customWords = v.split('\n').map(w => w.trim()).filter(Boolean); }, 5),
    actions(() => post('moderation', words)),
  );
}

/** A report, and everything that can be done about it. */
function openReport(r) {
  const body = [
    sheetRow('Reported', `${r.targetName} (${r.targetTag})`),
    sheetRow('Reason', r.reason),
    sheetRow('Reported by', r.reporterName),
    sheetRow('Account age', r.accountAge),
    sheetRow('Still here', r.inServer ? 'yes' : 'no'),
    sheetRow('Warnings', String(r.warnings)),
    sheetRow('Past reports', r.priorReports
      ? `${r.priorReports} · ${r.priorActioned} actioned`
      : 'none'),
  ];
  if (r.link) body.push(sheetRow('Message', el('span', 'v mono wrap', r.link)));

  const why = { text: '' };
  body.push(textField('Reason to record (optional)', '', v => { why.text = v; }));

  const timeout = { minutes: 60 };
  const timeoutField = textField('Timeout length (minutes)', '60', v => { timeout.minutes = Number(v); });
  body.push(timeoutField);

  const act = (label, action, danger) => {
    const b = el('button', `btn ${danger ? 'danger' : ''}`.trim(), label);
    b.type = 'button';
    // A member who has left can still be banned, but not kicked or timed out.
    if (!r.inServer && (action === 'kick' || action === 'timeout')) b.disabled = true;
    b.addEventListener('click', async () => {
      if (b.dataset.armed !== '1' && action !== 'dismiss') {
        b.dataset.armed = '1';
        b.textContent = `Tap again to ${label.toLowerCase()}`;
        return;
      }
      b.disabled = true;
      const out = await post('report', {
        reportId: r.id, action, reason: why.text,
        timeoutMinutes: timeout.minutes,
      });
      if (out) closeSheet();
      else { b.disabled = false; b.dataset.armed = ''; b.textContent = label; }
    });
    return b;
  };

  openSheet(`Report · ${r.targetName}`, body, [
    act('Warn', 'warn', false),
    act('Timeout', 'timeout', false),
    act('Kick', 'kick', true),
    act('Ban', 'ban', true),
    act('Dismiss', 'dismiss', false),
  ]);
}

/* ── link requests ─────────────────────────────────────────────────────────
   The queue used to live only as cards in the mod-log channel, which means
   noticing one requires being in Discord, on the right channel, at the time.

   Each row leads with the domain rather than the member, because that is what
   the decision is actually about, and carries the worst signal found so a row
   that needs reading looks different from one that does not. */

const SEVERITY_LABEL = { danger: 'CHECK', warn: 'LOOK', clear: 'CLEAR' };

function renderLinkRequests() {
  const l = state.overview?.links;
  if (!l) return;

  const stateLine = $('#link-filter-state');
  stateLine.textContent = l.filterOn
    ? 'Link filter is on'
    : 'Link filter is off — nothing new will arrive here';
  stateLine.className = `hint${l.filterOn ? '' : ' bad'}`;

  const count = $('#link-count');
  count.hidden = l.waiting.length === 0;
  count.textContent = String(l.waiting.length);

  /* -- waiting on a decision --------------------------------------------- */
  const wrap = $('#link-waiting');
  const rows = l.waiting.map(r => {
    const d = el('button', 'gaw tappable');
    d.type = 'button';
    const top = el('div', 'gaw-top');
    top.append(
      el('span', `kind sev-${r.severity}`, SEVERITY_LABEL[r.severity] || 'LOOK'),
      el('span', 'nm', r.domain || 'unreadable address'),
    );
    d.append(top);
    d.append(el('p', 'hint', `${r.displayName} · in #${r.channel || 'a deleted channel'}${r.createdAt ? ` · ${relativeTime(r.createdAt)}` : ''}`));
    if (r.flags.length) d.append(el('p', 'hint', r.flags[0].text));
    d.append(el('span', 'chev', '›'));
    d.addEventListener('click', () => openLinkRequest(r));
    return d;
  });

  // An unfinished request still blocks that member from opening another one,
  // so it has to be visible and clearable even though there is nothing to
  // decide on it yet.
  for (const r of l.unfinished) {
    const d = el('div', 'gaw');
    const top = el('div', 'gaw-top');
    top.append(el('span', 'kind sev-idle', 'UNSENT'), el('span', 'nm', r.displayName));
    d.append(top);
    d.append(el('p', 'hint', 'Was told to ask but never filled the form in. This still blocks them from opening another request.'));
    const act = el('div', 'actions');
    const drop = el('button', 'btn small', 'Clear it');
    drop.type = 'button';
    drop.addEventListener('click', async () => {
      drop.disabled = true;
      await post('linkrequest', { requestId: r.id, action: 'discard' });
    });
    act.append(drop);
    d.append(act);
    rows.push(d);
  }

  wrap.replaceChildren(...(rows.length ? rows : [el('p', 'muted', 'Nothing waiting.')]));

  /* -- standing permissions ---------------------------------------------- */
  // Its own row rather than the generic one: a name, a state and a button do
  // not sit on a shared baseline, and the button needs to be held off the
  // text rather than butted against it.
  const permits = $('#link-permits');
  permits.replaceChildren(...(l.permits.length ? l.permits.map(p => {
    const r = el('div', 'permit');
    r.append(el('span', 'who', p.displayName));

    const right = el('div', 'permit-right');
    const state = p.state === 'locked'
      ? { cls: 'off', text: `locked ${readableWait(p.secondsLeft)}` }
      : p.state === 'waiting'
        ? { cls: 'wait', text: `next in ${readableWait(p.secondsLeft)}` }
        : { cls: 'on', text: 'may post now' };
    right.append(el('span', `pill ${state.cls}`, state.text));

    const revoke = el('button', 'btn small danger', 'Revoke');
    revoke.type = 'button';
    revoke.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'Revoke this permission?',
        message: `${p.displayName} will need to ask again before posting another link.`,
        confirmLabel: 'Revoke it', danger: true,
      })) return;
      revoke.disabled = true;
      await post('linkrevoke', { userId: p.userId });
    });
    right.append(revoke);

    r.append(right);
    return r;
  }) : [el('p', 'muted', 'Nobody has a standing permission.')]));

  /* -- recently decided --------------------------------------------------- */
  const recent = $('#link-recent');
  recent.replaceChildren(...(l.recent.length ? l.recent.map(r => {
    const row = el('div', 'row');
    row.append(el('span', 'k', `${r.status === 'approved' ? '✅' : '❌'} ${r.domain || '—'}`));
    row.append(el('span', 'v dim',
      `${r.displayName}${r.decidedBy ? ` · by ${r.decidedBy}` : ''}${r.decidedAt ? ` · ${relativeTime(r.decidedAt)}` : ''}`));
    return row;
  }) : [el('p', 'muted', 'No decisions yet.')]));
}

function readableWait(seconds) {
  if (!seconds || seconds < 0) return 'now';
  if (seconds < 60) return `${Math.ceil(seconds)}s`;
  if (seconds < 3600) return `${Math.ceil(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.round(seconds / 3600)}h`;
  return `${Math.round(seconds / 86400)}d`;
}

/**
 * The full request, and the two decisions.
 *
 * Everything found about the link is laid out before the buttons, because the
 * whole point is that approving should be a judgement rather than a reflex.
 */
function openLinkRequest(r) {
  const body = [];

  const flags = el('div', 'signals');
  for (const f of (r.flags.length ? r.flags : [{ level: 'good', text: 'Nothing unusual about this one.' }])) {
    flags.append(el('p', `signal ${f.level}`, f.text));
  }
  body.push(flags);

  body.push(sheetRow('Link', el('span', 'v mono wrap', r.link || '—')));
  body.push(sheetRow('Asked by', `${r.displayName} (${r.userTag})`));
  body.push(sheetRow('Account age', r.accountAge));
  if (r.memberAge) body.push(sheetRow('In this server', r.memberAge));
  body.push(sheetRow('Past requests', r.history.total > 1
    ? `${r.history.approved} approved · ${r.history.denied} denied`
    : 'This is their first'));
  body.push(sheetRow('Channel', r.channel ? `#${r.channel}` : 'deleted'));

  if (r.reason) {
    const q = el('div', 'quote');
    q.append(el('p', null, r.reason));
    body.push(el('span', 'k', 'Their reason'), q);
  }

  const cool = { value: '24h' };
  body.push(durationField('Then they may post one link every', '24h', v => { cool.value = v; }));

  const approve = el('button', 'btn primary', 'Approve and post it');
  approve.type = 'button';
  approve.addEventListener('click', async () => {
    if (!parseDurationMs(cool.value)) { toast('Cooldown must look like 6h or 7d.', 'bad'); return; }
    approve.disabled = true;
    approve.textContent = 'Posting…';
    const out = await post('linkrequest', { requestId: r.id, action: 'approve', cooldown: cool.value });
    if (out) closeSheet();
    else { approve.disabled = false; approve.textContent = 'Approve and post it'; }
  });

  const denyBtn = el('button', 'btn danger', 'Deny');
  denyBtn.type = 'button';
  denyBtn.addEventListener('click', async () => {
    denyBtn.disabled = true;
    const out = await post('linkrequest', { requestId: r.id, action: 'deny' });
    if (out) closeSheet();
    else denyBtn.disabled = false;
  });

  openSheet(r.domain || 'Link request', body, [approve, denyBtn]);
}

/* ── casino ────────────────────────────────────────────────────────────────
   Three forms rather than one, because they are three different decisions:
   what a bet may be, what the shortcut buttons offer, and which games exist.
   Saving one should not make you re-confirm the other two. */

function renderCasino() {
  const c = state.overview?.casino;
  if (!c) return;

  /* -- table stakes ------------------------------------------------------ */
  const stakes = { ...c.values };
  const stakeNote = el('p', 'hint', '');
  const syncStakeNote = () => {
    const bad = Number(stakes.minBet) >= Number(stakes.maxBet);
    stakeNote.textContent = bad
      ? 'Minimum must be below maximum, or nobody can place a bet at all.'
      : `Bets between ${num(stakes.minBet)} and ${num(stakes.maxBet)} coins.${Number(stakes.cooldownSeconds) > 0 ? ` ${stakes.cooldownSeconds}s between games.` : ' No cooldown between games.'}`;
    stakeNote.className = `hint${bad ? ' bad' : ''}`;
  };

  $('#form-casino').replaceChildren(
    ...c.fields.map(f => textField(`${f.label}${f.key === 'cooldownSeconds' ? ' — 0 for none' : ''}`,
      String(stakes[f.key] ?? ''), v => { stakes[f.key] = Number(v); syncStakeNote(); })),
    stakeNote,
    actions(() => post('casino', stakes)),
  );
  syncStakeNote();

  /* -- quick bets -------------------------------------------------------- */
  const presets = c.presets.slice();
  const presetForm = $('#form-casino-presets');
  const presetNote = el('p', 'hint', '');
  const syncPresetNote = () => {
    // Sorted and de-duplicated server-side, so say so rather than letting the
    // saved order come back looking like the field was ignored.
    const clean = [...new Set(presets.filter(n => n > 0))].sort((a, b) => a - b);
    presetNote.textContent = clean.length < presets.length
      ? `Duplicates and blanks are dropped — this will save as ${clean.join(' / ')} topped up from the defaults.`
      : `Buttons will read ${clean.join(' / ')}, lowest first.`;
  };

  presetForm.replaceChildren(
    ...presets.map((value, i) => textField(`Button ${i + 1}`, String(value), v => {
      presets[i] = Number(v);
      syncPresetNote();
    })),
    presetNote,
    actions(() => post('casino', { presets })),
  );
  syncPresetNote();

  /* -- games ------------------------------------------------------------- */
  const games = Object.fromEntries(c.games.map(g => [g.key, g.enabled]));
  const gamesNote = el('p', 'hint', '');
  const syncGamesNote = () => {
    const on = Object.values(games).filter(Boolean).length;
    gamesNote.textContent = on === 0
      ? 'Every game is off — the casino menu will say it is closed.'
      : `${on} of ${c.games.length} games open.`;
    gamesNote.className = `hint${on === 0 ? ' bad' : ''}`;
  };

  $('#form-casino-games').replaceChildren(
    ...c.games.map(g => toggle(g.label, g.enabled, v => { games[g.key] = v; syncGamesNote(); })),
    gamesNote,
    actions(() => post('casino', { games })),
  );
  syncGamesNote();
}

/* ── tickets ───────────────────────────────────────────────────────────── */

function renderTickets() {
  const t = state.overview?.tickets;
  if (!t) return;

  /* -- the open list ---------------------------------------------------- */
  const wrap = $('#ticket-open');
  if (!t.open.length) {
    wrap.replaceChildren(el('p', 'muted', 'No tickets are open right now.'));
  } else {
    wrap.replaceChildren(...t.open.map(tk => {
      const d = el('div', 'gaw ticket-open-card');
      const top = el('div', 'gaw-top');
      top.append(el('span', 'kind prize', 'OPEN'), el('span', 'nm', `#${tk.name}`));
      d.append(top);

      const bits = [];
      if (tk.createdAt) bits.push(`opened ${relativeTime(tk.createdAt)}`);
      d.append(el('p', 'hint', bits.join(' · ') || 'open'));

      if (tk.ownerId) {
        const line = el('div', 'row');
        const who = tk.ownerTag || tk.ownerName || 'Member';
        const v = el('span', 'v ticket-opener', who);
        v.title = tk.ownerId;
        line.append(el('span', 'k', 'Opened by'), v);
        d.append(line);
      }

      const act = el('div', 'actions');
      const copy = el('button', 'btn small', 'Copy ID');
      copy.type = 'button';
      copy.title = 'Copy channel ID';
      copy.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(String(tk.id));
          toast('Channel ID copied.', 'ok');
        } catch {
          toast(String(tk.id), 'ok');
        }
      });
      const detail = el('button', 'btn small', 'Details');
      detail.type = 'button';
      detail.addEventListener('click', () => openTicketSheet(tk));
      const close = el('button', 'btn small danger', 'Close');
      close.type = 'button';
      close.addEventListener('click', () => openTicketSheet(tk));
      act.append(copy, detail, close);
      d.append(act);
      return d;
    }));
  }

  /* -- settings: support roles (multi) — same list as Settings role chips */
  const draft = {
    supportRoleIds: Array.isArray(t.supportRoleIds) ? [...t.supportRoleIds] : (t.supportRoleId ? [t.supportRoleId] : []),
  };
  $('#form-tickets').replaceChildren(
    pickManyRoles(
      'Support roles',
      roleList(),
      draft.supportRoleIds,
      ids => { draft.supportRoleIds = ids; },
    ),
    el('p', 'hint', 'Members with any of these roles can see and answer tickets. Pick one or more.'),
    actions(() => post('tickets', draft)),
  );

  /* -- post the panel ----------------------------------------------------- */
  const panel = { channelId: '' };
  const postForm = $('#form-ticketpanel');
  postForm.replaceChildren(
    pickOne('Channel', 'channel', '', v => { panel.channelId = v; }, { blank: 'Pick a channel' }),
    actions(async () => {
      if (!panel.channelId) { toast('Pick a channel first.', 'bad'); return; }
      await post('ticketpanel', panel);
    }, { label: 'Post the panel', busyLabel: 'Posting…' }),
  );
}

/** Closing deletes the channel, so it asks in the sheet rather than inline. */
function openTicketSheet(tk) {
  const body = [
    sheetRow('Channel', `#${tk.name}`),
    tk.ownerId ? sheetRow('Opened by', el('span', 'v', tk.ownerTag || tk.ownerName || ('@' + tk.ownerId))) : null,
    tk.ownerId ? sheetRow('User ID', el('span', 'v mono', tk.ownerId)) : null,
    tk.createdAt ? sheetRow('Opened', new Date(tk.createdAt).toLocaleString()) : null,
    sheetRow('Channel ID', el('span', 'v mono', tk.id)),
    el('p', 'note', 'Closing deletes the channel and everything said in it. There is no archive — this cannot be undone.'),
  ].filter(Boolean);

  const close = el('button', 'btn danger', 'Close this ticket');
  close.type = 'button';
  close.addEventListener('click', async () => {
    if (close.dataset.armed !== '1') {
      close.dataset.armed = '1';
      close.textContent = 'Tap again to delete the channel';
      return;
    }
    close.disabled = true;
    const out = await post('ticketclose', { channelId: tk.id });
    if (out) closeSheet();
    else { close.disabled = false; close.dataset.armed = ''; close.textContent = 'Close this ticket'; }
  });

  openSheet(`#${tk.name}`, body, [close]);
}

/** "3 hours ago", for anything with a timestamp and no room for a full date. */
/* ── polls ─────────────────────────────────────────────────────────────────
 *
 * What is running, what it has collected, and the two things you do to a poll
 * that has run long enough. The results are the point: a bar per option
 * against the share of the vote, so the answer is readable at a glance rather
 * than as six numbers you have to add up yourself.
 */

const POLL_LETTERS = 'ABCDE';

// Kept outside the render so typing a question survives the live stream
// repainting this tab underneath you.
const pollDraft = { question: '', options: ['', ''], channelId: null };

function pollResult(p) {
  const card = el('div', 'gaw');

  const top = el('div', 'gaw-top');
  top.append(el('span', `kind ${p.closedAt ? '' : 'prize'}`.trim(), p.closedAt ? 'CLOSED' : 'OPEN'));
  top.append(el('span', 'nm', p.question));
  card.append(top);

  const bits = [];
  if (p.channel) bits.push(`#${p.channel}`);
  bits.push(`${num(p.total)} vote${p.total === 1 ? '' : 's'}`);
  if (p.createdAt) bits.push(relativeTime(p.createdAt));
  if (p.createdByName) bits.push(`by ${p.createdByName}`);
  card.append(el('p', 'hint', bits.join(' · ')));

  // The leader is marked rather than left to be worked out. On a tie nothing
  // is marked, because calling one of them the winner would be a lie.
  const top1 = Math.max(0, ...p.options.map(o => o.votes));
  const leaders = p.options.filter(o => o.votes === top1 && top1 > 0).length;

  const results = el('div', 'poll-results');
  p.options.forEach((o, i) => {
    const line = el('div', `poll-line${o.votes === top1 && leaders === 1 && top1 > 0 ? ' lead' : ''}`);
    line.append(el('span', 'poll-key', POLL_LETTERS[i]));
    const body = el('div', 'poll-body');
    const head = el('div', 'poll-head');
    head.append(el('span', 'poll-label', o.label));
    head.append(el('span', 'poll-num', `${num(o.votes)} · ${o.share}%`));
    body.append(head);
    const track = el('div', 'poll-track');
    const fill = el('i');
    fill.style.width = `${o.share}%`;
    track.append(fill);
    body.append(track);
    line.append(body);
    results.append(line);
  });
  card.append(results);

  const act = el('div', 'actions');
  if (p.link) {
    const open = el('a', 'btn small', 'Open in Discord');
    open.href = p.link;
    open.target = '_blank';
    open.rel = 'noopener';
    act.append(open);
  }
  if (!p.closedAt) {
    const close = el('button', 'btn small', 'Close voting');
    close.type = 'button';
    close.addEventListener('click', async () => {
      close.disabled = true;
      try { await post('pollclose', { messageId: p.messageId }, { quiet: true }); }
      finally { close.disabled = false; }
    });
    act.append(close);
  }
  const drop = el('button', 'btn small danger', 'Remove');
  drop.type = 'button';
  drop.title = 'Takes it off this list. The message in Discord is left alone.';
  drop.addEventListener('click', async () => {
    drop.disabled = true;
    try { await post('polldelete', { messageId: p.messageId }, { quiet: true }); }
    finally { drop.disabled = false; }
  });
  act.append(drop);
  card.append(act);

  return card;
}

function renderPolls() {
  const data = state.overview?.polls;
  if (!data) return;

  const count = $('#poll-count');
  count.textContent = String(data.open.length);
  count.hidden = data.open.length === 0;
  $('#poll-state').textContent = data.closed.length
    ? `${data.closed.length} closed recently`
    : '';

  const wrap = $('#poll-open');
  const shown = [...data.open, ...data.closed];
  wrap.replaceChildren(...(shown.length
    ? shown.map(pollResult)
    : [el('p', 'muted', 'No polls yet. Ask something below, or run /poll in Discord — either way it shows up here.')]));

  /* -- the new-poll form ------------------------------------------------- */
  const limits = data.limits;
  const form = $('#form-poll');

  const optionFields = el('div', 'subfields');
  const drawOptions = () => {
    optionFields.replaceChildren(...pollDraft.options.map((value, i) => {
      const f = textField(`Option ${POLL_LETTERS[i]}`, value,
        v => { pollDraft.options[i] = v.slice(0, limits.option); });
      // Only the options past the required two can be taken away, so the form
      // can never be edited into something the server would reject.
      if (i >= 2) {
        const strip = el('button', 'btn small', 'Remove');
        strip.type = 'button';
        strip.addEventListener('click', () => {
          pollDraft.options.splice(i, 1);
          drawOptions();
        });
        const row = el('div', 'poll-option-row');
        row.append(f, strip);
        return row;
      }
      return f;
    }));

    if (pollDraft.options.length < limits.options) {
      const add = el('button', 'btn small', 'Add an option');
      add.type = 'button';
      add.addEventListener('click', () => {
        pollDraft.options.push('');
        drawOptions();
      });
      optionFields.append(add);
    }
  };
  drawOptions();

  form.replaceChildren(
    textField('Question', pollDraft.question,
      v => { pollDraft.question = v.slice(0, limits.question); },
      { placeholder: 'Which session do you trade most?' }),
    optionFields,
    pickOne('Post to', 'channel', pollDraft.channelId, v => { pollDraft.channelId = v; }),
    actions(async () => {
      const r = await post('pollcreate', {
        question: pollDraft.question,
        options: pollDraft.options,
        channelId: pollDraft.channelId,
      });
      // Cleared only once it is actually posted — a rejected poll keeps
      // everything you typed. The redraw has to be explicit: post() repaints
      // from the overview it gets back, and that repaint happens before this
      // line, so clearing the draft alone would leave the old text on screen
      // until something else happened to render the tab.
      if (r?.ok) {
        pollDraft.question = '';
        pollDraft.options = ['', ''];
        renderPolls();
      }
    }, { label: 'Post the poll', busyLabel: 'Posting…' }),
  );
}

function relativeTime(ts) {
  const secs = Math.max(0, Math.round((Date.now() - ts) / 1000));
  const steps = [[60, 'second'], [60, 'minute'], [24, 'hour'], [7, 'day'], [4.35, 'week'], [12, 'month']];
  let n = secs, unit = 'second';
  for (const [size, name] of steps) {
    if (n < size) { unit = name; break; }
    n = n / size;
    unit = name;
  }
  const rounded = Math.round(n);
  return `${rounded} ${unit}${rounded === 1 ? '' : 's'} ago`;
}

/**
 * Which panel actions are announced in the mod log.
 *
 * Coins are missing from this list on purpose, and the copy says so — an
 * economy change that leaves no trace is the one thing not worth making
 * optional.
 */
function renderPanelLog() {
  const pl = state.overview?.panelLog;
  const form = $('#form-panellog');
  if (!pl) { form.replaceChildren(); return; }

  const draft = { ...pl.values };
  form.replaceChildren(
    ...pl.categories.map(c => toggle(c.label, draft[c.key] !== false, v => { draft[c.key] = v; })),
    actions(() => post('panellog', draft)),
  );
}

/**
 * The Whop embed link.
 *
 * Whop's app reloads whatever URL is sitting in its own embed field, not
 * anything the page did on its own — so once the WebView it uses has closed,
 * neither a cookie nor localStorage can be counted on to still be there.
 * The URL itself is the only thing that survives, because Whop is the one
 * holding onto it. Baking a long-lived, revocable session into that URL is
 * what keeps the embed signed in across the app being closed and reopened.
 */
function initEmbedLink() {
  const getBtn = $('#embed-link-get');
  if (!getBtn || getBtn.dataset.wired) return;
  getBtn.dataset.wired = '1';

  const revokeBtn = $('#embed-link-revoke');
  const row = $('#embed-link-row');
  const input = $('#embed-link-value');
  const note = $('#embed-link-note');

  const showLink = url => {
    input.value = url;
    row.hidden = false;
    revokeBtn.hidden = false;
    note.hidden = false;
    note.textContent = "Anyone with this link can act on your servers here, the same as your own Discord login — treat it like a password and only paste it into Whop's own embed settings.";
  };

  const mint = async () => {
    const res = await fetch('/api/embed-link', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'x-csrf-token': state.csrf, ...authHeaders() },
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.url) { toast('Could not get the link.', 'bad'); return; }
    showLink(data.url);
  };

  getBtn.addEventListener('click', async () => {
    getBtn.disabled = true;
    getBtn.textContent = 'Getting your link…';
    try { await mint(); }
    finally { getBtn.disabled = false; getBtn.textContent = 'Get my Whop link'; }
  });

  revokeBtn.addEventListener('click', async () => {
    revokeBtn.disabled = true;
    // One request, not a revoke-then-mint pair: minting always invalidates
    // whatever this account had before. A separate revoke first used to mean
    // the only credential an all-Whop admin has — the link itself — could get
    // killed by the very click meant to replace it, one request before the
    // mint that needed it.
    try { await mint(); toast('New link ready — update Whop with it.', 'good'); }
    finally { revokeBtn.disabled = false; }
  });

  $('#embed-link-copy').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(input.value); toast('Copied.', 'good'); }
    catch { input.select(); toast('Select and copy the link manually.'); }
  });
}

/* ── owner console ─────────────────────────────────────────────────────────
   Spans every server the bot is in, so nothing here reads state.guildId or
   state.overview the way every other section does — it asks for its own
   data and keeps its own small cache instead. */

async function ownerWrite(method, path, body) {
  const res = await fetch(path, {
    method, credentials: 'same-origin',
    headers: { 'content-type': 'application/json', 'x-csrf-token': state.csrf, ...authHeaders() },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { toast(WRITE_ERRORS[data.error] || 'That did not save.', 'bad'); return null; }
  return data;
}

async function loadOwnerConsole() {
  try {
    const [data, flags] = await Promise.all([
      get('/api/owner/guilds'),
      get('/api/owner/bot-profile').catch(() => ({ allowGuildNickname: false })),
    ]);
    state.ownerGuilds = data.guilds;
    state.botProfileFlags = flags;
    renderOwnerConsole();
  } catch (err) {
    console.error(err);
    toast('Could not load the owner console.', 'bad');
  }
}

// Fetched once per guild card, the first time it is opened, and kept —
// nothing on this page changes who is a member of a server, so there is
// nothing that should ever invalidate it during one visit.
const ownerMemberCache = new Map();

async function ownerMembersFor(guildId) {
  if (ownerMemberCache.has(guildId)) return ownerMemberCache.get(guildId);
  const data = await get(`/api/owner/guild/${guildId}/members`);
  ownerMemberCache.set(guildId, data.members);
  return data.members;
}

async function ownerRevokeStaff(guildId, userId, name) {
  if (!await askConfirm({
    title: 'Revoke this access grant?',
    message: `${name || 'This account'} loses the panel access you personally granted here. If Discord's own roles let them manage this server anyway, that is unaffected.`,
    confirmLabel: 'Revoke it', danger: true,
  })) return;
  const data = await ownerWrite('DELETE', '/api/owner/staff', { guildId, userId });
  if (!data) return;
  state.ownerGuilds = data.guilds;
  renderOwnerConsole();
  toast('Access revoked.', 'good');
}

async function ownerSignOut(userId, name) {
  if (!await askConfirm({
    title: 'Sign this account out everywhere?',
    message: `${name || 'This account'} is signed out of the panel immediately — every open tab, every saved Whop link. They can sign back in with Discord as long as something still lets them in.`,
    confirmLabel: 'Sign them out', danger: true,
  })) return;
  const data = await ownerWrite('POST', '/api/owner/sign-out', { userId });
  if (!data) return;
  toast('Signed out.', 'good');
}

async function ownerLeaveGuild(guildId, name) {
  if (!await askConfirm({
    title: 'Remove the bot from this server?',
    message: `The bot leaves ${name || 'this server'} immediately. Staff grants for it are cleared. Someone will need to re-invite the bot to bring it back.`,
    confirmLabel: 'Leave server', danger: true,
  })) return;
  const data = await ownerWrite('POST', '/api/owner/leave', { guildId });
  if (!data) return;
  state.ownerGuilds = data.guilds || [];
  if (state.guildId === guildId) {
    state.guildId = null;
    state.overview = null;
  }
  renderOwnerConsole();
  toast(`Left ${name || 'the server'}.`, 'good');
}

/**
 * Fills one guild's member picker, from cache if this card has already been
 * opened once this visit. Split out from renderOwnerConsole because a grant
 * or a revoke re-renders the whole list — every guild's data can have
 * changed, not just the one that was acted on — and the card you were just
 * using has to come back open with its picker already usable, not collapsed
 * back to a cold "Loading members…" you have to click through again.
 */
async function loadOwnerPicker(guildId, picker, placeholder, grantBtn, signOutAnyBtn) {
  try {
    const members = await ownerMembersFor(guildId);
    picker.dataset.loaded = '1';
    if (!members.length) {
      placeholder.textContent = 'No members to pick from.';
      return;
    }
    picker.replaceChildren(...members.map(m => {
      const o = el('option', null, m.name);
      o.value = m.id;
      return o;
    }));
    picker.disabled = false;
    grantBtn.disabled = false;
    signOutAnyBtn.disabled = false;
  } catch (err) {
    console.error(err);
    placeholder.textContent = 'Could not load members.';
  }
}

function renderOwnerConsole() {
  const list = $('#owner-guilds');
  const guilds = state.ownerGuilds || [];
  if (!guilds.length) { list.replaceChildren(el('p', 'muted', 'The bot is not in any server.')); return; }

  const flags = state.botProfileFlags || { allowGuildNickname: false };
  const openIds = new Set([...list.querySelectorAll('details[open]')].map(d => d.dataset.guildId));

  const totalMembers = guilds.reduce((n, g) => n + (g.members || 0), 0);
  const nodes = [];

  // ── Network summary ───────────────────────────────────────────────────
  const summary = el('div', 'gaw');
  summary.append(el('div', 'gaw-top', el('span', 'nm', 'Network')));
  summary.append(el('p', 'hint',
    `${guilds.length} server${guilds.length === 1 ? '' : 's'} · ${num(totalMembers)} members total. Top picker only shows servers you own or were granted. Open any other server from a card below.`));
  nodes.push(summary);

  // ── Global operator controls ──────────────────────────────────────────
  const global = el('div', 'gaw');
  global.append(el('div', 'gaw-top', el('span', 'nm', 'Global controls')));
  global.append(el('p', 'hint',
    'These affect the bot everywhere. Per-server nickname is separate and only changes that server’s display name.'));
  global.append(toggle('Allow server admins to set bot nickname', !!flags.allowGuildNickname, async (v) => {
    const data = await ownerWrite('POST', '/api/owner/bot-profile', { allowGuildNickname: v });
    if (!data) return;
    state.botProfileFlags = data;
    toast(v ? 'Server admins can set nicknames.' : 'Server nicknames locked.', 'good');
  }));
  const resetAv = el('button', 'btn small danger', 'Reset global avatar');
  resetAv.type = 'button';
  resetAv.title = 'Clears the bot avatar back to the Discord application default';
  resetAv.addEventListener('click', async () => {
    if (!await askConfirm({
      title: 'Reset global bot avatar?',
      message: 'This removes the custom avatar for the whole bot (every server). Discord will show the default application icon until you upload a new one. This cannot be limited to one server — Discord only allows one bot avatar.',
      confirmLabel: 'Reset avatar', danger: true,
    })) return;
    const res = await post('bot-profile-global', { avatar: null });
    if (res?.ok || res?.global) toast('Avatar reset to Discord default.', 'good');
  });
  const gAct = el('div', 'actions');
  gAct.append(resetAv);
  global.append(gAct);
  nodes.push(global);

  // ── Per-server cards ──────────────────────────────────────────────────
  for (const g of guilds) {
    const d = el('details', 'item');
    d.dataset.guildId = g.id;
    const sum = el('summary');
    if (g.icon) { const i = el('img'); i.src = g.icon; i.alt = ''; sum.append(i); }
    const onCount = (g.features || []).filter(f => f.enabled).length;
    const featBits = g.features ? `${onCount}/${g.features.length} features on` : '';
    sum.append(
      el('span', 'nm', g.name),
      el('span', 'pr', `${num(g.members)} member${g.members === 1 ? '' : 's'}${featBits ? ' · ' + featBits : ''}`),
    );
    const body = el('div', 'body');

    // Open this server's full panel (even if not in top picker)
    const openBtn = el('button', 'btn primary small', 'Open panel');
    openBtn.type = 'button';
    openBtn.addEventListener('click', async () => {
      if (!state.guilds.some(x => x.id === g.id)) {
        state.guilds = [...state.guilds, { id: g.id, name: g.name, icon: g.icon, members: g.members }];
      }
      await selectGuild(g.id).catch(reportLoadFailure);
      showSection('overview');
      toast(`Opened ${g.name}.`, 'good');
    });
    const leaveBtn = el('button', 'btn small danger', 'Leave server');
    leaveBtn.type = 'button';
    leaveBtn.addEventListener('click', () => ownerLeaveGuild(g.id, g.name));
    const topAct = el('div', 'actions');
    topAct.append(openBtn, leaveBtn);
    body.append(topAct);

    // Feature matrix for this guild
    if (g.features && g.features.length) {
      const featCard = el('div', 'gaw');
      featCard.append(el('div', 'gaw-top', el('span', 'nm', 'Features')));
      featCard.append(el('p', 'hint', 'Turn modules on or off for this server only. Same switches as Settings → Features.'));
      const draft = {};
      for (const f of g.features) draft[f.key] = f.enabled;
      const rows = g.features.map(f => {
        const row = el('div', 'toggle-row');
        row.append(toggle(f.label, draft[f.key], v => { draft[f.key] = v; }));
        return row;
      });
      featCard.append(...rows);
      featCard.append(actions(async () => {
        const data = await ownerWrite('POST', '/api/owner/features', { guildId: g.id, features: draft });
        if (!data) return;
        if (data.guilds) state.ownerGuilds = data.guilds;
        renderOwnerConsole();
        return data;
      }, { label: 'Save features', busyLabel: 'Saving…' }));
      body.append(featCard);
    }

    // Staff grants
    const staffList = el('div', 'rows');
    if (!g.staff.length) {
      staffList.append(el('p', 'muted', 'No staff grants on this server yet.'));
    } else {
      staffList.append(...g.staff.map(s => {
        const card = el('div', 'gaw');
        const top = el('div', 'gaw-top');
        top.append(el('span', 'nm', s.name || 'Former member'));
        card.append(top);
        card.append(el('p', 'hint', `granted access ${relativeTime(s.addedAt)}`));
        const act = el('div', 'actions');
        const signOutBtn = el('button', 'btn small', 'Sign out');
        signOutBtn.type = 'button';
        signOutBtn.addEventListener('click', () => ownerSignOut(s.userId, s.name));
        const revokeBtn = el('button', 'btn small danger', 'Revoke');
        revokeBtn.type = 'button';
        revokeBtn.addEventListener('click', () => ownerRevokeStaff(g.id, s.userId, s.name));
        act.append(signOutBtn, revokeBtn);
        card.append(act);
        return card;
      }));
    }
    body.append(staffList);

    const picker = el('select');
    const placeholder = el('option', null, 'Loading members…');
    placeholder.value = '';
    picker.append(placeholder);
    picker.disabled = true;
    const pickerField = el('label', 'field');
    pickerField.append(el('span', null, 'Member'), picker);

    const act = el('div', 'actions');
    const grantBtn = el('button', 'btn primary small', 'Grant access');
    grantBtn.type = 'button';
    grantBtn.disabled = true;
    grantBtn.addEventListener('click', async () => {
      if (!picker.value) return;
      const data = await ownerWrite('POST', '/api/owner/staff', { guildId: g.id, userId: picker.value });
      if (!data) return;
      state.ownerGuilds = data.guilds;
      renderOwnerConsole();
      toast('Access granted.', 'good');
    });
    const signOutAnyBtn = el('button', 'btn small', 'Sign out this account');
    signOutAnyBtn.type = 'button';
    signOutAnyBtn.disabled = true;
    signOutAnyBtn.addEventListener('click', () => {
      if (!picker.value) return;
      ownerSignOut(picker.value, picker.selectedOptions[0]?.textContent);
    });
    act.append(grantBtn, signOutAnyBtn);
    body.append(pickerField, act);

    d.addEventListener('toggle', () => {
      if (!d.open || picker.dataset.loaded) return;
      loadOwnerPicker(g.id, picker, placeholder, grantBtn, signOutAnyBtn);
    });
    d.append(sum, body);
    if (openIds.has(g.id)) {
      d.open = true;
      loadOwnerPicker(g.id, picker, placeholder, grantBtn, signOutAnyBtn);
    }
    nodes.push(d);
  }

  list.replaceChildren(...nodes);
}

/* ── terms & privacy ──────────────────────────────────────────────────────
   The pages themselves are static and public; all this does is show their
   real, absolute addresses. Relative hrefs would open fine, but the thing
   you actually need from this card is a URL to paste into Discord's
   application listing — and for that it has to be the full one. */

function renderLegalLinks() {
  const card = $('#legal-card');
  if (!card) return;
  // Wired once. This runs on every overview refresh, and a second pass would
  // stack a second click handler on each copy button — two toasts, then three.
  if (card.dataset.wired) return;
  card.dataset.wired = '1';

  const absolute = path => new URL(path, location.origin).href;
  const links = {
    terms:   { url: absolute('/terms'),   urlEl: '#legal-terms-url',   copy: '#legal-copy-terms' },
    privacy: { url: absolute('/privacy'), urlEl: '#legal-privacy-url', copy: '#legal-copy-privacy' },
  };

  for (const { url, urlEl, copy } of Object.values(links)) {
    // Shown without the scheme — the address is there to be recognised and
    // copied, and "https://" at the front of both is the part nobody reads.
    $(urlEl).textContent = url.replace(/^https?:\/\//, '');
    $(urlEl).title = url;
    $(copy).addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(url); toast('Link copied.', 'good'); }
      catch { toast(url); }
    });
  }
}

/* ── feature groups ────────────────────────────────────────────────────────
   Casino, lottery, cards and verification are all "a handful of typed
   settings", so one renderer covers them from the field descriptions the
   server sends. Adding the next one is a table entry in web/features.js. */

function renderGroupForm(target, groupName) {
  const g = state.overview?.features?.groups?.[groupName];
  const form = $(target);
  if (!g) { form.replaceChildren(el('p', 'muted', 'Not available.')); return; }

  const draft = { group: groupName };
  const nodes = g.fields.map(f => {
    const v = g.values[f.key];
    if (f.type === 'channel') return pickOne(f.label, 'channel', v, x => { draft[f.key] = x; });
    if (f.type === 'role') return pickOne(f.label, 'role', v, x => { draft[f.key] = x; });
    if (f.type === 'text') return areaField(f.label, v, x => { draft[f.key] = x; }, 4);
    // Without this a boolean field fell through to the number input below and
    // rendered as an empty box — which is why the lottery pause never showed
    // up as a switch.
    if (f.type === 'bool') return toggle(f.label, !!v, x => { draft[f.key] = x; });
    return textField(`${f.label}${f.min != null ? ` (${f.min}–${f.max})` : ''}`,
      v == null ? '' : String(v), x => { draft[f.key] = Number(x); });
  });
  nodes.push(actions(() => post('feature', draft)));
  form.replaceChildren(...nodes);
}

function renderCoins() {
  const form = $('#form-coins');
  if (!form) return; /* economy UI removed — do not block the rest of the panel */
  const draft = { mode: 'give', amount: 0, userId: null, everyone: false };

  const summary = el('p', 'hint', 'Pick someone, or apply to everyone.');
  const memberField = pickMember('Member', null, v => { draft.userId = v; });

  const everyone = toggle('Apply to every member', false, v => {
    draft.everyone = v;
    memberField.style.display = v ? 'none' : '';
    summary.textContent = v
      ? 'This will change the balance of every non-bot member. Set is unavailable in bulk.'
      : 'Pick someone, or apply to everyone.';
  });

  form.replaceChildren(
    select('What to do', 'give', [
      { value: 'give', label: 'Give coins' },
      { value: 'take', label: 'Take coins' },
      { value: 'set', label: 'Set balance to' },
    ], v => { draft.mode = v; }),
    textField('Amount', '0', v => { draft.amount = Number(v); }),
    memberField,
    everyone,
    summary,
    actions(async () => {
      if (!draft.everyone && !draft.userId) { toast('Pick a member first.', 'bad'); return; }
      const who = draft.everyone ? 'every member' : 'that member';
      if (!await askConfirm({
        title: 'Change balances?',
        message: `${draft.mode === 'set' ? 'Set to' : draft.mode === 'give' ? 'Give' : 'Take'} ${num(draft.amount)} coins — ${who}. Coin changes are always written to your mod log.`,
        confirmLabel: 'Do it', danger: draft.mode !== 'give',
      })) return;
      await post('coins', draft);
    }),
  );
}

/* ── automation ────────────────────────────────────────────────────────── */

function templateOptions() {
  const raw = state.overview?.composer;
  const list = Array.isArray(raw) ? raw : [];
  return list.map(t => ({ value: t.name, label: t.name }));
}

// The browser's offset in minutes east of UTC — getTimezoneOffset() reports the
// opposite sign to how the scheduler stores it, so it is negated here once.
const tzOffset = () => -new Date().getTimezoneOffset();

const freqOptions = () => (state.overview?.features?.frequencies || [])
  .map(f => (typeof f === 'string' ? { value: f, label: f } : f));

const freqLabel = value =>
  (state.overview?.features?.frequencies || []).find(f => f.value === value)?.label || value;

const dayOptions = () => state.overview?.features?.scheduleDays || [];

// How a schedule's cadence reads in the list. A weekly one names its day —
// "Every week (pick a day)" is the wording for the picker, not for a row
// describing a schedule that already has one.
const cadenceLabel = s => {
  if (s.frequency !== 'weekly' || s.dayOfWeek === null || s.dayOfWeek === undefined) return freqLabel(s.frequency);
  return `Every ${dayOptions().find(d => d.value === s.dayOfWeek)?.label || 'week'}`;
};

const fmtTime = ts => (ts ? new Date(ts).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : 'not set');

// What the date means on each cadence, in the words that cadence needs.
//
// A date is one day for a schedule that posts once and a starting point for
// one that repeats, and those are different enough that one label for both
// would be wrong on three of the four. The weekly line says outright which of
// the two day pickers wins, because that is the one place they overlap.
const DATE_LABEL = {
  once:     'Date it posts',
  everyday: 'First post on',
  weekdays: 'First post on',
  weekly:   'First post on',
};
const DATE_NOTE = {
  once:     'It posts once on this day at the time above, then removes itself.',
  everyday: 'It starts on this day, then posts every day at the same time.',
  weekdays: 'It starts on this day, moved to the next weekday if that lands on a weekend.',
  weekly:   'It starts on this day and repeats weekly on that weekday — a date set here wins over the day picker.',
};

function renderSchedules() {
  const list = $('#sched-list');
  const composer = $('#sched-composer');
  const countPill = $('#sched-count');
  const items = state.overview?.features?.schedules || [];
  if (countPill) {
    countPill.textContent = items.length
      ? `${items.length} active`
      : 'none yet';
  }

  const nodes = [];
  if (!items.length) {
    const empty = el('div', 'empty-desk');
    empty.append(
      el('p', 'muted', 'No clocks running yet.'),
      el('p', 'hint', 'Compose one below — template, channel, cadence, time. The bot posts for you.'),
    );
    nodes.push(empty);
  }

  for (const s of items) {
    const draft = {
      id: s.id,
      embedName: s.embedName,
      channelId: s.channelId,
      frequency: s.frequency,
      time: s.time || '',
      dayOfWeek: s.dayOfWeek,
      date: s.date || '',
      mention: s.mention || null,
      enabled: s.enabled !== false,
    };
    const d = el('details', 'item');
    const sum = el('summary');
    const on = s.enabled !== false;
    sum.append(
      el('span', `bstyle ${on ? 'success' : 'secondary'}`, on ? 'live' : 'paused'),
      el('span', 'nm', s.embedName || 'Untitled'),
      el('span', 'pr', cadenceLabel(s)),
    );
    const meta = el('p', 'hint');
    meta.textContent = [
      s.channelName ? `#${s.channelName}` : (s.channelId ? `channel ${s.channelId}` : 'no channel'),
      s.nextRun ? `next ${fmtTime(s.nextRun)}` : null,
      s.time ? `at ${s.time}` : null,
    ].filter(Boolean).join(' · ');
    sum.append(meta);

    const body = el('div', 'body');
    const dayPick = select('Weekday', draft.dayOfWeek, dayOptions(), v => { draft.dayOfWeek = v === '' ? null : Number(v); }, { blank: 'Same as first-post date' });
    dayPick.style.display = draft.frequency === 'weekly' ? '' : 'none';
    const datePick = dateField(DATE_LABEL[draft.frequency] || 'Date', draft.date, v => { draft.date = v; }, { note: DATE_NOTE[draft.frequency] || '' });

    const syncCadence = f => {
      dayPick.style.display = f === 'weekly' ? '' : 'none';
      datePick.retitle(DATE_LABEL[f] || 'Date', DATE_NOTE[f] || '');
    };

    body.append(
      select('Message to post', draft.embedName, templateOptions(), v => { draft.embedName = v; }, { blank: 'Pick a message' }),
      pickOne('Channel', 'channel', draft.channelId, v => { draft.channelId = v; }, { blank: 'Pick a channel' }),
      select('How often', draft.frequency, freqOptions(), v => { draft.frequency = v; syncCadence(v); }),
      dayPick,
      textField('Time', draft.time, v => { draft.time = v; }, { placeholder: '09:30' }),
      datePick,
      mentionPicker('Ping with the post', draft.mention, v => { draft.mention = v; }),
      toggle('Schedule enabled', on, v => { draft.enabled = v; }),
    );

    const act = el('div', 'actions');
    const save = el('button', 'btn primary small', 'Save schedule');
    save.type = 'button';
    save.addEventListener('click', () => post('schedule', { ...draft, offsetMinutes: tzOffset() }));
    const del = el('button', 'btn small danger', 'Delete');
    del.type = 'button';
    del.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'Delete this schedule?',
        message: `“${s.embedName}” will stop posting on its clock.`,
        confirmLabel: 'Delete it', danger: true,
      })) return;
      await post('schedule', { id: s.id, remove: true });
    });
    act.append(save, del);
    body.append(act);
    d.append(sum, body);
    nodes.push(d);
  }
  list.replaceChildren(...nodes);

  // Composer — skip rebuild while the user is typing in it
  if (!composer) return;
  if (composer.contains(document.activeElement)) return;

  const nb = {
    embedName: '', channelId: '', frequency: 'everyday',
    time: '09:30', dayOfWeek: null, date: '', mention: null,
  };
  const wrap = el('div', 'desk-composer');
  wrap.append(el('h3', null, 'New schedule'));
  wrap.append(el('p', 'hint', `Times use your local zone (UTC${tzOffset() >= 0 ? '+' : ''}${(tzOffset() / 60).toFixed(2).replace(/\.00$/, '')}). Pick a Studio message, where it posts, how often, and a clock time.`));

  const newDayPick = select('Weekday', '', dayOptions(), v => { nb.dayOfWeek = v === '' ? null : Number(v); }, { blank: 'Same as first-post date' });
  newDayPick.style.display = 'none';
  const newDatePick = dateField(DATE_LABEL.everyday, '', v => { nb.date = v; }, { note: DATE_NOTE.everyday });
  const syncNew = f => {
    newDayPick.style.display = f === 'weekly' ? '' : 'none';
    newDatePick.retitle(DATE_LABEL[f] || 'Date', DATE_NOTE[f] || '');
  };

  // Cadence chips
  const cadence = el('div', 'field');
  cadence.append(el('label', null, 'How often'));
  const chipRow = el('div', 'chipset cadence-chips');
  const freqs = freqOptions().length ? freqOptions() : [
    { value: 'once', label: 'Once' },
    { value: 'everyday', label: 'Every day' },
    { value: 'weekdays', label: 'Weekdays' },
    { value: 'weekly', label: 'Weekly' },
  ];
  const paintChips = () => {
    chipRow.replaceChildren();
    for (const f of freqs) {
      const b = el('button', 'chip-toggle' + (nb.frequency === f.value ? ' on' : ''), f.label);
      b.type = 'button';
      b.addEventListener('click', () => { nb.frequency = f.value; syncNew(f.value); paintChips(); });
      chipRow.append(b);
    }
  };
  paintChips();
  cadence.append(chipRow);

  // Time presets
  const timeField = textField('Time', nb.time, v => { nb.time = v; }, { placeholder: '09:30 or 2h from now' });
  const presets = el('div', 'time-presets');
  for (const [label, val] of [['Morning 9:30', '09:30'], ['Noon', '12:00'], ['Evening 18:00', '18:00'], ['In 1 hour', '1h'], ['In 2 hours', '2h']]) {
    const b = el('button', 'chip-toggle', label);
    b.type = 'button';
    b.addEventListener('click', () => {
      nb.time = val;
      const input = timeField.querySelector('input');
      if (input) { input.value = val; input.dispatchEvent(new Event('input', { bubbles: true })); }
    });
    presets.append(b);
  }
  timeField.append(presets);

  wrap.append(
    select('Message to post', '', templateOptions(), v => { nb.embedName = v; }, { blank: 'Pick a Studio template' }),
    pickOne('Channel', 'channel', '', v => { nb.channelId = v; }, { blank: 'Where it posts' }),
    cadence,
    newDayPick,
    timeField,
    newDatePick,
    mentionPicker('Optional ping', null, v => { nb.mention = v; }),
    actions(() => post('schedulenew', { ...nb, offsetMinutes: tzOffset() }), { label: 'Create schedule' }),
  );
  composer.replaceChildren(wrap);
}

function renderAutoreplies() {
  const list = $('#reply-list');
  const composer = $('#reply-composer');
  const countPill = $('#reply-count');
  const items = state.overview?.features?.autoreplies || [];
  const enabledN = items.filter(r => r.enabled).length;
  if (countPill) {
    countPill.textContent = items.length
      ? `${enabledN}/${items.length} on`
      : 'none yet';
  }

  const nodes = [];
  if (!items.length) {
    const empty = el('div', 'empty-desk');
    empty.append(
      el('p', 'muted', 'No phrase watchers yet.'),
      el('p', 'hint', 'Add a trigger below and pick the template the bot should post back.'),
    );
    nodes.push(empty);
  }

  for (const r of items) {
    const draft = {
      key: r.key, trigger: r.trigger, embedName: r.embedName,
      exact: r.exact, cooldown: r.cooldown, enabled: r.enabled,
    };
    const d = el('details', 'item');
    const sum = el('summary');
    sum.append(
      el('span', `bstyle ${r.enabled ? 'success' : 'secondary'}`, r.enabled ? 'on' : 'off'),
      el('span', 'nm', r.trigger),
      el('span', 'pr', r.embedName || '—'),
    );
    const body = el('div', 'body');
    body.append(
      textField('Trigger phrase', r.trigger, v => { draft.trigger = v; }),
      select('Reply with', r.embedName, templateOptions(), v => { draft.embedName = v; }, { blank: 'Pick a template' }),
      textField('Cooldown (seconds)', String(r.cooldown ?? 5), v => { draft.cooldown = Number(v); }),
      toggle('Whole message must match exactly', !!r.exact, v => { draft.exact = v; }),
      toggle('Enabled', !!r.enabled, v => { draft.enabled = v; }),
    );
    const act = el('div', 'actions');
    const save = el('button', 'btn primary small', 'Save reply');
    save.type = 'button';
    save.addEventListener('click', () => post('autoreply', draft));
    const del = el('button', 'btn small danger', 'Remove');
    del.type = 'button';
    del.addEventListener('click', async () => {
      if (!await askConfirm({
        title: 'Remove this auto-reply?',
        message: `The bot will stop replying to “${r.trigger}”.`,
        confirmLabel: 'Remove it', danger: true,
      })) return;
      await post('autoreply', { key: r.key, remove: true });
    });
    act.append(save, del);
    body.append(act);
    d.append(sum, body);
    nodes.push(d);
  }
  list.replaceChildren(...nodes);

  if (!composer) return;
  if (composer.contains(document.activeElement)) return;

  const nb = { key: '', trigger: '', embedName: '', cooldown: 5, exact: false, enabled: true };
  const wrap = el('div', 'desk-composer');
  wrap.append(el('h3', null, 'New auto-reply'));
  wrap.append(el('p', 'hint', 'When a member’s message matches the trigger, the bot posts a Studio template. Use exact match for command-style phrases; leave it off for keywords inside longer messages.'));

  const cd = el('div', 'field');
  cd.append(el('label', null, 'Cooldown'));
  const cdRow = el('div', 'chipset');
  for (const sec of [0, 5, 15, 30, 60, 300]) {
    const label = sec === 0 ? 'None' : sec < 60 ? `${sec}s` : `${sec / 60}m`;
    const b = el('button', 'chip-toggle' + (nb.cooldown === sec ? ' on' : ''), label);
    b.type = 'button';
    b.addEventListener('click', () => {
      nb.cooldown = sec;
      for (const x of cdRow.children) x.classList.toggle('on', x === b);
    });
    cdRow.append(b);
  }
  cd.append(cdRow);

  wrap.append(
    textField('Trigger phrase', '', v => { nb.key = v.toLowerCase().trim(); nb.trigger = v; }, { placeholder: 'e.g. rules, price, link' }),
    select('Reply with', '', templateOptions(), v => { nb.embedName = v; }, { blank: 'Pick a Studio template' }),
    cd,
    toggle('Whole message must match exactly', false, v => { nb.exact = v; }),
    toggle('Enabled immediately', true, v => { nb.enabled = v; }),
    actions(() => post('autoreply', nb), { label: 'Create auto-reply' }),
  );
  composer.replaceChildren(wrap);
}

/* ── engagement ────────────────────────────────────────────────────────── */


/* ── trading rank (engagement) ─────────────────────────────────────────── */

function rankTrading() {
  return state.overview?.features?.levels?.trading || null;
}

function channelOptsFromTrading(t) {
  return (t?.channelOpts || []).map(c => ({
    value: c.id,
    label: (c.kind === 'forum' ? 'Forum · ' : '#') + c.name,
    kind: c.kind || 'text',
  }));
}

function multiSelect(label, values, opts, onChange) {
  const box = el('div', 'field');
  box.append(el('label', null, label));
  const sel = el('select');
  sel.multiple = true;
  sel.size = Math.min(5, Math.max(3, opts.length || 3));
  const chosen = new Set(values || []);
  for (const o of opts) {
    const opt = document.createElement('option');
    opt.value = o.value;
    opt.textContent = o.label;
    if (chosen.has(o.value)) opt.selected = true;
    sel.append(opt);
  }
  const hint = el('p', 'hint', chosen.size ? [...chosen].map(id => (opts.find(o => o.value === id) || {}).label || id).join(' · ') : 'None selected');
  sel.addEventListener('change', () => {
    const ids = [...sel.selectedOptions].map(o => o.value);
    onChange(ids);
    hint.textContent = ids.length
      ? ids.map(id => (opts.find(o => o.value === id) || {}).label || id).join(' · ')
      : 'None selected';
  });
  box.append(sel, hint);
  return box;
}

/** One setup card + live board — meaningful controls only. */
function renderEngagement() {
  const setup = $('#rank-setup');
  const board = $('#rank-board');
  if (!setup && !board) return;

  const t = rankTrading();
  const lv = state.overview?.features?.levels;

  if (setup) {
    if (!t && !lv) {
      setup.replaceChildren(el('p', 'muted', 'Open a server to configure rank.'));
    } else {
      const draft = {
        mode: t?.mode || 'trading',
        dailyXpCap: t?.dailyXpCap ?? 400,
        earnChannels: [...(t?.sources?.earnChannels || [])],
        forumChannels: [...(t?.sources?.forumChannels || [])],
        tradeShareChannels: [...(t?.sources?.tradeShareChannels || [])],
      };
      const opts = channelOptsFromTrading(t);
      const forums = opts.filter(o => o.kind === 'forum');
      const texts = opts.filter(o => o.kind !== 'forum');

      const nodes = [];

      // Mode segmented
      const modeBox = el('div', 'field');
      modeBox.append(el('label', null, 'Mode'));
      const modeRow = el('div', 'rank-mode-row');
      for (const [v, lab] of [['trading', 'Trading signals'], ['legacy', 'Legacy chat XP']]) {
        const b = el('button', 'btn small' + (draft.mode === v ? ' primary' : ''), lab);
        b.type = 'button';
        b.addEventListener('click', () => {
          draft.mode = v;
          modeRow.querySelectorAll('button').forEach(x => x.classList.toggle('primary', x === b));
        });
        modeRow.append(b);
      }
      modeBox.append(modeRow);
      modeBox.append(el('p', 'hint', draft.mode === 'trading'
        ? 'Only charts, journal, and trade shares earn XP.'
        : 'Any message can earn XP (old behaviour).'));
      nodes.push(modeBox);

      if (texts.length) nodes.push(multiSelect('Chart / setup channels', draft.earnChannels, texts, ids => { draft.earnChannels = ids; }));
      else nodes.push(el('p', 'hint', 'No text channels loaded yet.'));

      if (forums.length) nodes.push(multiSelect('Journal forums (owner gets XP)', draft.forumChannels, forums, ids => { draft.forumChannels = ids; }));
      nodes.push(multiSelect('QuantLab trade-share channels', draft.tradeShareChannels, texts, ids => { draft.tradeShareChannels = ids; }));

      nodes.push(textField('Daily XP cap (per member)', String(draft.dailyXpCap), v => {
        draft.dailyXpCap = Number(v) || 0;
      }));

      // Live signal legend
      const legend = el('div', 'rank-legend');
      legend.append(el('div', 'rank-legend-title', 'What pays XP'));
      const signals = t?.signals || {
        chart: { min: 25, max: 40 },
        setup: { min: 20, max: 35 },
        journal: { min: 35, max: 55 },
        share: { min: 30, max: 50 },
      };
      for (const [k, lab] of [['chart', 'Chart image'], ['setup', 'Setup / levels'], ['journal', 'Journal post'], ['share', 'Trade share']]) {
        const s = signals[k] || {};
        legend.append(el('div', 'rank-legend-row', `${lab}  ·  ${s.min ?? '—'}–${s.max ?? '—'} XP`));
      }
      nodes.push(legend);

      nodes.push(actions(async () => {
        const out = await post('leveltrading', {
          mode: draft.mode,
          dailyXpCap: draft.dailyXpCap,
          earnChannels: draft.earnChannels,
          forumChannels: draft.forumChannels,
          tradeShareChannels: draft.tradeShareChannels,
        });
        if (!out) return null;
        if (state.overview?.features?.levels) {
          state.overview.features.levels.trading = out.trading || state.overview.features.levels.trading;
        }
        renderEngagement();
        return out;
      }));
      setup.replaceChildren(...nodes);
    }
  }

  if (board) {
    const tag = $('#rank-board-tag');
    const list = t?.leaderboard || lv?.leaderboard || [];
    if (tag) tag.textContent = list.length ? `${list.length} ranked` : 'live';
    if (!list.length) {
      board.replaceChildren(el('p', 'muted', 'No rank XP yet — post a chart or journal entry in a tracked channel.'));
    } else {
      const table = el('div', 'rank-board-list');
      list.slice(0, 15).forEach((u, i) => {
        const row = el('div', 'rank-board-row');
        const left = el('div', 'rank-board-left');
        left.append(el('span', 'rank-board-pos', String(i + 1)));
        left.append(el('span', 'rank-board-name', u.name || u.id));
        left.append(el('span', 'rank-board-lvl', `Lv ${u.level ?? 0}`));
        row.append(left);
        row.append(el('span', 'rank-board-xp', `${num(u.totalXp || u.xp || 0)} XP`));
        table.append(row);
      });
      board.replaceChildren(table);
    }
  }
}

function renderLevels() {
  const lv = state.overview?.features?.levels;
  const form = $('#form-levels');
  if (!lv) { form.replaceChildren(el('p', 'muted', 'Not available.')); return; }

  // Live copy of what is on screen, so the readout below can be recalculated
  // as you type rather than only after a save.
  const shown = Object.fromEntries(lv.fields.map(f => [f.key, lv.values[f.key] ?? f.fallback ?? '']));

  const rate = el('p', 'hint');
  const syncRate = () => { rate.textContent = describeXpRate(shown); };

  const draft = {};
  const nodes = [];
  for (const f of lv.fields) {
    // A duration keeps its 20s/1m form all the way through — Number() on it
    // would send NaN, which is how a text-shaped field breaks a numeric form.
    const isDuration = f.type === 'duration';
    const label = isDuration ? f.label : `${f.label} (${f.min}–${f.max})`;
    nodes.push(textField(label, String(shown[f.key]), v => {
      shown[f.key] = isDuration ? v : Number(v);
      draft[f.key] = shown[f.key];
      syncRate();
    }, isDuration ? { placeholder: '20s, 1m, 5m — or 0' } : {}));
    if (f.hint) nodes.push(el('p', 'hint', f.hint));
  }

  syncRate();
  nodes.push(rate);
  nodes.push(el('p', 'hint', `${num(lv.tracked)} members are being tracked.`));
  nodes.push(actions(() => post('levels', draft)));
  form.replaceChildren(...nodes);
}

/**
 * What the level settings add up to, in a sentence.
 *
 * Four numbers that each make sense alone tell you nothing together — whether
 * 25 XP on a 20-second cooldown is generous depends on the base XP and the
 * curve, and nobody does that arithmetic in their head. Recomputed as the
 * fields change, so the effect of a change is visible before it is saved.
 */
function describeXpRate(v) {
  const ms = parseDurationMs(String(v.cooldownMs ?? '')) ?? (/^0/.test(String(v.cooldownMs)) ? 0 : null);
  const maxXp = Number(v.xpMax) || 0;
  const avgXp = ((Number(v.xpMin) || 0) + maxXp) / 2;
  const baseXp = Number(v.baseXp) || 0;
  if (ms === null || !avgXp || !baseXp) return 'Fill the fields above to see what they add up to.';

  const msgs = Math.max(1, Math.ceil(baseXp / avgXp));
  if (ms === 0) return `No cooldown — every message pays. About ${msgs} message${msgs === 1 ? '' : 's'} to reach level 2.`;

  const perHour = Math.floor(3600000 / ms) * maxXp;
  return `At most ${num(perHour)} XP/hour · about ${msgs} earning message${msgs === 1 ? '' : 's'} to reach level 2 (${shortDuration(msgs * ms)} at full speed).`;
}

/**
 * Short, readable span. The page's own duration() floors to whole minutes,
 * which turns every XP cooldown into "0m" — these are seconds-to-minutes, not
 * the hours-to-days it was written for.
 */
function shortDuration(ms) {
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s`;
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), rest = s % 60;
  if (h) return m ? `${h}h ${m}m` : `${h}h`;
  return rest ? `${m}m ${rest}s` : `${m}m`;
}

function renderLevelRoles() {
  const lv = state.overview?.features?.levels;
  const list = $('#levelroles');
  const nodes = [];

  if (!lv?.roles?.length) nodes.push(el('p', 'muted', 'No level rewards set.'));
  for (const r of (lv?.roles || [])) {
    const line = el('div', 'post-row');
    line.append(el('span', 'k', `Level ${r.level} → ${r.roleName || 'role deleted'}`));
    const del = el('button', 'btn small danger', 'Remove');
    del.type = 'button';
    del.addEventListener('click', () => post('levelrole', { level: r.level, remove: true }));
    line.append(del);
    nodes.push(line);
  }

  const add = el('details', 'item');
  const sum = el('summary');
  sum.append(el('span', 'nm', '+ Reward a role at a level'));
  const nb = { level: 5, roleId: null };
  const body = el('div', 'body');
  body.append(
    textField('Level', '5', v => { nb.level = Number(v); }),
    pickOne('Role to grant', 'role', '', v => { nb.roleId = v; }, { blank: 'Pick a role' }),
    actions(() => post('levelrole', nb)),
  );
  add.append(sum, body);
  nodes.push(add);

  list.replaceChildren(...nodes);
}

/**
 * Level badges — same shape as level roles above, one row per configured
 * level, plus an "add" form. The catalogue (state.overview.features.levels
 * .badgeCatalog) is the fixed set of pixel-art badges the bot can draw;
 * this screen only decides which level unlocks which one.
 */
function renderLevelBadges() {
  const lv = state.overview?.features?.levels;
  const list = $('#levelbadges');
  if (!list) return;
  const nodes = [];

  if (!lv?.badges?.length) nodes.push(el('p', 'muted', 'No level badges set.'));
  for (const b of (lv?.badges || [])) {
    const line = el('div', 'post-row');
    line.append(el('span', 'k', `Level ${b.level} → ${b.badgeLabel}`));
    const del = el('button', 'btn small danger', 'Remove');
    del.type = 'button';
    del.addEventListener('click', () => post('levelbadge', { level: b.level, remove: true }));
    line.append(del);
    nodes.push(line);
  }

  const catalog = lv?.badgeCatalog || [];
  const add = el('details', 'item');
  const sum = el('summary');
  sum.append(el('span', 'nm', '+ Award a badge at a level'));
  const nb = { level: 5, badgeId: catalog[0]?.id || null };
  const body = el('div', 'body');
  body.append(
    textField('Level', '5', v => { nb.level = Number(v); }),
    select('Badge to grant', nb.badgeId || '', catalog.map(c => ({ value: c.id, label: `${c.emoji} ${c.label}` })),
      v => { nb.badgeId = v; }),
    actions(() => post('levelbadge', nb)),
  );
  add.append(sum, body);
  nodes.push(add);

  list.replaceChildren(...nodes);
}

/** A member's progress can't be recovered once cleared, so this is the one
 * place in Engagement that goes through askConfirm rather than a plain save
 * button. */
function renderLevelsReset() {
  const box = $('#levels-reset');
  if (!box) return;
  const lv = state.overview?.features?.levels;
  const btn = el('button', 'btn danger', 'Reset all levels');
  btn.type = 'button';
  btn.addEventListener('click', async () => {
    if (!await askConfirm({
      title: 'Reset every member\u2019s level?',
      message: `${num(lv?.tracked || 0)} tracked member${lv?.tracked === 1 ? '' : 's'} will be put back to level 1 with 0 XP. Level reward roles and level badges stay configured. This cannot be undone.`,
      confirmLabel: 'Reset levels', danger: true,
    })) return;
    await post('resetlevels', {});
  });
  box.replaceChildren(btn);
}

/* ── studio ────────────────────────────────────────────────────────────── */

let previewTimer = null;
let previewSeq = 0;

function requestPreview() {
  clearTimeout(previewTimer);
  $('#stage-busy').hidden = false;
  // Debounced, because each distinct render blocks the same thread that answers
  // Discord. Typing should cost one render when you stop, not one per key.
  previewTimer = setTimeout(loadPreview, 320);
}

async function loadPreview() {
  const seq = ++previewSeq;
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(state.copy)) if (v) params.set(k, v);
  // Lets an empty form fall back to whatever this guild has saved, rather than
  // to the factory defaults the embed is no longer sending.
  if (state.guildId) params.set('g', state.guildId);
  const url = `/api/preview/${state.tpl.key}?${params}`;

  try {
    const res = await fetch(url, { credentials: 'same-origin', headers: authHeaders() });
    if (res.status === 429) {
      // The server is pacing renders. Wait exactly as long as it asked.
      const { retryAfterMs } = await res.json();
      previewTimer = setTimeout(loadPreview, (retryAfterMs || 250) + 40);
      return;
    }
    if (!res.ok) throw new Error(String(res.status));
    const blob = await res.blob();
    if (seq !== previewSeq) return; // a newer edit already won
    const objectUrl = URL.createObjectURL(blob);
    const img = $('#preview');
    const previous = img.src;
    img.src = objectUrl;
    if (previous.startsWith('blob:')) URL.revokeObjectURL(previous);
    $('#preview-download').href = objectUrl;
    $('#preview-download').download = `${state.tpl.key}_banner.png`;
    $('#preview-status').textContent = res.headers.get('x-render-cached') === 'true' ? 'Live preview · cached' : 'Live preview';
  } catch {
    $('#preview-status').textContent = 'Preview failed — try editing again.';
  } finally {
    if (seq === previewSeq) $('#stage-busy').hidden = true;
  }
}

function renderStudioFields() {
  const wrap = $('#tpl-fields');
  wrap.replaceChildren(...Object.keys(state.tpl.defaults).map(field => {
    const limit = state.tpl.limits[field];
    const l = el('label', 'field');
    const head = el('div', 'field-head');
    const count = el('span', 'count');
    head.append(el('span', null, field[0].toUpperCase() + field.slice(1)), count);
    l.append(head);

    const long = field === 'tagline';
    const input = el(long ? 'textarea' : 'input');
    if (!long) input.type = 'text';
    input.maxLength = limit;
    input.value = state.copy[field] ?? state.tpl.defaults[field];
    const sync = () => { count.textContent = `${input.value.length}/${limit}`; };
    sync();
    input.addEventListener('input', () => {
      // Upper-cased live, because the pixel font has no lower case — the field
      // should say what the image will say.
      const caret = input.selectionStart;
      input.value = input.value.toUpperCase();
      input.setSelectionRange(caret, caret);
      state.copy[field] = input.value;
      sync();
      markStudioDirty();
      requestPreview();
    });
    l.append(input);
    return l;
  }));
}

/**
 * What is currently saved for a banner, filled in with the defaults.
 *
 * Studio shows the effective wording — the words the embed would actually
 * send — rather than the raw saved record, which only holds the fields that
 * differ. Otherwise a banner with one customised line would open with the
 * other three blank.
 */
function savedCopyFor(key) {
  const saved = state.overview?.banners?.[key] || {};
  const tpl = state.templates.find(t => t.key === key);
  return { ...(tpl?.defaults || {}), ...saved };
}

/** Whether the form differs from what is saved, which is what the embed sends. */
function studioDirty() {
  if (!state.tpl) return false;
  const saved = savedCopyFor(state.tpl.key);
  return Object.keys(state.tpl.defaults).some(f => (state.copy[f] ?? '') !== (saved[f] ?? ''));
}

function markStudioDirty() {
  const dirty = studioDirty();
  $('#tpl-dirty').hidden = !dirty;
  $('#tpl-save').disabled = !dirty;
  $('#tpl-revert').disabled = !dirty;
}

function selectTemplate(key, copy) {
  state.tpl = state.templates.find(t => t.key === key) || state.templates[0];
  state.copy = copy ? { ...copy } : savedCopyFor(state.tpl.key);
  renderStudioFields();
  markStudioDirty();
  loadPreview();
}

async function initStudio() {
  const { templates } = await get('/api/templates');
  state.templates = templates;
  const select = $('#tpl-select');
  select.replaceChildren(...templates.map(t => {
    const o = el('option', null, t.label);
    o.value = t.key;
    return o;
  }));
  select.addEventListener('change', () => selectTemplate(select.value));

  // Revert goes back to what is saved; reset goes back to the factory wording
  // and needs saving to take effect, same as any other edit.
  $('#tpl-revert').addEventListener('click', () => selectTemplate(state.tpl.key));
  $('#tpl-reset').addEventListener('click', () => selectTemplate(state.tpl.key, state.tpl.defaults));

  $('#tpl-save').addEventListener('click', async () => {
    const btn = $('#tpl-save');
    btn.disabled = true;
    const previous = btn.textContent;
    btn.textContent = 'Saving…';
    try {
      // Only the lines that differ from the defaults are sent, so a banner
      // left alone stays on the default render the cache already holds.
      const copy = {};
      for (const [f, v] of Object.entries(state.copy)) {
        if (v && v !== state.tpl.defaults[f]) copy[f] = v;
      }
      const out = await post('banner', { template: state.tpl.key, copy });
      if (out && state.overview) {
        state.overview.banners = { ...(state.overview.banners || {}), [state.tpl.key]: out.copy || {} };
      }
    } finally {
      btn.textContent = previous;
      markStudioDirty();
    }
  });

  selectTemplate(templates[0].key);
}

/* ── the pill ──────────────────────────────────────────────────────────────
   Two small things the bar now has room for: how far down the page you are,
   and which section you are in once the nav has scrolled past. */

const SECTION_NAMES = {
  overview: 'Overview', composer: 'Composer', studio: 'Studio',
  casino: 'Casino', tickets: 'Tickets',
  giveaways: 'Giveaways', feeds: 'Feeds', economy: 'Economy',
  automation: 'Automation', engagement: 'Engagement',
  moderation: 'Moderation', settings: 'Settings',
};

function paintBar() {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  const y = window.scrollY;
  document.documentElement.style.setProperty('--scroll', max > 8 ? `${Math.min(100, (y / max) * 100).toFixed(1)}%` : '0%');
  // 64px is roughly where the section nav leaves the screen, so the label
  // arrives exactly as the thing it replaces goes away.
  root.dataset.scrolled = y > 64 ? '1' : '0';
  $('#here').textContent = SECTION_NAMES[root.dataset.section] || '';
}

function watchScroll() {
  let queued = false;
  const onScroll = () => {
    if (queued) return;
    queued = true;
    // Coalesced into a frame — a scroll handler that writes styles directly is
    // the classic way to make a phone feel sluggish.
    requestAnimationFrame(() => { queued = false; paintBar(); });
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll, { passive: true });
  paintBar();
}

/**
 * Tapping outside a field closes the keyboard.
 *
 * Browsers only blur an input when you tap something else focusable, so on a
 * phone the keyboard stays up over half the screen while you try to read what
 * you just typed. Tapping any non-interactive part of the page now dismisses
 * it, which is what every native app does.
 */
function dismissKeyboardOnOutsideTap() {
  const isControl = node => node instanceof Element
    && node.closest('input, textarea, select, button, a, label, [contenteditable]');

  document.addEventListener('pointerdown', event => {
    const active = document.activeElement;
    if (!active || !/^(INPUT|TEXTAREA)$/.test(active.tagName)) return;
    if (isControl(event.target)) return;
    active.blur();
  }, { passive: true });
}

/* ── live ──────────────────────────────────────────────────────────────────
   The panel used to be a snapshot: it read everything once and then showed
   you that until you reloaded. Someone entering a giveaway, a report coming
   in, a watched account starting to fail — none of it appeared without a
   refresh, so the number on screen was only true at the moment you last
   looked at it.

   The server pushes the whole overview whenever it changes. What arrives is
   applied to the parts of the page that only ever display things; forms are
   never touched, because the one thing worse than a stale number is a
   half-typed one disappearing. */

let live = null;
let liveMissed = false;

/** Is the person in the middle of typing something, or has a native menu open? */
let uiBusy = false;
let uiBusyTimer = null;
function markUiBusy() {
  uiBusy = true;
  if (uiBusyTimer) clearTimeout(uiBusyTimer);
  uiBusyTimer = null;
}
function clearUiBusySoon() {
  if (uiBusyTimer) clearTimeout(uiBusyTimer);
  uiBusyTimer = setTimeout(() => {
    uiBusy = false;
    uiBusyTimer = null;
    if (typeof liveMissed !== 'undefined' && liveMissed && typeof renderLive === 'function') {
      try { renderLive(); } catch (_) {}
    }
  }, 200);
}
document.addEventListener('mousedown', (e) => {
  const t = e.target;
  if (!t) return;
  if (t.tagName === 'SELECT' || (t.closest && t.closest('select'))) markUiBusy();
}, true);
document.addEventListener('focusin', (e) => {
  if (e.target && e.target.tagName === 'SELECT') markUiBusy();
}, true);
document.addEventListener('focusout', (e) => {
  if (e.target && e.target.tagName === 'SELECT') clearUiBusySoon();
}, true);
document.addEventListener('change', (e) => {
  if (e.target && e.target.tagName === 'SELECT') clearUiBusySoon();
}, true);
document.addEventListener('toggle', (e) => {
  if (e.target && e.target.tagName === 'DETAILS') {
    if (e.target.open) markUiBusy();
    else clearUiBusySoon();
  }
}, true);

function isEditing() {
  if (uiBusy) return true;
  const a = document.activeElement;
  if (!a) return false;
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return true;
  if (a.isContentEditable === true) return true;
  if (document.querySelector('select:focus, details[open] summary:focus')) return true;
  return false;
}

/**
 * Repaints what the stream can safely repaint.
 *
 * Lists and counters only. The composer, the appearance editor, Studio, the
 * economy dials and every settings form are left exactly as they are — a
 * repaint would throw away whatever was in them.
 *
 * Social is a special case: its account list is read-only once collapsed, but
 * an open card is a form, so it is only redrawn when none is open.
 */
const _liveSig = Object.create(null);
function _sigChanged(key, value) {
  let next;
  try { next = JSON.stringify(value); } catch (_) { next = String(value); }
  if (_liveSig[key] === next) return false;
  _liveSig[key] = next;
  return true;
}

function renderLive() {
  if (!state.overview) return;
  if (isEditing() || sheetIsOpen()) { liveMissed = true; return; }
  liveMissed = false;

  renderOverviewCards();
  if (!root.dataset.entered) revealOverviewChrome();

  const o = state.overview;
  if (_sigChanged('giveaways', o.giveaways)) renderGiveaways();
  if (_sigChanged('lottery', o.lottery)) renderLottery();
  if (_sigChanged('mod', o.mod)) renderModeration();
  if (_sigChanged('links', o.linkRequests || o.links)) renderLinkRequests();
  if (_sigChanged('tickets', o.tickets)) renderTickets();
  /* Social removed from panel */
  if (root.dataset.section === 'automation') {
    if (_sigChanged('schedules', o.features?.schedules)) renderSchedules();
    if (_sigChanged('autoreplies', o.features?.autoreplies)) renderAutoreplies();
  }
  startTicking();
}

function sheetIsOpen() {
  const sheet = $('#sheet');
  return !!sheet && !sheet.hidden;
}

function stopLive() {
  if (live) { live.close(); live = null; }
}

/**
 * Opens the stream for the guild being looked at.
 *
 * EventSource reconnects by itself, so there is no retry loop here — the only
 * thing worth doing on an error is saying so, and letting it get on with it.
 */
function startLive() {
  stopLive();
  if (typeof EventSource !== 'function' || !state.guildId) return;

  // The token rides on the query string because EventSource cannot set a
  // header, and inside somebody else's iframe the cookie is blocked outright.
  // The server checks it exactly as it checks a header.
  const qs = state.token ? `?t=${encodeURIComponent(state.token)}` : '';
  try {
    live = new EventSource(`/api/guild/${state.guildId}/stream${qs}`, { withCredentials: true });
  } catch {
    return;
  }

  live.addEventListener('overview', ev => {
    let next;
    try { next = JSON.parse(ev.data); } catch { return; }
    // Guard against a payload that arrives after the guild has been switched.
    if (!next?.guild?.id || next.guild.id !== state.guildId) return;
    state.overview = next;
    renderLive();
  });
}

// A field losing focus is the moment a deferred repaint becomes safe.
document.addEventListener('focusout', () => {
  if (!liveMissed) return;
  setTimeout(() => {
    if (!liveMissed) return;
    if (isEditing() || sheetIsOpen()) return;
    renderLive();
  }, 120);
});

// Nothing is pushed to a page nobody is looking at, and a phone suspends the
// connection anyway. Reopening on return is also what makes the first thing
// you see current rather than however old the tab was.
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') { stopLive(); return; }
  if (!state.guildId) return;
  startLive();
  // Do NOT refreshOverview on every tab focus — that rebuilds forms and
  // erases text the user was typing. Only fetch if overview never loaded.
  if (!state.overview) refreshOverview();
});

// The other way a load quietly loses: the request went out while the
// connection was down. Nothing tells the page that except this.
window.addEventListener('online', () => {
  if (!state.guildId) return;
  if (isEditingPanel()) return; // keep typed fields
  refreshOverview();
});

// Coming back through the history stack — Back into the panel, or a phone
// restoring the tab — replays the page from cache without re-running any of
// it. Whatever was missing then is still missing now.
window.addEventListener('pageshow', (e) => {
  if (e.persisted && state.guildId) refreshOverview();
});

/* ── boot ──────────────────────────────────────────────────────────────── */

/**
 * Shows one section and marks its nav button.
 *
 * The active section carries `data-active` and the stylesheet keys off that
 * alone, so adding a section is a matter of adding markup and a nav button —
 * there is no second list anywhere that has to be kept in step.
 */


/* Catch selects injected after first enhance (giveaway form, feeds, etc.) */
(function watchSelects() {
  if (window.cselectObserver) return;
  window.cselectObserver = new MutationObserver(() => {
    try { enhanceSelects(document); } catch (_) {}
  });
  const start = () => {
    if (!document.body) return;
    window.cselectObserver.observe(document.body, { childList: true, subtree: true });
  };
  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start);
})();

function enhanceSelects(scope) {
  const rootEl = scope || document;
  rootEl.querySelectorAll('select:not([data-cselect])').forEach((sel) => {
    if (sel.closest('.cselect')) return;
    sel.dataset.cselect = '1';
    sel.classList.add('cselect-native');
    const wrap = document.createElement('div');
    wrap.className = 'cselect';
    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(sel);
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'cselect-trigger';
    btn.setAttribute('aria-haspopup', 'listbox');
    btn.setAttribute('aria-expanded', 'false');
    const val = document.createElement('span');
    val.className = 'cselect-value';
    const chev = document.createElement('span');
    chev.className = 'cselect-chev';
    chev.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>';
    btn.append(val, chev);
    wrap.appendChild(btn);
    const menu = document.createElement('div');
    menu.className = 'cselect-menu';
    menu.hidden = true;
    menu.setAttribute('role', 'listbox');
    document.body.appendChild(menu);

    const syncLabel = () => {
      const opt = sel.options[sel.selectedIndex];
      val.textContent = opt ? (opt.textContent || opt.value || '—') : '—';
    };
    syncLabel();

    let closeTimer = null;
    const close = () => {
      if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
      wrap.dataset.open = '';
      btn.setAttribute('aria-expanded', 'false');
      menu.classList.remove('is-open', 'is-leaving');
      menu.hidden = true;
      menu.replaceChildren();
    };
    const softClose = () => {
      if (wrap.dataset.open !== '1') return;
      wrap.dataset.open = '';
      btn.setAttribute('aria-expanded', 'false');
      menu.classList.remove('is-open');
      menu.classList.add('is-leaving');
      if (closeTimer) clearTimeout(closeTimer);
      closeTimer = setTimeout(() => {
        menu.classList.remove('is-leaving');
        menu.hidden = true;
        menu.replaceChildren();
        closeTimer = null;
      }, 160);
    };

    const place = () => {
      const r = btn.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const pad = 8;
      const width = Math.min(Math.max(r.width, 180), vw - pad * 2);
      let left = r.left;
      if (left + width > vw - pad) left = vw - width - pad;
      if (left < pad) left = pad;
      menu.style.position = 'fixed';
      menu.style.width = width + 'px';
      menu.style.left = left + 'px';
      menu.style.right = 'auto';
      menu.style.overflowY = 'auto';
      menu.style.webkitOverflowScrolling = 'touch';

      const spaceBelow = vh - r.bottom - pad;
      const spaceAbove = r.top - pad;
      const maxCap = Math.floor(vh * 0.55);
      let maxH;
      if (spaceBelow >= 160 || spaceBelow >= spaceAbove) {
        maxH = Math.max(140, Math.min(maxCap, spaceBelow));
        menu.style.top = (r.bottom + 6) + 'px';
        menu.style.bottom = 'auto';
      } else {
        maxH = Math.max(140, Math.min(maxCap, spaceAbove));
        menu.style.bottom = (vh - r.top + 6) + 'px';
        menu.style.top = 'auto';
      }
      menu.style.maxHeight = maxH + 'px';
    };

    // Close only when the PAGE scrolls — not when scrolling the menu list
    const onScrollClose = (e) => {
      if (menu.contains(e.target)) return;
      softClose();
    };
    window.addEventListener('scroll', onScrollClose, true);

    const open = () => {
      document.querySelectorAll('.cselect-menu').forEach((m) => {
        m.hidden = true;
        m.replaceChildren();
        m.classList.remove('is-open', 'is-leaving');
      });
      document.querySelectorAll('.cselect[data-open="1"]').forEach((w) => {
        w.dataset.open = '';
        const b = w.querySelector('.cselect-trigger');
        if (b) b.setAttribute('aria-expanded', 'false');
      });

      menu.replaceChildren();
      // Search ONLY on selects that opt in (Quick Action member)
      const searchable = sel.dataset.searchable === '1';
      let filter = '';
      let listHost = menu;

      if (searchable) {
        const searchWrap = document.createElement('div');
        searchWrap.className = 'cselect-search';
        const input = document.createElement('input');
        input.type = 'search';
        input.placeholder = 'Search members…';
        input.autocomplete = 'off';
        input.spellcheck = false;
        input.addEventListener('click', (e) => e.stopPropagation());
        input.addEventListener('keydown', (e) => e.stopPropagation());
        input.addEventListener('input', () => {
          filter = input.value || '';
          paintOpts();
        });
        searchWrap.appendChild(input);
        menu.appendChild(searchWrap);
        listHost = document.createElement('div');
        listHost.className = 'cselect-list';
        menu.appendChild(listHost);
        setTimeout(() => { try { input.focus(); } catch (_) {} }, 20);
      }

      const paintOpts = () => {
        listHost.querySelectorAll('.cselect-option, .cselect-empty').forEach((n) => n.remove());
        const q = filter.trim().toLowerCase();
        let shown = 0;
        Array.from(sel.options).forEach((opt, i) => {
          const text = opt.textContent || opt.value || '—';
          if (q && !text.toLowerCase().includes(q) && !(opt.value || '').includes(q)) return;
          const o = document.createElement('button');
          o.type = 'button';
          o.className = 'cselect-option' + (opt.selected ? ' is-selected' : '');
          o.setAttribute('role', 'option');
          o.textContent = text;
          if (opt.disabled) o.disabled = true;
          o.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (opt.disabled) return;
            sel.selectedIndex = i;
            sel.dispatchEvent(new Event('change', { bubbles: true }));
            syncLabel();
            close();
          });
          listHost.appendChild(o);
          shown++;
        });
        if (!shown) {
          const empty = document.createElement('div');
          empty.className = 'cselect-empty';
          empty.textContent = 'No matches';
          listHost.appendChild(empty);
        }
      };

      paintOpts();
      menu.hidden = false;
      menu.classList.remove('is-leaving');
      void menu.offsetWidth;
      menu.classList.add('is-open');
      wrap.dataset.open = '1';
      btn.setAttribute('aria-expanded', 'true');
      place();
    };

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (wrap.dataset.open === '1') softClose();
      else open();
    });
    sel.addEventListener('change', syncLabel);
  });
}

document.addEventListener('click', (e) => {
  if (e.target.closest && (e.target.closest('.cselect') || e.target.closest('.cselect-menu'))) return;
  document.querySelectorAll('.cselect-menu.is-open, .cselect-menu:not([hidden])').forEach((m) => {
    m.classList.remove('is-open');
    m.classList.add('is-leaving');
    setTimeout(() => {
      m.classList.remove('is-leaving');
      m.hidden = true;
      m.replaceChildren();
    }, 160);
  });
  document.querySelectorAll('.cselect[data-open="1"]').forEach((w) => {
    w.dataset.open = '';
    const b = w.querySelector('.cselect-trigger');
    if (b) b.setAttribute('aria-expanded', 'false');
  });
});
window.addEventListener('resize', () => {
  document.querySelectorAll('.cselect-menu').forEach((m) => { m.hidden = true; m.replaceChildren(); });
  document.querySelectorAll('.cselect[data-open="1"]').forEach((w) => { w.dataset.open = ''; });
});

function showSection(name) {
  try { enhanceSelects(document); } catch (e) {}

  const prev = root.dataset.section;
  root.dataset.section = name;
  const titleEl = document.getElementById('here');
  if (titleEl) titleEl.textContent = (SECTION_NAMES && SECTION_NAMES[name]) || name;
  for (const s of document.querySelectorAll('.section')) {
    const active = s.dataset.section === name;
    s.toggleAttribute('data-active', active);
  }
  for (const b of document.querySelectorAll('#sections button')) {
    if (b.dataset.goto === name) b.setAttribute('aria-current', 'true');
    else b.removeAttribute('aria-current');
  }
  // Paint heavy editors only when their tab is opened (stops flash + lag).
  if (name === 'appearance' && prev !== 'appearance') renderAppearance();
  if (name === 'automation' && prev !== 'automation') {
    try { renderSchedules(); } catch (e) { console.warn('[panel] renderSchedules', e); }
    try { renderAutoreplies(); } catch (e) { console.warn('[panel] renderAutoreplies', e); }
  }
  if (name === 'composer' && prev !== 'composer') {
    try { renderComposer(); } catch (e) { console.warn('[panel] renderComposer', e); }
  }
  if (name === 'giveaways') {
    renderGiveaways();
    // First open of the tab builds the form; later visits keep typed draft
    renderGiveawayForm({ force: !$('#form-gaw')?.dataset?.ready });
  }
}

function initSections() {
  for (const b of document.querySelectorAll('#sections button')) {
    b.addEventListener('click', () => {
      showSection(b.dataset.goto);
      if (b.dataset.goto === 'giveaways') state.gawBump?.();
      // Spans every guild, so nothing about switching servers ever refreshes
      // it the way refreshOverview does the guild-scoped tabs — it has to ask
      // for itself, and asking again on every visit is what catches a grant
      // another admin made from a different device in between.
      if (b.dataset.goto === 'owner') loadOwnerConsole();
      paintBar();
      history.replaceState(null, '', `?g=${state.guildId}&s=${b.dataset.goto}`);
    });
  }
}

async function selectGuild(id) {
  const switched = state.guildId !== id;
  state.guildId = id;
  history.replaceState(null, '', `?g=${id}&s=${root.dataset.section}`);
  renderGuildPicker();
  // Only drop the previous overview when the server actually changes.
  // Clearing it on every select (including retries) is what left the panel
  // with empty SYSTEMS / TOP BALANCES cards when a phone cancelled the fetch.
  if (switched) {
    state.overview = null;
    root.classList.add('overview-loading');
    root.classList.remove('overview-failed');
    // Put loading placeholders back so the layout does not collapse.
    const tiles = $('#tiles');
    if (tiles && ![...tiles.children].some(c => c.classList.contains('ph'))) {
      tiles.replaceChildren(...Array.from({ length: 6 }, () => {
        const t = el('div', 'tile ph');
        t.append(el('div', 'n', '—'), el('div', 'l', 'Loading'));
        return t;
      }));
    }
    ['card-systems', 'card-counts', 'card-health'].forEach(id => {
      const n = document.getElementById(id);
      if (n) n.replaceChildren();
    });
    const board = $('#board');
    if (board) board.replaceChildren();
  }
  await refreshOverview();
  refreshLeaderboard();
}

/* ── keeping the panel filled ──────────────────────────────────────────────
 *
 * One failed request used to leave the panel empty for good: the top bar, the
 * tabs, and a column of headed but blank cards, with a toast that had already
 * faded. The only way out was to close it and open it again.
 *
 * That is easy to hit on a phone and hard to notice anywhere else. The panel
 * is usually opened from Discord or from inside Whop, which means the page
 * frequently starts loading in a tab that is not in front — and a phone will
 * suspend a background page part-way through, cancel what it had in flight,
 * and hand it back looking finished. Whatever had not arrived never does.
 *
 * So the overview is something the page keeps asking for until it has it,
 * rather than something it tries once: retried on failure with a widening
 * gap, asked for again the moment the page is looked at, and again when the
 * network comes back.
 *
 * All of it silent. A first attempt takes a moment on any connection, and a
 * panel that announces every one of them is a panel that is always talking
 * about itself. The retry is the fix; saying "loading" is not, and a notice
 * is one more thing that can be left on screen by mistake. What you should
 * see is the panel filling in.
 */

let overviewTries = 0;
let overviewRetry = null;

async function refreshOverview() {
  const forGuild = state.guildId;
  if (!forGuild) return;
  clearTimeout(overviewRetry);

  const blank = !state.overview;
  if (blank) {
    root.classList.add('overview-loading');
    root.classList.remove('overview-failed');
  }

  try {
    const data = await get(`/api/guild/${forGuild}`);
    // An answer for a server you have since switched away from is not an
    // answer to the question currently on screen.
    if (forGuild !== state.guildId) return;
    state.overview = data;
    overviewTries = 0;
    root.classList.remove('overview-loading', 'overview-failed');
    renderOverview();
    // Force visible state — recovers from interrupted CSS entrances on iOS.
    revealOverviewChrome();
    // Whatever else was blank when this was blank gets another go too.
    if (blank) refreshSidecars();
    // Banner wording is per guild, so Studio has to re-read it rather than keep
    // showing the previous server's copy.
    if (state.tpl) selectTemplate(state.tpl.key);
    // And the stream follows whichever server is being looked at.
    startLive();
  } catch (err) {
    if (forGuild !== state.guildId) return;
    // A 401 is the session, not the server, and retrying it forever would be
    // a loop nobody can see the end of.
    if (err.status === 401) return reportLoadFailure(err);

    overviewTries += 1;
    console.error(err);
    root.classList.remove('overview-loading');
    root.classList.add('overview-failed');
    // 1s, 2s, 4s, 8s, then every 15s. Quick enough that a blip is invisible,
    // slow enough that a server which is genuinely down is not hammered.
    const wait = Math.min(15000, 1000 * 2 ** (overviewTries - 1));
    overviewRetry = setTimeout(refreshOverview, wait);
  }
}

/** After paint, pin opacity so a cancelled animation cannot leave cards invisible. */
function revealOverviewChrome() {
  if (root.dataset.entered) return;
  requestAnimationFrame(() => {
    document.querySelectorAll(
      '.tiles > *:not(.ph), .section[data-active] .panel, .section[data-active]'
    ).forEach(node => {
      node.style.opacity = '1';
      node.style.transform = 'none';
    });
  });
  setTimeout(() => { root.dataset.entered = '1'; }, 700);
}

/**
 * Whether /api/me has ever answered. It is the line between "we do not know
 * who you are" and "we know exactly who you are and something else broke",
 * and those two need opposite responses: one is a sign-in page, the other is
 * an error message on a panel you stay signed in to.
 */
let signedIn = false;

/** Says what actually went wrong, instead of implying you are not signed in. */
function reportLoadFailure(err) {
  console.error(err);
  // A 401 this late is the real thing — the session died while the page was
  // using it — so this is the one failure that does belong on the sign-in page.
  if (err?.status === 401) {
    state.token = null;
    remember(null);
    signedIn = false;
    return showLogin();
  }
  toast('Could not load that server. Reload to try again.', 'bad');
}

async function main() {
  watchScroll();
  dismissKeyboardOnOutsideTap();

  // The popup posts the session back here when it finishes.
  window.addEventListener('message', event => {
    // Only our own origin may hand us a session. Without this check any page
    // that could reach this window could inject one.
    if (event.origin !== location.origin) return;
    if (event.data?.type !== 'yserflow-session' || typeof event.data.token !== 'string') return;
    clearInterval(handoffTimer);
    state.token = event.data.token;
    remember(event.data.token);
    main().catch(() => {});
  });

  let me;
  try {
    me = await get('/api/me');
  } catch (err) {
    if (err.status === 503 && err.body?.missing) return showSetup(err.body.missing);

    // A stored token that no longer works is worse than none — it would keep
    // failing silently on every load. Throwing it away and asking once more is
    // the other half: signing out and straight back in leaves exactly that
    // pair behind, a fresh cookie from the callback and a dead token still in
    // storage, and one refused credential should never be allowed to decide
    // that a page with a perfectly good cookie is not signed in. Costs one
    // extra request, and only on a load that had already failed.
    if (err.status === 401 && state.token) {
      state.token = null;
      remember(null);
      try {
        me = await get('/api/me');
      } catch (retry) {
        if (retry.status === 503 && retry.body?.missing) return showSetup(retry.body.missing);
        return showLogin();
      }
    } else {
      return showLogin();
    }
  }

  // Past this point there is a session. Anything that fails from here on is a
  // problem with the data, not with who you are — see the handler on main().
  signedIn = true;

  state.csrf = me.csrf;
  if (me.token) { state.token = me.token; remember(me.token); }
  state.guilds = me.guilds;
  state.me = me.user;
  renderIdentity(me.user);
  initSections();
  try { enhanceSelects(document); } catch (e) {}
  initSheet();
  initEmbedLink();
  // The button does not exist to click for anyone this is false for — see
  // the comment on #nav-owner in the markup.
  if (me.isOwner) {
    $('#nav-owner').hidden = false;
    loadOwnerConsole();
  }
  $('#tpl-new').addEventListener('click', () => {
    state.tplName = null;
    state.draft = { ...newDraft(''), isNew: true };
    renderComposer();
  });
  // Social feature removed — no #social-new button.
  root.dataset.state = 'panel';
  offerStorageAccess();

  const params = new URLSearchParams(location.search);
  const wanted = params.get('g');
  // Always through showSection, including for the default — it is what puts
  // data-active on a section, and without it nothing would be visible at all.
  const section = params.get('s');
  const known = section && document.querySelector(`#sections button[data-goto="${section}"]`);
  showSection(known ? section : (root.dataset.section || 'overview'));

  paintBar();

  const first = me.guilds.some(g => g.id === wanted) ? wanted : me.guilds[0]?.id;
  // A server whose overview will not load is a broken server, not a broken
  // session. Letting this throw sent the whole of main() into its catch and
  // showed the sign-in page to somebody who had just signed in perfectly
  // well — one bad request and the panel appeared to reject the login.
  if (first) await selectGuild(first).catch(reportLoadFailure);

  refreshSidecars();
  initStudio().catch(() => {});
}

/**
 * The two cards that are not part of the guild overview.
 *
 * Deliberately independent of it, so one slow call never blanks the others —
 * but that also meant a failure here was swallowed and the card stayed empty
 * until the next full reload. They are re-asked on the same occasions the
 * overview is, so the whole screen recovers together rather than in pieces.
 */
function refreshSidecars() {
  refreshLeaderboard();
  get('/api/health').then(renderHealth).catch(() => {});
}

/** Re-fetched on every guild switch, not just on load — the answer depends
 * on the selected guild's economy setting, so a stale one from the last
 * server would be wrong here in a way it never was before that toggle
 * existed. */
function refreshLeaderboard() {
  const q = state.guildId ? `?g=${state.guildId}` : '';
  get(`/api/leaderboard${q}`).then(renderBoard).catch(() => {});
}

// Never sign somebody out over a bug. Before /api/me answers, a failure really
// does mean there is no session and the sign-in page is the right screen.
// After it answers, the session is good and blanking the panel back to a
// sign-in button just tells the person a lie about why nothing loaded.
main().catch(err => {
  console.error(err);
  if (signedIn) toast('Something went wrong loading the panel. Reload to try again.', 'bad');
  else showLogin();
});
